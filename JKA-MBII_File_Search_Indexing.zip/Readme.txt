DISCLAIMER: This has only been tested on Windows 10. Will probably work with Windows 7 onward, but as always use at your own risk. Always have a backup!

What does it do: Configure Windows search to index the content of PK3s and JKA/MBII specific text files. Useful for FA editing or anything else that requires finding something in particular.

Install: Double click the .reg file to import the registry settings. May take a little while for the files to be indexed.