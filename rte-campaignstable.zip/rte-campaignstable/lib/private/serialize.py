import lib.private.buffer as buffer;

class ISerializible():
    def Serialize(self, buf : buffer.Buffer):
        pass; # virtual

    def Deserialize(self, buf : buffer.Buffer):
        pass; #virtual