# mbii-rock-the-era

## **REQUIRES Python 3.11+**

**How to use :**
    Well, since I did not used an isolated python workspace for the project, be advised its probably a good idea to do so on your local. Execute "prepare.bat" to install dependancy modules, then just start the "startRefactor.bat".

Ensure `g_logExplicit` is `"3"`, `g_logSync` is `"1"`, `com_logChat` is `"2"`, and `g_logClientInfo` is `"1"` in your server.cfg.


PROBLEMS : 

#1) File backwards reading module in original form doesnt support ANSI-WIN1252 text encoding that is used by the MBIIServer to log stuff, until this dependancy is resolved via any means, manual modification is required, results are untested.

```
AppData\Local\Programs\Python\Python312\Lib\site-packages\file_read_backwards\file_read_backwards.py

supported_encodings = ["utf-8", "ascii", "latin-1", "ansi"]
```

### **Discord bot integration**

These scripts possess discord bot integration, to send raw log data to the discord servers to better streamline the debugging process. This can be disabled in the code by removing the plugin from godfingerCfg.json. Using this discord bot process requires that you install the required dependencies in the prepare.bat, as well as a sufficiently filled out discordbot.env file following the below example. If it does not exist, it will be generated for you.

```
- plugins/discordbot/discordbot.env
# ensure your bot has administration & bot Oauth2 permissions, and is not a public app
DISCORD_BOT_TOKEN=#Bot API token in discord.com/developers
DISCORD_GUILD_ID=#Discord server ID
DISCORD_CHANNEL_ID=#Discord channel ID
DISCORD_THREAD_ID=#Thread ID, if used
USE_THREAD=#True/False to use discord threads or not
```

### **Config file documentation**

The JSON file format is used for all config files included in this release, and while its usage is convenient for the programmers, it does not allow for in-line commentary to describe the function and usage of various settings in the file. Thus, the following is a brief overview of the config files included in this release.

### **godfingerCfg.json**

```
- "Remote"
    - "address"
        - "ip" : The IP address of the server to connect to. In most cases this should be localhost as the script requires access to the log file to function.
        - "port" : The port to connect to. In most cases, should be 29070.
    - "bindAddress" : The address for the script to use as a bind address. In most cases should be the same as the IP.
    - "password" : The server's rcon password. Set in server.cfg.
- "MBIIPath" : File path to the MBII installation to be used.
- "logFilename" : Name of the server log file (defined in server.cfg, default is server.log)
- "serverFileName" : Name of the server executable file to use.
- "logicDelay" : Interval of time to pass between script heartbeat loops.
- "logReadDelay" : Interval of time to pass between retrieval of new log lines to parse.
- "restartOnCrash" : If this is set to true, the server will attempt to restart itself if a fatal exception is detected.
- "paths" : A list of string paths to append to system path, used to pass import directories for dependancies of plugins and such.
- "prologueMessage" : A string to post in svsay when the platform is up.
- "epilogueMessage" : A string to post in svsay when the platform is finishing.
- "Plugins": A list of plugin names, defined as python package strings (https://docs.python.org/3/tutorial/modules.html#packages), to use with the engine.
```

### **RTECfg.json**

```
- "Remote"
    - "address"
        - "ip" : The IP address of the server to connect to. In most cases this should be localhost as the script requires access to the log file to function.
        - "port" : The port to connect to. In most cases, should be 29070.
    - "bindAddress" : The address for the script to use as a bind address. In most cases should be the same as the IP.
    - "password" : The server's rcon password. Set in server.cfg.
- "MBIIPath": File path to the MBII installation to be used.
- "MessagePrefix": Prefix to display before messages. Can use '^(0-9)' color codes.
- "RTEPrefix": Character (or string of characters) that must appear before messages to be registered by the script.
- "requirePrefix" : if set to true, RTEPrefix must appear before all commands to be recognized by the script. If set to false, RTEPrefix is optional.
- "UpdateSeconds": Interval of time to pass between script updates.
- "NetworkFPS": Unused
- "rtePort": Unused
- "rtvPort": Unused
- "rteVoteTime": Duration of RTE votes.
- "rtbVoteTime": Duration of RTB votes
- "tcmpVoteTime": Duration of 'toggle campaign' votes
- "limitMultipleTiebreakers": If set to 0, tiebreakers can potentially go on infinitely if they keep ending in ties. If set to any integer *'x'* over 0, then after *x* tiebreakers, the script will pick a random option.
- "useConstantTeamConfigs": If set to true, provides a constant set of teamconfigs before any additional logic, typically used for observer classes.
```

### **rtvConfig.json**

```
- "Remote"
    - "address"
        - "ip" : The IP address of the server to connect to. In most cases this should be localhost as the script requires access to the log file to function.
        - "port" : The port to connect to. In most cases, should be 29070.
    - "bindAddress" : The address for the script to use as a bind address. In most cases should be the same as the IP.
    - "password" : The server's rcon password. Set in server.cfg.
- "mapBanList" : List of maps to ban from RTV (or, if mapBanListWhitelist is set to true, a list of maps that can be selected by RTV)
- "mapBanListWhitelist" : If set to true, mapBanList acts as a blacklist (maps in the list will not be allowed to be selected by RTV.) If set to false, mapBanList acts as a whitelist ("only" maps in mapBanList will be allowed to be selected by RTV.)
- "emptyServerMap" : 
    - "enabled" : If set to true, the map below will be loaded if no players are on the server.
    - "map" : Name of map to be loaded if there are no players on the server.
- "MBIIPath": File path to the MBII installation to be used.
- "MessagePrefix": Prefix to display before messages. Can use '^(0-9)' color codes.
- "RTVPrefix": Character (or string of characters) that must appear before messages to be registered by the script if requirePrefix is set to true.
- "requirePrefix" : if set to true, RTVPrefix must appear before all commands to be recognized by the script. If set to false, RTVPrefix is optional.
- "voteTime" : Duration of RTV votes.
```

### **stconfig.json**

```
- "scorePerKill": Score amount rewarded to a team when a team member of respective team scores a kill
- "scorePerSuicide": Score amount rewarded ( can be negative ) to a team when a team member of respective team scores a team kill
- "pointsPerScore": Points amount rewarded to a team points pool ( credits ) when a score reward is applied to the respective team
- "pointsLimit": Points amount until the overflow kicks in and drops both teams points back to 0, overflown cut value is truncated
- "killsToAnnounce": Amount of kills to trigger accumulated points and tickets announcement in global game chat via rcon
- "startingPoints": A pair of integers representing default starting points for team RED and team BLUE in that order e.g [ 50, 50 ]
- "resetOnEmpty": A toggle that makes points and tickets to reset if configured to True, otherwise set to False
- "startingTickets": An integer representing default starting tickets for both teams
- "ticketExhaustPoints": A pair of integers representing amount of points to reward for a team when their tickets are depleted, Loose and Win in that order,
e.g [ 50, 100 ]
```

