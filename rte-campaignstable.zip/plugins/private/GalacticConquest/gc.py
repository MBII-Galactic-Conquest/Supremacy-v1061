
import logging;
import godfingerEvent;
import pluginExports;
import lib.shared.serverdata as serverdata
import lib.shared.config as config;
import time;
import json;
import plugins.private.GalacticConquest.gcTeamConfig as gcTeamConfig;
import plugins.private.GalacticConquest.gcCampRot as gcCampRotation;
import threading;
import os;
import lib.shared.pk3 as pk3;
import pathlib;
import lib.shared.client as client;


CONFIG_DEFAULT_PATH = os.path.join(os.path.dirname(__file__), "gcConfig.json");
global GCCONFIG
GCCONFIG = config.Config.fromJSON(CONFIG_DEFAULT_PATH)
CONFIG_FALLBACK = \
"""{
    "MBIIPath": "your/path/to/mbii/here",
    "emptyServerMap" : 
    {
        "enabled" : true,
        "map" : "gc_intermission",
        "teamConfigs": ["INT_Soldier", "INT_Officer"]
    }
}
"""

global PluginInstance;
SERVER_DATA = None;
Args = None;
Log = logging.getLogger(__name__);


class GalacticConquest(object):
    def __init__(self, serverData : serverdata.ServerData):
        startTime = time.time();
        global GCCONFIG;
        self._serverData = serverData;
        self._config : config.Config = GCCONFIG;
        if self._config == None: # failed to load existing
            # handle config-less init
            Log.error("Missing gcConfig.json, creating a fallback one, close the app, modify gcConfig.json and come back")
            self.config = config.Config()
            self.config.cfg = json.loads(CONFIG_FALLBACK)
            f = open(CONFIG_DEFAULT_PATH, "wt")
            f.write(CONFIG_FALLBACK)
            f.close()
        
        # Should be constant data in runtime, dont modify.
        self._campaignRotations : list[gcCampRotation.GcCampaignRotation] = self.LoadCampaignRotations();
        self._teamConfigs : list[gcTeamConfig.GcTeamConfig] = self.LoadTeamconfigs();

        self._campLookup : dict[str, gcCampRotation.GcCampaignRotation] = {};
        self._tcLookup : dict[str, gcTeamConfig.GcTeamConfig] = {};

        self._GenerateLookups();
    
        Log.info("Galactic Conquest loaded in %.2f seconds\n Campaign count : %d\n TeamConfig count : %d\n" \
                                    % (time.time() - startTime, len(self._campaignRotations), len(self._teamConfigs)));
        

    def _GenerateCampaignLookup(self):
        result = {}; # a dict, just a dict
        for campaign in self._campaignRotations:
            result[campaign.GetNameVerbose()] = campaign;
        return result;

    def _GenerateTcLookup(self):
        result = {}; # a dict, just a dict
        for tc in self._teamConfigs:
            result[tc.GetFilename()] = tc;
        return result;

    def _GenerateLookups(self):
        self._campLookup.clear();
        self._tcLookup.clear();
        self._campLookup = self._GenerateCampaignLookup();
        self._tcLookup = self._GenerateTcLookup();
    

    def GetTcByName(self, name : str) -> gcTeamConfig.GcTeamConfig:
        if name in self._tcLookup:
            return self._tcLookup[name];
        else:
            return None;

    def GetCampByName(self, name : str) -> gcTeamConfig.GcTeamConfig:
        if name in self._campLookup:
            return self._campLookup[name];
        else:
            return None;

    def Start(self) -> bool:
        if self._config.cfg["emptyServerMap"]["enabled"]:  
            pCount = self._serverData.API.GetClientCount();
            if pCount <= 0:
                self.ToIntermission();
        return True;

    def Finish(self) -> bool:
        return True;

    def _ThreadedLoadConfigs(self, pk, indexLock, indexList, resultTcs):
        while True:
            fname = None;
            with indexLock:
                if len(indexList) > 0:
                    fname = indexList.pop(-1);
                else:
                    break;
            if fname.endswith(".mbtc"):
                bd : pk3.PK3Bindata  = pk.GetFile(fname);
                tcR = gcTeamConfig.GcTeamConfig(None, fname);
                if tcR.LoadBytes(bd.bytes):
                    resultTcs.append(tcR);
                else:
                    Log.error("Error loading bytes for : " + bd.name);
            
    def LoadTeamconfigs(self) -> list[gcTeamConfig.GcTeamConfig]:
        tcs = [];
        for file in os.listdir(self._config.cfg["MBIIPath"]):
            fileTup = os.path.splitext(file);
            if fileTup[1] == ".mbtc":
                pathName = self._config.cfg["MBIIPath"] + file;
                tcR = gcTeamConfig.GcTeamConfig(None, pathName);
                tcR.LoadFile(pathName);
                tcs.append(tcR);
        pks = self._serverData.pk3Manager.GetAllPk3();
        lCpuCount = os.cpu_count();
        for k in pks:
            pk = pks[k];
            index = list(pk.GetFilesIndex().keys());
            indexLock = threading.Lock();
            workerThreads = [];
            for c in range(lCpuCount):
                workerThreads.append(threading.Thread(target=self._ThreadedLoadConfigs, daemon=True, args=(pk, indexLock, index, tcs)));
            for thrd in workerThreads:
                thrd.start();
            for thrd in workerThreads:
                thrd.join();
        return tcs;

    def LoadCampaignRotations(self) -> list[gcCampRotation.GcCampaignRotation]:
        crs : list[gcCampRotation.GcCampaignRotation]= [];
        idcounter = 0;
        for file in os.listdir(self._config.cfg["MBIIPath"]):
            fileTup = os.path.splitext(file);
            if fileTup[1] == ".mbcr" and (fileTup[0].find("_") == 1 or fileTup[0].find("_") == 2):      # ignore default campaign rotation since it keeps getting re-added
                cmpR = gcCampRotation.GcCampaignRotation(fileTup[0], idcounter);
                idcounter += 1;
                if cmpR.LoadFile(self._config.cfg["MBIIPath"] + file):
                    crs.append(cmpR);
                else:
                    print("Error loading mbcr file at : " + self._config.cfg["MBIIPath"] + file);
        pks = self._serverData.pk3Manager.GetAllPk3();
        for k in pks:
            pk = pks[k];
            index = pk.GetFilesIndex();
            for zfk in index:
                zi = index[zfk];
                fname = zi.filename;
                if fname.find("/") == -1: # in root dir
                    if fname.endswith(".mbcr"):
                        bd : pk3.PK3Bindata  = pk.GetFile(fname);
                        cmpR = gcCampRotation.GcCampaignRotation(fname, idcounter);
                        idcounter += 1;
                        if cmpR.LoadBytes(bd.bytes):
                            crs.append(cmpR);
                        else:
                            print("Error loading bytes for : " + bd.name);
        crs.sort(key=lambda cr: int(cr.GetEraStr()))
        return crs;

    def ToIntermission(self):
        self._serverData.interface.BatchExecute("b", [
            f"g_siegeteam1 {self._config.cfg['emptyServerMap']['teamConfigs'][0]}",
            f"g_siegeteam2 {self._config.cfg['emptyServerMap']['teamConfigs'][1]}",
            f"map {self._config.cfg['emptyServerMap']['map']}"
        ])


    def OnClientDisconnect(self, eventClient : client.Client, reason : int) -> bool:
        if reason != godfingerEvent.ClientDisconnectEvent.REASON_SERVER_SHUTDOWN:
            Log.debug("Client disconnecting.");
            if self._config.cfg["emptyServerMap"]["enabled"]:   
                if self._serverData.API.GetClientCount() <= 1: # 1 means thats the last client
                    self.ToIntermission();
        return False


def API_GetCampaigns() -> list[gcCampRotation.GcCampaignRotation]:
    global PluginInstance;
    return PluginInstance._campaignRotations;

def API_GetTeamconfigs() -> list[gcTeamConfig.GcTeamConfig]:
    global PluginInstance;
    return PluginInstance._teamConfigs;

def API_GetTCByName(name : str) -> gcTeamConfig.GcTeamConfig:
    global PluginInstance;
    return PluginInstance.GetTcByName(name);

def API_GetCampByName(name : str) -> gcCampRotation.GcCampaignRotation:
    global PluginInstance;
    return PluginInstance.GetCampByName(name);

# DISCLAIMER : DO NOT LOCK ANY OF THESE FUNCTIONS, IF YOU WANT MAKE INTERNAL LOOPS FOR PLUGINS - MAKE OWN THREADS AND MANAGE THEM, LET THESE FUNCTIONS GO.
# Called once when this module ( plugin ) is loaded, return is bool to indicate success for the system
def OnInitialize(serverData : serverdata.ServerData, exports = None) -> bool:
    logMode = logging.INFO;
    if serverData.args.debug:
        logMode = logging.DEBUG;
    if serverData.args.logfile != "":
        logging.basicConfig(
        filename=serverData.args.logfile,
        level=logMode,
        format='%(asctime)s %(levelname)08s %(name)s %(message)s')
    else:
        logging.basicConfig(
        level=logMode,
        format='%(asctime)s %(levelname)08s %(name)s %(message)s')

    global SERVER_DATA;
    SERVER_DATA = serverData; # keep it stored
    global PluginInstance;
    PluginInstance = GalacticConquest(serverData);
    if exports != None:
        exports.Add("GetCampaigns", API_GetCampaigns);
        exports.Add("GetTeamconfigs", API_GetTeamconfigs);
        exports.Add("GetTcByName", API_GetTCByName);
        exports.Add("GetCampByName", API_GetCampByName);
        pass;
    return True; # indicate plugin load success

# Called once when platform starts, after platform is done with loading internal data and preparing
def OnStart():
    global PluginInstance;
    return PluginInstance.Start();

# Called each loop tick from the system, TODO? maybe add a return timeout for next call
def OnLoop():
    pass
    #print("Calling Loop function from plugin!");

# Called before plugin is unloaded by the system, finalize and free everything here
def OnFinish():
    pass;

# Called from system on some event raising, return True to indicate event being captured in this module, False to continue tossing it to other plugins in chain
def OnEvent(event) -> bool:
    global PluginInstance
    #print("Calling OnEvent function from plugin with event %s!" % (str(event)));
    if event.type == godfingerEvent.GODFINGER_EVENT_TYPE_MESSAGE:
        return False;
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_CLIENTCONNECT:
        return False;
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_CLIENTCHANGED:
        return False;
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_CLIENTDISCONNECT:
        return PluginInstance.OnClientDisconnect(event.client, event.reason);
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_INIT:
        return False;
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_SHUTDOWN:
        return False;
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_KILL:
        return False;
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_PLAYER:
        return False;
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_EXIT:
        return False;
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_MAPCHANGE:
        return False;
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_SMSAY:
        return False;

    return False;