from math import floor
from time import time
import queue;
import lib.shared.timeout as timeout;
import lib.shared.player as player;
import lib.shared.teams as teams;
import threading;
import logging;
import lib.shared.colors as colors;
import godfingerinterface;

Log = logging.getLogger(__name__);
hasInformedConsoleVote = False;

class VotingImport():
    def __init__(self):
        self.f_onVoteStartedCallback = None;
        self.f_onVoteFinishedCallback = None;
        self.f_getAllPlayers = None;

class VoteOption():
    def __init__(self, forSomething : object, text):
        self._something = forSomething;
        self._text = text;

    def GetText(self):
        return "" + self._text;

    def __repr__(self):
        return "VoteOption %s %s " % ( self._something, self._text);

class Vote():

    class Voter():
        def __init__(self, player, optionIndex):
            self.player = player;
            self.optionIndex = optionIndex;
    
        def __eq__(self, other):
            return self.player == other.player;

        def __hash__(self):
            return hash((self.player));
        
    class VoteWinner():
        def __init__(self, voteOption : VoteOption, voters : list):
            self.voteOption = voteOption;
            self.voters = voters;
        
        # def GetPlayer(self):
        #     return self._player;

        # def GetOptionIndex(self):
        #     return self._optionIndex;
    
    STATE_IDLE          = 0;
    STATE_PROCESSING    = 1;
    STATE_FINISHED      = 2;
    STATE_EVALUATING    = 4;
    STATE_END           = 5;

    REASON_NONE  = -1;
    REASON_TIMEOUT = 0;
    REASON_FINISHED = 1;
    REASON_KILLED = 2;

    TIMEOUT_ANNOUNCE_SECONDS = 9;

    # TEAM_EVIL/TEAM_GOOD/TEAM_SPEC is fucking non-generic because the main interfacing is via svtell, 
    #   which doesnt distinguish by teams, we have to do it manually, but it's not a Voting system responsibility, client management, that is, deal with it, or fix it.
    # currently only one team is allowed to subject, except for global that is targeting all teams ingame, possible solution - allowed teams list, not sure if its required.
    # prefixStr is used to append to announcement string upon shitposting into server chat
    # caption is basically a name of the vote
    # decsription is vote details string
    # voteThreshold is used to determine vote count to evaluate prematurely ( before timeS expires after vote start )
    #   in relation to population of targeted team ( global considers everyone )
    def __init__(self, timeS : float, voteThreshold : float, options = list[VoteOption], prefixStr = "", \
                 caption = "Default vote name.", description : str = "A default vote description.", teamId : int = teams.TEAM_GLOBAL, voteColor='green'):
        self._imports = None;
        self._prefixStr = prefixStr;
        self._description = description;
        self._caption = caption;
        self._state = Vote.STATE_IDLE;
        self._reason = Vote.REASON_NONE;
        self._options = options; # vote options list
        self._allVoters = list[Vote.Voter](); # all voters list, no context;
        self._voters : dict[ int, list[Vote.Voter] ] = {}; #players generally, key = vote option index, value - list of players that voted for it
        for optionIndex in range(len(options)):
            self._voters[optionIndex] = list[Vote.Voter]();
        self._timeS = timeS;
        self._timeout = timeout.Timeout();
        self._announceTimeout = timeout.Timeout();
        self._teamId = teamId; # teamId identifier, -1 means global
        self.voteThreshold = voteThreshold; # count of players required to evaluate the vote positively as relation of players to global player count in the context
        self.voteColor = voteColor

    def __del__(self):
        pass

    def __repr__(self):
        return "Vote instance teamId : %s  caption : %s options : %s" % ( self._teamId, self._caption, self._options );

    def GetTeam(self) -> int:
        return self._teamId;

    def GetVoters(self):
        return self._voters;

    def GetVoter(self, pid):
        result = None;
        for voter in self._allVoters:
            if voter.player.GetId() == pid:
                result = self._voters[pid];
        return result;

    def GetOptions(self) -> list[VoteOption]:
        return self._options;

    def GetState(self) -> int:
        return self._state;

    def GetReason(self) -> int:
        return self._reason;

    def SetImports(self, imports):
        self._imports = imports;
    
    def GetImports(self):
        return self._imports;

    def GetRandomOption(self) -> VoteOption:
        rslt = None;
        if len(self._options) > 0:
            rslt = self._options[range(len(self._options))];
        return rslt;

    # TODO maybe make it less complex later ?
    def GetWinners(self) -> list[VoteWinner]:
        result = list[Vote.VoteWinner]();
        selfVoters = self._voters.copy();
        highestVoteCount = 0;
        index = -1;
        for k1 in selfVoters:
            voters = selfVoters[k1];
            count = len(voters);
            if count > highestVoteCount:
                highestVoteCount = count;
                index = k1;
        if highestVoteCount != 0:
            result.append(Vote.VoteWinner(self._options[index], selfVoters.pop(index)));
            for k2 in selfVoters:
                voters = selfVoters[k2];
                count = len(voters);
                if count == highestVoteCount:
                    result.append(Vote.VoteWinner(self._options[k2], voters.copy()));
        return result;

    # ITS UGLY ! 
    def HandleVoter(self, player, optionIndex):
        voter = Vote.Voter(player, optionIndex);
        for i in range ( len(self._allVoters) ):
            selfVoter = self._allVoters[i];
            if voter == selfVoter: # basically same player, vote options can be different
                oi1 = voter.optionIndex
                oi2 = selfVoter.optionIndex;
                if oi1 != oi2:
                    print(f"Player {voter.player} changed their vote from {oi2} to {oi1}")
                    selfVoter.optionIndex = oi1; # Now the voter is voting for a different option
                    self._voters[oi2].remove(selfVoter);
                    self._voters[oi1].append(voter);
                else:
                    print( str( player ) + " Has already voted for " + str(optionIndex));
                break;
        if voter not in self._voters[optionIndex]:
            print(f"Player {voter.player} voted for {optionIndex}")
            self._allVoters.append(voter); 
            self._voters[optionIndex].append(voter);
    
    def RevokeVote(self, player, iface : godfingerinterface.IServerInterface):
        pid = player.GetId();
        for cur in self._allVoters:
            if cur.player.GetId() == pid:
                self._voters.pop(pid);
                self._allVoters.remove(cur);
                iface.SvTell(str(pid), "Your vote has been revoked due to team change.");
                break;

    def _Evaluate(self, iface : godfingerinterface.IServerInterface, reason = REASON_TIMEOUT):
        if self._teamId == teams.TEAM_GLOBAL and reason != Vote.REASON_KILLED:
            iface.Say(self._prefixStr +"Vote evaluation stage : " + self._caption);
        self._state = Vote.STATE_EVALUATING;
        self._OnEvaluate(iface, reason);
        self._state = Vote.STATE_END;
    
    def _Announce(self, iface : godfingerinterface.IServerInterface):
        #Log.debug("Announcing vote %s", str(self));
        optionsText = "";
        for index in range(len(self._options)):
            # optionsText += str(index)+"."+str(self._options[index - 1].GetText());
            if index in self._voters:
                optionsText += f"{str(index+1)}({str(len(self._voters.get(index)))}): {str(self._options[index].GetText())}; "
            # if index in self._voters:
            #     optionsText += " ("+str( len( self._voters.get(index) ) )+") ";
        
        color = "default";
        if self._teamId == teams.TEAM_GOOD:
            color = "red";
        elif self._teamId == teams.TEAM_EVIL:
            color = "lblue";
        
        colorized = self._prefixStr+colors.ColorizeText(optionsText, color);
        #Log.debug(colorized);
        # keep it this way until we fix the rate limiting and msg truncation stuff
        iface.SvSay(colorized[:-4]);  # strip off the trailing "; ^7"
        
        #print("ARGH : " + optionsText);
        # truncatedList = rcon.TruncateMessage(optionsText);
        
        # if self._teamId == teams.TEAM_GLOBAL:
        #     #for msg in truncatedList:
        #     rc.svsay(colorized);
        # else:
        #     vstr = "tvmsg%s"%(str(self._teamId));
        #     #rc.setVstr(vstr, optionsText);
        #     allPlayers = self._imports.f_getAllPlayers();
        #     #rc.teamsayvstr(allPlayers, self._teamId, "tvexec%s"%(str(self._teamId)), vstr);
        #     #rc.teamsay(allPlayers, self._teamId, vstr, self._prefixStr +"Voting in progress : <" + self._caption + ">"); #  Time left : " + (str(self._timeout.Left())) );
        #     rc.teamsay(allPlayers, self._teamId, vstr, colorized); #  Time left : " + (str(self._timeout.Left())) );
        #     #for msg in truncatedList:
        #     #    rc.teamsayvstr(allPlayers, self._teamId, vstr, self._prefixStr+msg);
        
        self._OnAnnounce(iface);
        #else:
        #    rc.teamsay(self._prefixStr +"Voting in progress : <" + self._caption + ">");
        
    def TimeLeft(self) -> int:
        return self._timeout.Left();

    def IsActive(self):
        return self._state == Vote.STATE_PROCESSING and self._timeout.IsSet();

    def Start(self, iface : godfingerinterface.IServerInterface, players):
        global hasInformedConsoleVote;

        if not self.IsActive():
            self._timeout.Set( self._timeS );
            self._state = Vote.STATE_PROCESSING;
            self._OnStart(iface);
            if self._teamId == teams.TEAM_GLOBAL:
                iface.SvSay(self._prefixStr+ f"({self._caption}) has started, Time before end : {colors.ColorizeText(str(self._timeS), self.voteColor)} seconds.");
                iface.SvSound("sound/sup/announcer/vote_now.wav");

                if not hasInformedConsoleVote:
                    iface.SvSay("^3*!! CHECK CONSOLE FOR VOTING OPTIONS !!*");
                    hasInformedConsoleVote = True;

                self._Announce(iface);
                self._announceTimeout.Set(Vote.TIMEOUT_ANNOUNCE_SECONDS);
            else:
                if not hasInformedConsoleVote:
                    iface.SvSay("^3*!! CHECK CONSOLE AND VOTE IN TEAM CHAT FOR THIS VOTE !!* ^1REBS(R) ^7/ ^5IMPS(B)");
                    hasInformedConsoleVote = True;

                if self._teamId == teams.TEAM_GOOD:
                    teamColor = colors.COLOR_CODES['red']
                elif self._teamId == teams.TEAM_EVIL:
                    teamColor = colors.COLOR_CODES['lblue']
                else:
                    teamColor = colors.COLOR_CODES['gray']

                iface.TeamSay(players, self._teamId, "tStartStr", self._prefixStr+ f"({self._caption}) has started, Time before end : {colors.ColorizeText(str(self._timeS), self.voteColor)} seconds.");
                iface.TeamSound("sound/sup/announcer/vote_now.wav", self._teamId);

                self._Announce(iface);
                self._announceTimeout.Set(Vote.TIMEOUT_ANNOUNCE_SECONDS);

    # Vote is being kept until its STATE_FINISHED or Timeout is occured ( vote time )
    def Update(self, iface : godfingerinterface.IServerInterface) -> int:
        global hasInformedConsoleVote;

        if self.IsActive(): # still active timer
            if not self._announceTimeout.IsSet():
                self._Announce(iface);
                self._announceTimeout.Set(Vote.TIMEOUT_ANNOUNCE_SECONDS);
            rslt = self._OnUpdate(iface);
            if rslt == Vote.STATE_FINISHED:
                self._reason = Vote.REASON_FINISHED;
                self._Evaluate(iface, Vote.REASON_FINISHED);
                self._state = Vote.STATE_FINISHED;
                hasInformedConsoleVote = False;
            return rslt;
        else:
            # time's up, force Evaluate and return STATE_FINISHED
            self._reason = Vote.REASON_TIMEOUT;
            self._Evaluate(iface, Vote.REASON_TIMEOUT);
            self._state = Vote.STATE_FINISHED;
            hasInformedConsoleVote = False;
            return self._state;

    def Drop(self, iface : godfingerinterface.IServerInterface):
        if self.IsActive():
            self._reason = Vote.REASON_KILLED;
            self._Evaluate(iface, Vote.REASON_KILLED);

    # User defined handlers for main events
    def _OnAnnounce(self, iface : godfingerinterface.IServerInterface):
        pass;

    def _OnUpdate(self, iface : godfingerinterface.IServerInterface) -> int:
        return Vote.STATE_PROCESSING;

    def _OnEvaluate(self, iface : godfingerinterface.IServerInterface, reason):
        pass

    def _OnStart(self, iface : godfingerinterface.IServerInterface):
        pass

# Team votes have their own context and can happen simultaneously along each other and global one
class VoteManager():

    def __init__(self, iface : godfingerinterface.IServerInterface, rtePlayers, teamCount : int = 3, imports : VotingImport = None):
        self._imports = imports;
        self._iface = iface;
        self._rtePlayers = rtePlayers
        # teamId = index in list
        self._teamContexts = [];
        for i in range ( teamCount ):
            self._teamContexts.append(VoteContext(self._imports, rtePlayers)); # create team based contexts

    def __del__(self):
        Log.debug("Deleting vote manager.");
        self.DropVotes();

    def DropVotes(self):
        Log.debug("Dropping votes.");
        # stop all currently ongoing votes
        teamc = len(self._teamContexts);
        for t in range(teamc):
            tc = self._teamContexts[t];
            tc.DropVotes(self._iface);

    def GetCurrentVote(self, teamId : int = teams.TEAM_GLOBAL):
        result = None;
        if teamId < len(self._teamContexts):
            result = self._teamContexts[teamId].GetCurrentVote();
        return result;

    def _OnVoteStart(self, context, vote):
        if self._imports.f_onVoteStartedCallback:
            self._imports.f_onVoteStartedCallback(context, vote);
    
    
    def _OnVoteFinish(self, context, vote):
        if self._imports.f_onVoteFinishedCallback:
            self._imports.f_onVoteFinishedCallback(context, vote);

    # Adds a vote to current vote queue, if queue is empty, this vote will be started immediately
    def QueueVote(self, vote : Vote):
        Log.debug("Vote queue : " + str(vote));
        teamId = vote.GetTeam();
        if teamId in range (len(self._teamContexts)):
            Log.debug("Queueing vote %s", str(vote));
            self._teamContexts[teamId].QueueVote(vote);
    
    def QueueVotes(self, votes : list[Vote]):
        if len( votes ) > 0:
            for i in range( len ( votes ) ) :
                vote = votes[i];
                self.QueueVote(vote);

    def Update(self):
        #Log.debug("Updating global context.");
        for teamCntxInd in range (len(self._teamContexts)):
            #Log.debug("Updating context %s", str(teamCntxInd));
            self._teamContexts[teamCntxInd].Update(self._iface);

    def HandleVote(self, player, optionIndex : int, teamId = teams.TEAM_GLOBAL):
        targetContext = None;
        if teamId in range (len(self._teamContexts)):
            targetContext = self._teamContexts[teamId];
        else:
            return;
        curVote = targetContext.GetCurrentVote();
        curVote.HandleVoter(player,optionIndex);
    
    def GetVoterById(self, pid, teamId) -> Vote.Voter:
        if teamId != teams.TEAM_INVALID and teamId < teams.TEAM_COUNT:
            return self._teamContexts[teamId].GetVoter(teamId, pid);
        return None;
        
    def GetVoter(self, player, teamId) -> Vote.Voter:
        return self.GetVoterById(player.GetId(), teamId);

    def RevokeVote(self, player, teamId):
        if teamId == teams.TEAM_INVALID: # unknown team, make sure
            for t in self._teamContexts:
                t.RevokeVote(player, self._iface);
        else:
            self._teamContexts[teamId].RevokeVote(player, self._iface);
        

    def OnPlayerDisconnect(self, player):
        self.RevokeVote(player, teams.TEAM_INVALID);

    def OnPlayerChangeTeam(self, player, oldTeamId, newTeamId):
        if oldTeamId != newTeamId:
            self.RevokeVote(player, oldTeamId);

    def OnPlayerConnected(self, player):
        pass
            
        
class VoteContext():
        def __init__(self, imports : VotingImport, rtePlayers):
            self._imports = imports;
            self._currentVote : Vote = None;
            self._qLock = threading.Lock();
            self._voteQueue = queue.Queue();
            self._rtePlayers = rtePlayers

        def _StartNext(self, iface : godfingerinterface.IServerInterface):
            nextVote = None;
            with self._qLock:
                if not self._voteQueue.empty():
                    nextVote = self._voteQueue.get();
            if nextVote != None:
                self._currentVote = nextVote;
                if self._imports.f_onVoteStartedCallback:
                    self._imports.f_onVoteStartedCallback(self, nextVote);
                self._currentVote.SetImports(self._imports);
                self._currentVote.Start(iface, list(self._rtePlayers.values()));

        def Update(self, iface : godfingerinterface.IServerInterface):
            if self._currentVote != None:
                #Log.debug("Currently vote processed %s " % (str(self._currentVote)));
                toDiscard = ( self._currentVote.Update(iface) == Vote.STATE_FINISHED );
                if toDiscard:
                    if self._imports.f_onVoteFinishedCallback:
                        self._imports.f_onVoteFinishedCallback(self, self._currentVote);
                    self._currentVote = None; # discard current one, whatever.
                    self._StartNext(iface);
            else:
                self._StartNext(iface);
                
        def QueueVote(self, vote : Vote):
            with self._qLock:
                self._voteQueue.put(vote);
    
        def GetCurrentVote(self) -> Vote:
            return self._currentVote;

        def GetVoter(self, pid) -> Vote.Voter:
            if self._currentVote != None:
                self._currentVote.GetVoter(pid);
            else:
                return None;

        def RevokeVote(self, player, iface : godfingerinterface.IServerInterface):
            if self._currentVote != None:
                self._currentVote.RevokeVote(player, iface);

        def DropVotes(self, iface : godfingerinterface.IServerInterface):
            with self._qLock:
                if not self._voteQueue.empty():
                    while True:
                        vote = self._voteQueue.get(False);
                        if vote != None:
                            vote.Drop(iface);
                        else:
                            break;
            self._currentVote = None;