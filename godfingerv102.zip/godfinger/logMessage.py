

class LogMessage():
    def __init__(self, content : str, isStartup = False):
        self.content = content;
        self.isStartup = isStartup;