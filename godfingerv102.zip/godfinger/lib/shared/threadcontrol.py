

class ThreadControl:
    def __init__(self):
        self.stop = False;
