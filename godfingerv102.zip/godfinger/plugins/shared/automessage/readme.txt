ORIGINALLY MADE BY SITHANII
https://github.com/Sithanii/mb2-automessage