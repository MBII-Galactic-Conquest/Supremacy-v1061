from math import floor
from time import time


class Vote(object):
    '''
    Class representing a vote instance.

    When first initialized, all attributes are set to None. Attributes are populated by the start method.
    '''
    def __init__(self, choices):
        self.timeRemaining = None
        self.voteDuration = None
        self.startTime = None
        self.choices = choices
        self.allowedTeams = {}
        self.votes = {}

    def start(self, voteTime):
        """ Starts this vote instance.  """
        self.timeRemaining = voteTime
        self.voteDuration = voteTime
        for i, _ in enumerate(self.choices):
            self.votes[str(i+1)] = []
            self.startTime = floor(time())

    def getVotes(self, idx):
        if type(idx) == str:  # just in case a string index is passed
            idx = int(idx)
        if 0 <= idx <= 5:
            return self.votes[str(idx)]

    def getWinners(self):
        voteMax = max(self.votes, key= lambda x: len(self.votes[x]))
        winners = []
        if len(self.votes[voteMax]) == 0:    # nobody voted
            return winners
        for i in self.votes:
            if len(self.votes[i]) == len(self.votes[voteMax]):
                winners.append(i)
        return winners
        

class TeamVote(Vote):
    def __init__(self, choices, choices2):
        super().__init__(choices)
        self.choices2 = choices2
        self.votes2 = {}