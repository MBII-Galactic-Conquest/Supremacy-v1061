
class Observable():
    def __init__(self):
        self._events = dict[str, list[object]]();

    def Subscribe(self, name, observer):
        ls = None;
        if name not in self._events:
            ls = self._events[name] = list[object]();
        if observer not in ls:
            ls.append(observer);

    def Unsubscribe(self, name, observer):
        ls = None;
        if name in self._events:
            ls = self._events[name];
            if observer in ls:
                ls.remove(observer);

    def Notify(self, name, data : any):
        ls = None;
        if name in self._events:
            ls = self._events[name];
            for obs in ls:
                obs.Update(data);
