#!/bin/bash

# Start the MBIIDed server with debug options
./mbiided.i386 --debug \
    +set g_log "server.log" \
    +set g_logExplicit "3" \
    +set g_logClientInfo "1" \
    +set g_logSync "4" \
    +set com_logChat "2" \
    +set dedicated 2 \
    +set fs_game "MBII" \
    +exec server.cfg \
    +map gc_intermission \
    +set net_port 29070

# Pause and exit (for keeping the terminal open after execution)
read -p "Press Enter to exit..."
