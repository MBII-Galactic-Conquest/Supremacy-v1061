from io import SEEK_END
import os
from random import choice, randint
from time import sleep, time
from math import floor, ceil
from threading import Thread
from json import load, loads
import traceback;
import threading;
import logging;
import json

import godfingerEvent;

from lib.shared.player import Player

import lib.shared.colors as colors
import lib.shared.config as config
import json
import lib.shared.player as player

import lib.shared.serverdata as serverdata;
import lib.shared.threadcontrol as threadcontrol;
import lib.shared.campaignrotation as campaignrotation;
import lib.shared.teamconfig as teamconfig;

import lib.shared.client as client;
import godfingerEvent;
import lib.private.voting as voting;
import lib.shared.teams as teams;
# import net;

import lib.shared.timeout as timeout;

import plugins.private.GalacticConquest.gcTeamConfig as gcTeamConfig
import plugins.private.GalacticConquest.gcCampRot as gcCampRotation
import threading;
import logging;

import godfingerinterface;

Log = logging.getLogger(__name__);

CONFIG_DEFAULT_PATH = os.path.join(os.path.dirname(__file__), "RTECfg.json");
global rteConfig
rteConfig = config.Config.fromJSON(CONFIG_DEFAULT_PATH)
# Things like port and ip can be omitted, since this thing is supposed to be sharing the filesystem with the server, it could read it's config for credentials.
CONFIG_FALLBACK = \
"""{

    "MBIIPath": "your/path/here/",
    "MessagePrefix": "^5[RTE]: ^7",
    "RTEPrefix": "!",
    "requirePrefix": true,
    "UpdateSeconds": 1,
    "rteVoteTime": 60,
    "rteZeroRandom":false,
    "rtbVoteTime": 60,
    "rtbZeroRandom":false,
    "tcmpVoteTime": 10,
    "mapChangeRTBTimeoutSeconds":600,
    "intermissionMapName":"gc_intermission",
    "rtbTimeoutDuration" : 600,

    "limitMultipleTiebreakers":1,
    "useConstantTeamConfigs":true,
    "constantTeamConfigs":
    [
        "cr2_jawas",
        "cr2_jawas"
    ]
}
"""

global BONUSES_DATA;
BONUSES_DATA_PATH = os.path.join(os.path.dirname(__file__), "../../../data/Bonuses.json");
BONUSES_DATA = config.Config.fromJSON(BONUSES_DATA_PATH).cfg;

SERVER_DATA = None;

# s - soldier supplies
# b - soldier bacta
# g - soldier garrison
# bg - soldier bacta & garrison
# c - soldier combat shielding
# sg - sold supplies & garrison
# bs - sold bacta & supplies
# cg - sold shielding & garrison
# cs - sold shielding & supplies
# bc - sold bacta & shielding
# eb - soldier enhanced blasters
# l - generic leader
# m - soldier mvp
# x - named leader

# en - soldier energy boost
# eng - soldier energy & garrison
# ens - soldier energy & supplies
# enb - soldier energy & bacta
# enc - soldier energy & combat shielding

BONUS_STRINGS = \
{
    "s" : "Supplies",
    "b" : "Bacta",
    "g" : "Garrison",
    "bg": "Bacta & garrison",
    "c" : "Combat shielding",
    "sg": "Supplies & garrison",
    "bs": "Bacta & supplies",
    "cg": "Shielding & garrison",
    "cs": "Shielding & supplies",
    "bc": "Bacta & shielding",
    "eb": "Enhanced blasters",
    "l" : "Generic leader",
    "m" : "Soldier MVP",
    "x" : "Named leader",

    "en": "Energy boost",
    "eng":"Energy & garrison",
    "ens":"Energy & supplies",
    "enb":"Energy & bacta",
    "enc":"Energy & combat shielding"
}

ERA_BONUS_BLACKLIST = \
{
    gcCampRotation.ERA_CLONE_WARS : \
    {
        teams.TEAM_GOOD : [],
        teams.TEAM_EVIL : ["B", "BC", "BG", "BS", "ENB", "C", "CG", "CS", "ENC", "EN", "ENG", "ENS"]
    },
    gcCampRotation.ERA_CLONE_WARS_PHASE_2 : \
    {
        teams.TEAM_GOOD : [],
        teams.TEAM_EVIL : ["B", "BC", "BG", "BS", "ENB", "C", "CG", "CS", "ENC", "EN", "ENG", "ENS"]
    },
}

ETC_TYPE_REGULAR = 2;
ETC_TYPE_PHASED = 1;

class RTE(object):

    class RoundConfig():
        def __init__(self, camp : gcCampRotation.GcCampaignRotation = None, team1 : gcTeamConfig.GcTeamConfig = None, team2 : gcTeamConfig.GcTeamConfig = None):
            self._camp = camp;
            self._teams = [team1,team2];

        def GetCampaign(self):
            return self._camp;

        def GetTeams(self):
            return self._teams;

        def GetTeam(self, teamId):
            if teamId == teams.TEAM_GOOD:
                return self._teams[0];
            elif teamId == teams.TEAM_EVIL:
                return self._teams[1];
            return None;

        def SetTeam(self, teamId, team):
            if teamId == teams.TEAM_GOOD:
                self._teams[0] = team
            elif teamId == teams.TEAM_EVIL:
                self._teams[1] = team
    
    #   Sup_Evil1-BC.mbtc
    #   TC_FORMAT_PHASED  = TC_PREFIX+"_{}PH{}{}-{}-{}";  #"Sup_TeamPhaseSubphase-Era-Bonus"
    #   TC_FORMAT_REGULAR = TC_PREFIX+"_{}{}-{}";       #"Sup_TeamEra-Bonus"
    class EraTeamconfig():

        def __init__(self, teamconfig : gcTeamConfig.GcTeamConfig ):
            self._campaign = None;
            self._teamconfig = teamconfig;
            #print(teamconfig.GetFilename());
            self._eraStr = "";
            self._teamStr = "";
            self._teamId = -1; # invalid
            self._bonusStr = "";
            self._phaseStr = "";
            self._subphaseStr = "";
            self._type = 0;
            self.__FormEra();
        
        def __FormEra(self):
            if self._teamconfig != None:
                fname = self._teamconfig.GetFilename();
                if fname != None:
                    if fname.startswith("Sup_"): 
                        splitted = fname.split("_");
                        if len(splitted) == 2:
                            #print(str(splitted));
                            splitted  = splitted[1].split("-");
                            #print(str(len(splitted)));
                            splitLen = len(splitted);
                            if splitLen >= 3:
                                # phased variant, not implemented
                                if splitted[0].find("Good") != -1:
                                    self._teamStr = "Good";
                                    self._teamId = teams.TEAM_GOOD;
                                elif splitted[0].find("Evil") != -1:
                                    self._teamStr = "Evil";
                                    self._teamId = teams.TEAM_EVIL;
                                pos = splitted[0].find("PH");
                                if pos != -1:
                                    # phase found
                                    self._phaseStr = splitted[0][pos+2:1];
                                self._subphaseStr = "";
                                self._eraStr = splitted[1];
                                self._bonusStr = splitted[2];
                                self._type = ETC_TYPE_PHASED;
                            else:
                                # regular variant
                                if splitted[0].find("Good") != -1:
                                    self._teamStr = "Good";
                                    self._teamId = teams.TEAM_GOOD;
                                elif splitted[0].find("Evil") != -1:
                                    self._teamStr = "Evil";
                                    self._teamId = teams.TEAM_EVIL;
                                self._eraStr = splitted[0][4:len(splitted[0])];
                                self._type = ETC_TYPE_REGULAR;
                                if splitLen == 2:
                                    self._bonusStr = splitted[1];
                                elif splitLen == 1:
                                    self._bonusStr = "";
                                    #print(fname);
                            
        @staticmethod
        def IsEraTeamconfigName(str):
            if str.startswith("Sup_"):
                teamStr = str[4:8];
                if teamStr == "Evil" or teamStr == "Good":
                    isPhase = str[8:10].find("PH") != -1;
                    if not isPhase: # not implemented
                        return True;

            return False;

        def GetType(self):
            return self._type;

        def GetEraStr(self):
            return "" + self._eraStr;

        def GetTeamStr(self):
            return "" + self._teamStr;
    
        def GetBonusStr(self):
            return "" + self._bonusStr;
    
        def IsDefault(self) -> bool:
            return self.GetBonusStr() == "";

        def GetBonusVerbose(self):
            if self._bonusStr != '':
                lwr = self._bonusStr.lower();
                return BONUS_STRINGS[lwr];
            return "None";

        def GetTeamconfig(self) -> gcTeamConfig.GcTeamConfig :
            return self._teamconfig;
    
        def GetCampaign(self):
            return self._campaign;
    
        def _SetCampaign(self, camp):
            self._campaign = camp;
        
        def GetTeamId(self):
            return self._teamId;

        def __str__(self):
            return "EraTeamConfig : [ teamConfig \n %s, era %s, team %s, bonus %s, verbose %s, type %s ]" % \
                            ( self._teamconfig, self._eraStr, self._teamStr, self._bonusStr, self.GetBonusVerbose(), self._type);

    class ToggleCampaignVote(voting.Vote):
        def __init__(self, options : list[voting.VoteOption], voteThreshold : float = 0.5):
            super().__init__(rteConfig.cfg["tcmpVoteTime"], voteThreshold, options, rteConfig.cfg["MessagePrefix"], "To toggle campaign mode", voteColor='lblue' );
    
        def _OnEvaluate(self, iface : godfingerinterface.IServerInterface, reason):
            pass

        def _OnStart(self, iface : godfingerinterface.IServerInterface):
            pass

        def _OnUpdate(self, iface : godfingerinterface.IServerInterface) -> int:
            return voting.Vote.STATE_PROCESSING;

    class ToRTEVote(voting.Vote):   # UNUSED
        def __init__(self, options : list[voting.VoteOption], voteThreshold : float = 0.5):
            super().__init__(20, voteThreshold, options, rteConfig.cfg["MessagePrefix"], "To start Rock The Era" );
    
        def _OnEvaluate(self, iface : godfingerinterface.IServerInterface, reason):
            pass

        def _OnStart(self, iface : godfingerinterface.IServerInterface):
            pass

        def _OnUpdate(self, iface : godfingerinterface.IServerInterface) -> int:
            return voting.Vote.STATE_PROCESSING;

    class RTEVote(voting.Vote):
        def __init__(self, options : list[voting.VoteOption], voteThreshold : float = 0.5):
            super().__init__(rteConfig.cfg["rteVoteTime"], voteThreshold, options, rteConfig.cfg["MessagePrefix"], "To Rock The Era!", voteColor='lblue');
    
        def _OnEvaluate(self, iface : godfingerinterface.IServerInterface, reason):
            pass

        def _OnStart(self, iface : godfingerinterface.IServerInterface):
            pass

        def _OnUpdate(self, iface : godfingerinterface.IServerInterface) -> int:
            return voting.Vote.STATE_PROCESSING;

    class RTETCVote(voting.Vote):
        def __init__(self, teamId : int, options : list[voting.VoteOption], voteThreshold : float = 0.5):
            super().__init__(rteConfig.cfg["rtbVoteTime"], voteThreshold, options, rteConfig.cfg["MessagePrefix"], "To select next era team config!", teamId = teamId);
            self.voteColor = 'red' if teamId == teams.TEAM_GOOD else "blue"
        
        def _OnAnnounce(self, iface : godfingerinterface.IServerInterface):
            return super()._OnAnnounce(iface);

        def _OnEvaluate(self, iface : godfingerinterface.IServerInterface, reason):
            pass

        def _OnStart(self, iface : godfingerinterface.IServerInterface):
            pass

        def _OnUpdate(self, iface : godfingerinterface.IServerInterface) -> int:
            return voting.Vote.STATE_PROCESSING;

    """ Singleton representing an instance of Rock The Era """
    def __init__(self, serverData : serverdata.ServerData) -> None:
        #Log.info("RTE initializing...");
        #startTime = time()
        self.bonusesInfo = BONUSES_DATA;
        self.config = rteConfig
        if self.config == None:
            # handle config-less init
            Log.error("Missing config.json, creating a fallback one, close the app, modify config.json and come back")
            self.config = config.Config()
            self.config.cfg = json.loads(CONFIG_FALLBACK)
            f = open(CONFIG_DEFAULT_PATH, "wt")
            f.write(CONFIG_FALLBACK)
            f.close()
        self._limitMultipleTiebreakers = {
            teams.TEAM_GLOBAL   : self.config.cfg["limitMultipleTiebreakers"],
            teams.TEAM_GOOD     : self.config.cfg["limitMultipleTiebreakers"],
            teams.TEAM_EVIL     : self.config.cfg["limitMultipleTiebreakers"]
        }
        self._campaignMode = False;
        self._isRunning = False;
        self._serverData = serverData;
        self._loopThreadLock = threading.Lock();
        self._loopThreadControl = threadcontrol.ThreadControl();
        self._loopThread = Thread(target=self.LoopThreadHandler, daemon=True, args=(self._loopThreadControl, self.config.cfg["UpdateSeconds"]));
        self._playersLock = threading.Lock();
        self.players = {}
        self.voteThreshold = 0.5
        self.wantsToRTE = []
        self.wantsToRTB = []
        self.wantsToTcmp = []
        self.currentVote : voting.Vote = None;
        self._previousRoundConfig = RTE.RoundConfig();
        #self._previousCampaign = None;
        self._currentRoundConfig = RTE.RoundConfig();
        #self._currentCampaign = None
        self._nextRoundConfig = RTE.RoundConfig();
        #self._nextCampaign = None;
        self._changeNextRound = True; # hardcode for now
        self._doRTBafterRTE = False;
        self._roundRTBStarted = False;
        # Voting system init
        self._voteImports = voting.VotingImport();
        self._voteImports.f_onVoteStartedCallback  = self._OnVoteStart;
        self._voteImports.f_onVoteFinishedCallback = self._OnVoteFinish;
        self._voteImports.f_getAllPlayers          = self.GetAllPlayers;
        self._voteManager = voting.VoteManager(self._serverData.interface, self.players, teams.TEAM_COUNT, self._voteImports);
        self._rteNominations = dict[ int, player.Player ]();
        self._bonusNominations = { teams.TEAM_GOOD : dict[ str, player.Player ](), teams.TEAM_EVIL : dict[ str, player.Player ]() };

        self._eraTeamConfigs  = dict[ gcCampRotation.GcCampaignRotation, list[RTE.EraTeamconfig] ]();
        self._goodTeamConfigs = dict[ gcCampRotation.GcCampaignRotation, list[RTE.EraTeamconfig] ]();
        self._evilTeamConfigs = dict[ gcCampRotation.GcCampaignRotation, list[RTE.EraTeamconfig] ]();

        self._commandList = \
            {
                # commands and aliases must be tuples because lists are unhashable apparently
                # index 0 : tuple of aliases for each command
                # index 1: tuple of help string and handler function
                teams.TEAM_GLOBAL : {
                    tuple(["rte", "rocktheera"]) : ("!<rte | rocktheera> - vote to start the next Era vote", self.HandleRTE),
                    tuple(["unrte", "unrocktheera"]) : ("!<unrte | unrocktheera> - cancel your vote to start the next Era vote", self.HandleUnRTE),
                    tuple(["rtb", "rockthebonus"]) : ("!<rtb | rockthebonus> - vote to start the next Bonus vote", self.HandleRTB),
                    tuple(["unrtb", "unrockthebonus"]) : ("!<unrtb | unrockthebonus> - cancel your vote to start the next Era vote", self.HandleUnRTB),
                    tuple(["tcmp", "togglecampaign"]) : ("!<tcmp | togglecampaign> - vote to enable campaign mode", self.HandleTcmp),
                    tuple(["untcmp", "untogglecampaign"]) : ("!<untcmp | untogglecampaign> - cancel your vote to enable campaign mode", self.HandleUnTcmp),
                    tuple(["rten", "era"]) : ("!<rten | era> [id] - nominates an Era for the next Era vote, as long as the list isn't full. If no ID is given, displays the current era.", self.HandleRTENominate),
                    tuple(["unrten", "rera"]) : ("!<unrten | rera> - cancels your Era nomination", self.HandleUnRTENominate),
                    tuple(["rtenl", "eralist"]) : ("!<rtenl | eralist> - displays a list of valid eras for Era voting", self.HandleRTENomList),
                    tuple(["rtbn", "bonus"]) : ("!<rtbn | bonus> - nominates a Bonus for the next Bonus vote, as long as the list isn't full", self.HandleRTBNominate),
                    tuple(["unrtbn", "rbonus"]) : ("!<unrtbn | rbonus> - cancels your Bonus nomination", self.HandleUnRTBNominate),
                    tuple(["rtbnl", "bonuslist"]) : ("!<rtbnl | bonuslist> - displays a list of valid choices for Bonus voting", self.HandleRTBNomList),
                    tuple(["campaignmode", "cmpm"]) : ("!<cmpm | campaignmode> - prints whether campaign mode is enabled", self.HandleCmpm),
                    tuple(["help"]) : ("!help [command] - displays information about the given command, or lists commands if no command is given", self.HandleHelp),
                    tuple(["discord", "disc"]) : ("!discord - shows the Supremacy Discord link in chat", self.HandleDiscord),
                    tuple(["1", "2", "3", "4", "5", "6"]) : ("", self.HandleDecimalVote)    # handle decimal votes (e.g !1, !2, !3)
                },
                teams.TEAM_EVIL : {
                    ("1", "2", "3", "4", "5", "6") : ("", self.HandleDecimalVote)    # handle decimal votes (e.g !1, !2, !3)
                },
                teams.TEAM_GOOD : {
                    ("1", "2", "3", "4", "5", "6") : ("", self.HandleDecimalVote)    # handle decimal votes (e.g !1, !2, !3)
                },
                teams.TEAM_SPEC : {
                    ("1", "2", "3", "4", "5", "6") : ("", self.HandleDecimalVote)    # handle decimal votes (e.g !1, !2, !3)
                }
            }
        self._smodCommandList = {
            tuple(["testcrash", "tcrash"]) : ("!<testcrash|tcrash> - attempts to divide by 0, crashing the server", self.HandleTestCrash),
            tuple(["rtbe", "rtbenable", "unlock"]) : ("!<rtbe|rtbenable> - enables RTB vote if it's on cooldown", self.HandleRTBEnable),
            tuple(["frte", "forcerte"]) : ("!<frte|forcerte> - force RTE vote", self.HandleForceRTE),
            tuple(["frtb", "forcertb"]) : ("!<frtb|forcertb> - force RTB vote", self.HandleForceRTB),
            
        }
        self._rtbTimeout = timeout.Timeout();
        self._rtbResponseTimeout = timeout.Timeout();
        self._rtbAnnounceTimer = None;
        self._rtbTimeoutDuration = self.config.cfg["rtbTimeoutDuration"]
        self._deductedCreditsMsgShown = False;

        # Post-Init ( Start data )
        # Will be initialized upon Start, because thats how plugin's load ordering work.
        self._campaigns = None;
        self._teamconfigs = None;

        self._GetConquestGame = None;
        self._getTcByName = None;

        #Log.info("RTE initialized in %.2f seconds!\n" % (time() - startTime));

    def FormTeamconfigString(self, teamId, tcList : list[str]) -> str:
        rslt = "\"";
        if "useConstantTeamConfigs" in self.config.cfg:
            if self.config.cfg["useConstantTeamConfigs"]:
                if teamId == teams.TEAM_GOOD:
                    rslt += self.config.cfg["constantTeamConfigs"][0];
                elif teamId == teams.TEAM_EVIL:
                    rslt += self.config.cfg["constantTeamConfigs"][1];
        for tcStr in tcList:
            rslt += " " + tcStr;
        rslt += "\""
        return rslt;

    def GetDefaultTeamConfig(self, campaign : gcCampRotation.GcCampaignRotation, teamId) -> EraTeamconfig:
        rslt = None;
        if campaign != None:
            container = None;
            if teamId == teams.TEAM_GOOD:
                container = self._goodTeamConfigs[campaign];
            elif teamId == teams.TEAM_EVIL:
                container = self._evilTeamConfigs[campaign];
            else:
                return rslt;
            for etc in container:
                if etc.IsDefault():
                    rslt = etc;
                    break;
        return rslt;

    def GetAllPlayers(self) -> list[player.Player]:
        result = [];
        with self._playersLock:
            result = list(self.players.values());
        return result;

    def _UpdateNextTeamconfigs(self, camp):
        nextGood = self._nextRoundConfig.GetTeam(teams.TEAM_GOOD)
        nextEvil = self._nextRoundConfig.GetTeam(teams.TEAM_EVIL)
        if nextGood != None and nextGood.GetEraStr() != camp.GetEraStr():
            if int(camp.GetEraStr()) in ERA_BONUS_BLACKLIST:
                if nextGood.GetBonusString() in ERA_BONUS_BLACKLIST[int(camp.GetEraStr())][teams.TEAM_GOOD]:
                    dtc = self.GetDefaultTeamConfig(camp, teams.TEAM_GOOD);
                    self._nextRoundConfig.SetTeam(teams.TEAM_GOOD, dtc.GetTeamconfig())
                    self._serverData.interface.Say(self.config.cfg["MessagePrefix"] + f"Bonus {nextEvil.GetBonusString()} does not exist on Good team for era ID {camp.GetEraStr()}, using default...")
            else:
                for tc in self._eraTeamConfigs[camp]:
                    if tc.GetBonusStr() == nextGood.GetBonusString() and tc.GetTeamId() == teams.TEAM_GOOD:
                        self._nextRoundConfig.SetTeam(teams.TEAM_GOOD, tc._teamconfig)
                        break;
        if nextEvil != None and nextEvil.GetEraStr() != camp.GetEraStr():
            if int(camp.GetEraStr()) in ERA_BONUS_BLACKLIST:
                if nextEvil.GetBonusString() in ERA_BONUS_BLACKLIST[int(camp.GetEraStr())][teams.TEAM_EVIL]:
                    dtc = self.GetDefaultTeamConfig(camp, teams.TEAM_EVIL);
                    self._nextRoundConfig.SetTeam(teams.TEAM_EVIL, dtc.GetTeamconfig())
                    self._serverData.interface.Say(self.config.cfg["MessagePrefix"] + f"Bonus {nextEvil.GetBonusString()} does not exist on Evil team for era ID {camp.GetEraStr()}, using default...")
            else:
                for tc in self._eraTeamConfigs[camp]:
                    if tc.GetBonusStr() == nextEvil.GetBonusString() and tc.GetTeamId() == teams.TEAM_EVIL:
                        self._nextRoundConfig.SetTeam(teams.TEAM_EVIL, tc._teamconfig)
                        break;

    # Vote manager callbacks
    def _OnVoteStart(self, voteContext : voting.VoteContext, vote : voting.Vote):
        Log.debug("Vote starting %s", vote);
        votesInProgress = self._serverData.GetServerVar("votesInProgress")
        if not "RTE" in votesInProgress:
            votesInProgress.append("RTE")
            self._serverData.SetServerVar("votesInProgress", votesInProgress)
    
    # Vote manager callbacks
    def _OnVoteFinish(self, voteContext : voting.VoteContext, vote : voting.Vote):
        votesInProgress = self._serverData.GetServerVar("votesInProgress")
        if "RTE" in votesInProgress:
            votesInProgress.remove("RTE")
            self._serverData.SetServerVar("votesInProgress", votesInProgress)
        Log.debug("Vote finished in RTE");
        voteType = type(vote);
        voteTeam = vote.GetTeam()
        Log.debug("Type is %s " % (str(voteType)));
        winners = vote.GetWinners();
        # if tiebreaker limit has exceeded for the current voting round, choose a random winner
        if self.config.cfg["limitMultipleTiebreakers"] > 0 and self._limitMultipleTiebreakers[voteTeam] == 0 and len(winners) > 1:
            Log.debug("Tiebreaker limit exceeded, choosing random winner.")
            self._serverData.interface.Say("Tiebreaker limit exceeded, choosing random winner.")
            winners = [choice(winners)]
        count = len(winners);
        if count == 0 or count == 1:  # no tie, reset tiebreaker limit
            self._limitMultipleTiebreakers[voteTeam] = self.config.cfg["limitMultipleTiebreakers"]
        reason = vote.GetReason();
        if reason != voting.Vote.REASON_KILLED:
            if voteType == RTE.ToRTEVote:    # UNUSED, CONSIDER REMOVING
                if count == 1:
                    winner = winners[0];
                    voteOption = winner.voteOption;
                    self._serverData.interface.Say("Vote resolved with : "  + winner.voteOption.GetText() + " with whooping vote count of " + str(len(winner.voters)));
                    if voteOption.GetText() == "Start RTE.":
                        voteOptions = [];
                        for camp in self._campaigns:
                            voteOptions.append(voting.VoteOption(camp, camp.GetNameVerbose()));
                        newVote = RTE.RTEVote(voteOptions);
                        self._voteManager.QueueVote(newVote);
                    else:
                        self._serverData.interface.Say("RTE will not start due to vote resolution.");
                else:
                    self._serverData.interface.Say("No one voted for RTE to start.");
            # RTE Vote
            elif voteType == RTE.RTEVote:
                Log.debug("RTE VOTE FINISHED.");
                if count == 1:
                    winner = winners[0];
                    voteOption = winner.voteOption;
                    self._serverData.interface.Say("Vote resolved with : "  + winner.voteOption.GetText() + " with whooping vote count of " + str(len(winner.voters)));
                    if voteOption.GetText() == "Don't Change":
                        self._serverData.interface.Say("Campaign will not be changed in the next round.");
                        self._nextRoundConfig._camp = self._currentRoundConfig._camp;
                    else:
                        for camp in self._campaigns:
                            campNameVerbose = camp.GetNameVerbose();
                            if voteOption.GetText() == campNameVerbose and voteOption._something.GetFilename() == camp.GetFilename():
                                # thats the campaign we target for
                                self._nextRoundConfig._camp = camp;
                                self._UpdateNextTeamconfigs(camp);
                                self._serverData.interface.Say("Campaign will be changed in next round.");
                                break
                            else:
                                pass
                    self._rteNominations.clear(); # clear nominations for RTE
                    self._rtbTimeout.Set(self._rtbTimeoutDuration)
                    if self._doRTBafterRTE:
                        #start teamvotes for both teams for their supplies ( teamconfigs ) before era change
                        gtcList = [];
                        etcList = [];
                        for etc in self._eraTeamConfigs[self._nextRoundConfig._camp]:
                            tid = etc.GetTeamId();
                            if tid == teams.TEAM_GOOD:
                                gtcList.append(etc);
                            elif tid == teams.TEAM_EVIL:
                                etcList.append(etc);
                        optionsList = [];
                        for gtc in gtcList:
                            if gtc._bonusStr != 'M':    # exclude MVP from voting
                                vonm = ( ( "{%dp} " % BONUSES_DATA["Prices"][gtc._bonusStr.lower()] ) + gtc.GetBonusVerbose() );
                                optionsList.append(voting.VoteOption(gtc, vonm));
                        gtcOptions = []
                        for option in optionsList:
                            if option._something.GetBonusStr().lower() in self._bonusNominations[teams.TEAM_GOOD]:
                                gtcOptions.append(option)
                                del self._bonusNominations[teams.TEAM_GOOD][option._something.GetBonusStr().lower()]
                                optionsList.remove(option)
                        while len(gtcOptions) < 5:
                            gtcOptions.append(optionsList.pop(choice(range(0, len(optionsList)))))
                        # Add option to cancel as last vote option, has no vote object
                        gtcOptions.append(voting.VoteOption(None, "Abstain"))
                        gtcVote = RTE.RTETCVote(teams.TEAM_GOOD, gtcOptions);
                        optionsList.clear();
                        for etc in etcList:
                            if etc._bonusStr != 'M':    # exclude MVP from voting
                                vonm = ( ( "{%dp} " % BONUSES_DATA["Prices"][etc._bonusStr.lower()] ) + etc.GetBonusVerbose() );
                                optionsList.append(voting.VoteOption(etc, vonm));
                        etcOptions = []
                        for option in optionsList:
                            if option._something.GetBonusStr().lower() in self._bonusNominations[teams.TEAM_EVIL]:
                                etcOptions.append(option)
                                del self._bonusNominations[teams.TEAM_EVIL][option._something.GetBonusStr().lower()]
                                optionsList.remove(option)
                        while len(etcOptions) < 5:
                            etcOptions.append(optionsList.pop(choice(range(0, len(optionsList)))))
                        etcOptions.append(voting.VoteOption(None, "Abstain"))
                        etcVote = RTE.RTETCVote(teams.TEAM_EVIL, etcOptions);
                        self._voteManager.QueueVote(gtcVote);
                        self._voteManager.QueueVote(etcVote);
                # RTE Vote Tied
                elif count > 1:
                    self._serverData.interface.Say(self.config.cfg["MessagePrefix"] + "^5RTE^7 vote ended in a tie! Beginning tiebreaker vote...")
                    voteOptions = [x.voteOption for x in winners]
                    newVote = RTE.RTEVote(voteOptions);
                    if self._limitMultipleTiebreakers[voteTeam] != 0:
                        self._limitMultipleTiebreakers[voteTeam] -= 1
                    self._voteManager.QueueVote(newVote);
                elif count == 0:
                    if self.config.GetValue("rteZeroRandom", False):
                        self._serverData.interface.SvSay("Noone voted for era to change, picking random.");
                        allOptions = vote.GetOptions();
                        if len( allOptions ) > 1: # -2 because abstain and how randint works
                            ncmp = allOptions[randint(0,len(allOptions)-2)]._something;
                            self._nextRoundConfig._camp = ncmp;
                            self._UpdateNextTeamconfigs(ncmp);
                            self._serverData.interface.SvSay("Random campaign have been picked : %s. Campaign will be changed in next round."%(ncmp.GetNameVerbose()));

                        else:
                            self._serverData.interface.SvSay("Unable to pick random, keeping current one.");
                    else:
                        self._serverData.interface.SvSay("Noone voted for era to change, keeping current one.");
                if self._serverData.API.GetCurrentMap() == "gc_intermission" and count == 1 or count == 0:
                    self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + "^5Rock the Vote ^7starting now!")
                    rtvPluginPath = "plugins.private.RTV.rtvPlugin"
                    rtvPlugin = self._serverData.API.GetPlugin(rtvPluginPath)
                    if rtvPlugin != None:
                        xprts = rtvPlugin.GetExports()
                        xprts.Get("StartRTVVote").pointer(allowNoChange=False)
                    else:
                        Log.error(f"Could not load plugin object for {rtvPluginPath}")
            # RTB vote
            elif voteType == RTE.RTETCVote:
                Log.debug("TC Vote finished with count %s " % ( str(count ) ) );
                if self._nextRoundConfig._camp != None:
                    nextCamp = self._nextRoundConfig._camp
                elif self._currentRoundConfig._camp != None:
                    nextCamp = self._currentRoundConfig._camp
                else:
                    nextCamp = self._campaigns[0]
                Log.debug("Next camp is %s" % nextCamp.GetNameVerbose());
                if count == 1:
                    winner = winners[0];
                    voteOption = winner.voteOption;
                    Log.debug("Winner option %s " % ( str(voteOption) ) );
                    self._serverData.interface.TeamSay(self.GetAllPlayers(), voteTeam, "teamMessage%s"%(str(voteTeam)), "Vote resolved with : "  + winner.voteOption.GetText() + " with vote count of " + str(len(winner.voters)));
                    sleep(2)
                    if not self._deductedCreditsMsgShown:
                        self._serverData.interface.SvSay("^3Credits have been deducted, new teams will be applied on the next round...")
                        self._deductedCreditsMsgShown = True;
                    etc = voteOption._something; # hehe
                    if etc != None:
                        if voteTeam  == teams.TEAM_EVIL or voteTeam == teams.TEAM_GOOD:
                            #if self._campaignMode:
                            cgame = self._GetConquestGame();
                            if cgame.IsValid():
                                price = self.bonusesInfo["Prices"][etc.GetBonusStr().lower()];
                                # conquest game in progress and is valid
                                with cgame.lock:
                                    points = cgame.pointsRed if voteTeam == teams.TEAM_GOOD else cgame.pointsBlue;
                                    Log.debug("Points for team %d is %d and the price for selected bonus is %d" % (voteTeam, points, price ));
                                    if points < price:
                                        dtc = self.GetDefaultTeamConfig(nextCamp, voteTeam);
                                        self._nextRoundConfig.SetTeam(voteTeam, dtc.GetTeamconfig());
                                        self._serverData.interface.TeamSay(self.GetAllPlayers(), voteTeam, "teamMessage%s"%(str(voteTeam)), "Your team cannot afford the top voted bonus, setting to default.");
                                        Log.debug("Team %s teamconfig on next round set to default due to lack of conquest points : %s" % (voteTeam, etc.GetTeamconfig().GetFilename()));
                                    else:
                                        if voteTeam == teams.TEAM_GOOD:
                                            cgame.pointsRed -= price;
                                        else:
                                            cgame.pointsBlue -= price;
                                        self._nextRoundConfig.SetTeam(voteTeam, etc.GetTeamconfig());
                                        Log.debug("Team %s teamconfig on next round set to %s" % (voteTeam, etc.GetTeamconfig().GetFilename()));
                            #else:     
                            #    self._nextRoundConfig.SetTeam(voteTeam, etc.GetTeamconfig());
                            #    Log.debug("Team %s teamconfig on next round set to %s" % (voteTeam, etc.GetTeamconfig().GetFilename()));
                    else:   # Abstain from changing bonus
                        dtc = self.GetDefaultTeamConfig(nextCamp, voteTeam);
                        self._nextRoundConfig.SetTeam(voteTeam, dtc.GetTeamconfig());
                    self._rtbTimeout.Set(self._rtbTimeoutDuration)
                # RTB Vote Tied
                elif count > 1:
                    self._serverData.interface.Say(rteConfig.cfg["MessagePrefix"] + "^5RTB^7 vote ended in a tie! Beginning tiebreaker vote...");
                    voteOptions = [x.voteOption for x in winners]
                    newVote = RTE.RTETCVote(voteTeam, voteOptions);
                    if self._limitMultipleTiebreakers[voteTeam] != 0:
                        self._limitMultipleTiebreakers[voteTeam] -= 1
                    self._voteManager.QueueVote(newVote);
                elif count == 0: # none voted, take default no bonus etc ( two c said its always there, so lets trust him right ? right ? )
                    self._serverData.interface.SvSay("Nobody voted for bonus on team " + str(voteTeam));
                    netc = None;
                    isDefault = False;
                    if not self.config.GetValue("rtbZeroRandom", False):
                        netc = self.GetDefaultTeamConfig(nextCamp, voteTeam);
                        isDefault = True;
                        Log.debug("Team %s did not voted for any bonuses for next era, taking default." % (voteTeam));
                    else:
                        allOptions = vote.GetOptions();
                        if len( allOptions ) > 1:
                            # assuming it always contains abstain and len of 6
                            netc = allOptions[randint(0,len(allOptions)-1)]._something;
                            Log.debug("Team %s did not voted for any bonuses for next era, taking random." % (voteTeam));
                            if netc == None: # take default, should happen only in abstain variant
                                netc = self.GetDefaultTeamConfig(nextCamp, voteTeam);
                                isDefault = True;
                        else:
                            # fallback to default if we're outta options
                            Log.error("On zero vote in RTB options are too scarce to randomize, picking default.");
                            netc = self.GetDefaultTeamConfig(nextCamp, voteTeam);
                            isDefault = True;
                    
                    if not isDefault:
                        cgame = self._GetConquestGame();
                        if cgame.IsValid():
                            price = self.bonusesInfo["Prices"][netc.GetBonusStr().lower()];
                            # conquest game in progress and is valid
                            with cgame.lock:
                                points = cgame.pointsRed if voteTeam == teams.TEAM_GOOD else cgame.pointsBlue;
                                Log.debug("Points for team %d is %d and the price for randomized bonus is %d" % (voteTeam, points, price ));
                                if points < price:
                                    netc = self.GetDefaultTeamConfig(nextCamp, voteTeam);
                                    isDefault = True;
                                    self._serverData.interface.TeamSay(self.GetAllPlayers(), voteTeam, "teamMessage%s"%(str(voteTeam)), "Your team cannot afford randomized bonus, setting to default.");
                                    Log.debug("Team %s teamconfig on next round set to default due to lack of conquest points : %s" % (voteTeam, netc.GetTeamconfig().GetFilename()));
                                else:
                                    if voteTeam == teams.TEAM_GOOD:
                                        cgame.pointsRed -= price;
                                    else:
                                        cgame.pointsBlue -= price;
                        else:
                            netc = self.GetDefaultTeamConfig(nextCamp, voteTeam);
                            self._nextRoundConfig.SetTeam(voteTeam, netc.GetTeamconfig());
                            Log.debug("Unable to get cgame, points mechanic muted, Team %s teamconfig on next round set to %s" % (voteTeam,  netc.GetTeamconfig().GetFilename()));
                            return;
                    
                    self._serverData.interface.SvSay(rteConfig.cfg["MessagePrefix"] + "^5RTB^7 Team %s bonus has been resolved automatically : %s" % (teams.TranslateTeam(voteTeam), netc.GetBonusVerbose()));
                    self._nextRoundConfig.SetTeam(voteTeam, netc.GetTeamconfig());
                    Log.debug("Team %s teamconfig on next round set to %s" % (voteTeam, netc.GetTeamconfig().GetFilename()));
                    
            # TCMP vote
            elif voteType == RTE.ToggleCampaignVote:
                Log.debug("ToggleCampaignVote finished with count %s " % ( str(count ) ) );
                if count == 1:
                    winner = winners[0];
                    voteOption = winner.voteOption;
                    Log.debug("Winner option %s " % ( str(voteOption) ) );
                    self._serverData.interface.Say("Vote resolved with : "  + winner.voteOption.GetText() + " with vote count of " + str(len(winner.voters)));
                    toggleValue = voteOption._something; # hehe
                    returnVal = self._ToggleSelfCampaignMode(toggleValue)
                    if returnVal == 1:
                        self._serverData.interface.Say(self.config.cfg["MessagePrefix"] + f"Campaign mode set to {self._campaignMode}!")
                    elif returnVal == 0:
                        self._serverData.interface.Say(self.config.cfg["MessagePrefix"] + f"Campaign mode was already {self._campaignMode}!")
                    else:
                        self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"ERROR: RTV script could not be reached.")
                elif count > 1:
                    self._serverData.interface.Say(self.config.cfg["MessagePrefix"] + "5ToggleCampaignVote^7 vote ended in a tie! Beginning tiebreaker vote...")
                    voteOptions = [x.voteOption for x in winners]
                    newVote = RTE.ToggleCampaignVote(voteOptions);
                    if self._limitMultipleTiebreakers[voteTeam] != 0:
                        self._limitMultipleTiebreakers[voteTeam] -= 1
                    self._voteManager.QueueVote(newVote);
                elif count == 0:
                    self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"Nobody voted to change campaign mode, keeping it the same.")
        else : # REASON_KILLED
            pass

    def ChangeCampaign(self, campaign):
        self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"Switching Era to {campaign.GetNameVerbose()}...")
        sleep(0.5)
        self._previousRoundConfig._camp = self._currentRoundConfig._camp;
        self._serverData.interface.SetCvar("campaignFile", campaign.GetFilename())
        if self._campaignMode:
            self._serverData.interface.SetCvar("campaign", "1")
        self._currentRoundConfig._camp = campaign;
        self._nextRoundConfig._camp = None;
    
    def GetConfigValue(self, key) -> any:
        return self.config.cfg[key];

    def Stop(self):
        Log.info("Stopping RTE...");
        with self._loopThreadLock:
            self._loopThreadControl.stop = True;
            self._isRunning = False;
        # self._network.Stop();
        self._loopThread.join();
        self._serverData.interface.Say(self.config.cfg["MessagePrefix"] + "Stopping.");
        Log.info("Stopped.");

    def Finish(self):
        if self._isRunning:
            Log.info("Finishing RTE...");
            self.Stop();
            del self._voteManager;
            Log.info("Finished RTE.");
    
    def __del__(self):
        self.Finish();

    def _ClientDisconnect(self, cl : client.Client, reason : int):
        if reason != godfingerEvent.ClientDisconnectEvent.REASON_SERVER_SHUTDOWN:
            id = cl.GetId();
            dcPlayer = None;
            with self._playersLock:
                if id in self.players.keys():
                    dcPlayer = self.players.pop(id)
            if dcPlayer != None:
                dcPlayerTeam = dcPlayer.GetTeamId()
                self._voteManager.OnPlayerDisconnect(dcPlayer);
                # Delete disconnecting player's vote and bonus nominations, if exist
                if dcPlayer.GetTeamId() != teams.TEAM_SPEC:
                    for nom in list(self._bonusNominations[dcPlayerTeam].keys()):
                        if self._bonusNominations[dcPlayerTeam][nom] == dcPlayer:
                            del self._bonusNominations[dcPlayerTeam][nom]
                for nom in list(self._rteNominations.keys()):
                    if self._rteNominations[nom] == dcPlayer:
                        del self._rteNominations[nom]
                Log.info("RTE : Player disconnected: " + str(dcPlayer))
            else:
                Log.warning("RTE : Non-existent Player " + str(id) + " disconnected")
        return False;

    def _ClientConnect(self, cl : client.Client) -> bool:
        id = cl.GetId();
        newPlayer = None;
        with self._playersLock:
            if id in self.players.keys():
                if self.players[id].GetAddress() == cl.GetAddress():
                    return False
                Log.warning("RTE : Duplicate client ID connected, overwriting current entry " + str(id))
        newPlayer = player.Player(cl);
        if newPlayer != None:
            self._OnNewPlayer(newPlayer);
        return False;

    def _OnNewPlayer(self, newPlayer : player.Player):
        with self._playersLock:
            self.players[newPlayer.GetId()] = newPlayer
        self._voteManager.OnPlayerConnected(newPlayer);
        Log.info("RTE : Player joined: " + str(newPlayer))

    def HandleChatCommand(self, player : player.Player, teamId : int, cmdArgs : list[str]) -> bool:
        if len(cmdArgs) > 0:
            command = cmdArgs[0]
            for c in self._commandList[teamId]:
                if command in c:
                    return self._commandList[teamId][c][1](player, teamId, cmdArgs)
        return False

    def HandleCmpm(self, player : player.Player, teamId : int, cmdArgs : list[str]) -> bool:
        capture = False
        if self._serverData.args.debug:    
            # for testing purposes
            capture = True
            self._serverData.interface.Say(self.config.cfg["MessagePrefix"] + f"Campaign Mode Value : ^5{self._campaignMode}")
        return capture;

    def HandleHelp(self, player : player.Player, teamId : int, cmdArgs : list[str]) -> bool:
        capture = True
        commandAliasList = self._serverData.GetServerVar("registeredCommands")
        if len(cmdArgs) > 1:
            for i in commandAliasList:
                if cmdArgs[1] == i[0]:
                    saystr = i[1]
                    self._serverData.interface.Say(self.config.cfg["MessagePrefix"] + saystr)
                    return capture
            # couldn't find command
            self._serverData.interface.Say("^5[ST] ^7: " + f"Couldn't find chat command {colors.ColorizeText(cmdArgs[1], 'lblue')}")
        else:
            saystr = ', '.join([x[0] for x in commandAliasList])
            self._serverData.interface.Say(self.config.cfg["MessagePrefix"] + colors.ColorizeText("(Say !help <command> for help on a specific command): ", "lblue") + saystr)
        return capture
    
    def HandleRTE(self, player : player.Player, teamId : int, cmdArgs : list[str]) -> bool:
        capture = False
        votesInProgress = self._serverData.GetServerVar("votesInProgress")
        currentVote = self._voteManager.GetCurrentVote();
        currentTeamVotes = (self._voteManager.GetCurrentVote(teams.TEAM_GOOD), self._voteManager.GetCurrentVote(teams.TEAM_EVIL))
        if self._nextRoundConfig._camp == None and len(votesInProgress) == 0: # rte not in progress and it was not decided for next round
            capture = True
            playerName = player.GetName();
            playerID = player.GetId()
            playerTeam = player.GetTeamId()
            if self._rtbTimeout.IsSet():
                if not self._rtbResponseTimeout.IsSet():
                    self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + (f"{colors.ColorizeText('Rock the Era', 'lblue')} is temporarily disabled, time left: ^5%s^7" % self._rtbTimeout.LeftDHMS()));
                    self._rtbResponseTimeout.Set(3);
                return capture
            if not playerID in self.wantsToRTE:
                self.wantsToRTE.append(playerID)
                self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"Player {playerName}^7 wants to {colors.ColorizeText('Rock the Era', 'lblue')}! ({len(self.wantsToRTE)}/{ceil(len(self.players) * self.voteThreshold)})")
            else:
                self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"Player {playerName}^7 already wants to {colors.ColorizeText('Rock the Era', 'lblue')}! ({len(self.wantsToRTE)}/{ceil(len(self.players) * self.voteThreshold)})")
            if len(self.wantsToRTE) >= ceil(len(self.players) * self.voteThreshold):
                self.StartRTEVote()
        return capture;

    def HandleUnRTE(self, player : player.Player, teamId : int, cmdArgs : list[str]) -> bool:
        capture = True
        # if self._campaignMode:
        playerName = player.GetName();
        playerID = player.GetId()
        currentVote = self._voteManager.GetCurrentVote();
        currentTeamVotes = (self._voteManager.GetCurrentVote(teams.TEAM_GOOD), self._voteManager.GetCurrentVote(teams.TEAM_EVIL))
        votesInProgress = self._serverData.GetServerVar("votesInProgress")
        if currentVote == None and currentTeamVotes == (None, None) and len(votesInProgress) == 0 and self._nextRoundConfig.GetTeams() == [None, None]:
            if playerID in self.wantsToRTE:
                self.wantsToRTE.remove(playerID)
                self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"Player {playerName}^7 no longer wants to {colors.ColorizeText('Rock the Era', 'lblue')}! ({len(self.wantsToRTE)}/{ceil(len(self.players) * self.voteThreshold)})")
            else:
                self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"Player {playerName}^7 already did not want to {colors.ColorizeText('Rock the Era', 'lblue')}! ({len(self.wantsToRTE)}/{ceil(len(self.players) * self.voteThreshold)})")
            # else:
            #     self._serverData.interface.SvTell(senderClient.GetId(), "Campaign mode is off, to use RTE, toggle it with !togglecampaign/!tcmp vote.");
        return capture; 

    def HandleRTB(self, player : player.Player, teamId : int, cmdArgs : list[str]) -> bool:
        capture = True
        playerName = player.GetName();
        playerID = player.GetId()
        votesInProgress = self._serverData.GetServerVar("votesInProgress")
        if not self._serverData.mapName == self.config.cfg["intermissionMapName"]:
            if not self._roundRTBStarted:
                if not self._rtbTimeout.IsSet():
                    currentVote = self._voteManager.GetCurrentVote();
                    currentTeamVotes = (self._voteManager.GetCurrentVote(teams.TEAM_GOOD), self._voteManager.GetCurrentVote(teams.TEAM_EVIL))
                    if currentVote == None and currentTeamVotes == (None, None) and len(votesInProgress) == 0:     # no global vote in progress
                        if self._nextRoundConfig.GetTeams() == [None, None]:
                            if not playerID in self.wantsToRTB: 
                                self.wantsToRTB.append(playerID)
                                self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"Player {playerName}^7 wants to {colors.ColorizeText('Rock the Bonus', 'lblue')}! ({len(self.wantsToRTB)}/{ceil(len(self.players) * self.voteThreshold)})")
                            else:
                                self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"Player {playerName}^7 already wants to {colors.ColorizeText('Rock the Bonus', 'lblue')}! ({len(self.wantsToRTB)}/{ceil(len(self.players) * self.voteThreshold)})")
                            if len(self.wantsToRTB) >= ceil(len(self.players) * self.voteThreshold):
                                self._deductedCreditsMsgShown = False;
                                self.StartRTBVote();
                else:
                    if not self._rtbResponseTimeout.IsSet():
                        self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + (f"{colors.ColorizeText('Rock the Bonus', 'lblue')} is temporarily disabled to conserve credits, time left: ^5%s^7" % self._rtbTimeout.LeftDHMS()));
                        self._rtbResponseTimeout.Set(3);
        else:
            if not self._rtbResponseTimeout.IsSet():
                self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"{colors.ColorizeText('Rock the Bonus', 'lblue')} is disabled during intermission.");
                self._rtbResponseTimeout.Set(3);
        return capture;

    def HandleUnRTB(self, player : player.Player, teamId : int, cmdArgs : list[str]) -> bool:
        capture = False
        playerName = player.GetName();
        playerID = player.GetId()
        currentVote = self._voteManager.GetCurrentVote();
        currentTeamVotes = (self._voteManager.GetCurrentVote(teams.TEAM_GOOD), self._voteManager.GetCurrentVote(teams.TEAM_EVIL))
        votesInProgress = self._serverData.GetServerVar("votesInProgress")
        if currentVote == None and currentTeamVotes == (None, None) and len(votesInProgress) == 0 and self._nextRoundConfig.GetTeams() == [None, None]:
            capture = True
            # if self._campaignMode:
            if playerID in self.wantsToRTB:
                self.wantsToRTB.remove(playerID)
                self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"Player {playerName}^7 no longer wants to {colors.ColorizeText('Rock the Bonus', 'lblue')}! ({len(self.wantsToRTB)}/{ceil(len(self.players) * self.voteThreshold)})")
            else:
                self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"Player {playerName}^7 already did not want to {colors.ColorizeText('Rock the Bonus', 'lblue')}! ({len(self.wantsToRTB)}/{ceil(len(self.players) * self.voteThreshold)})")

            # else:
            #     self._serverData.interface.svtell(senderClient.GetId(), "Campaign mode is off, to use RTE, toggle it with !togglecampaign/!tcmp vote.");
        return capture; 

    def HandleTcmp(self, player : player.Player, teamId : int, cmdArgs : list[str]) -> bool:
        capture = True
        playerName = player.GetName();
        playerID = player.GetId()
        currentVote = self._voteManager.GetCurrentVote();
        currentTeamVotes = (self._voteManager.GetCurrentVote(teams.TEAM_GOOD), self._voteManager.GetCurrentVote(teams.TEAM_EVIL))
        votesInProgress = self._serverData.GetServerVar("votesInProgress")
        if currentVote == None and currentTeamVotes == (None, None) and len(votesInProgress) == 0:
            if not playerID in self.wantsToTcmp:
                self.wantsToTcmp.append(playerID)
                self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"Player {playerName}^7 wants to toggle campaign! ({len(self.wantsToTcmp)}/{ceil(len(self.players) * self.voteThreshold)})")
            else:
                self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"Player {playerName}^7 already wants to toggle campaign! ({len(self.wantsToTcmp)}/{ceil(len(self.players) * self.voteThreshold)})")
            if len(self.wantsToTcmp) >= ceil(len(self.players) * self.voteThreshold):
                self.wantsToTcmp.clear()
                voteOptions = [voting.VoteOption(True, "Toggle campaign mode On"), voting.VoteOption(False, "Toggle campaign mode Off")];
                tvote = RTE.ToggleCampaignVote(voteOptions);
                self._voteManager.QueueVote(tvote);
                self.currentVote = tvote;
        return capture;

    def HandleUnTcmp(self, player : player.Player, teamId : int, cmdArgs : list[str]) -> bool:
        capture = True
        playerName = player.GetName();
        playerID = player.GetId()
        currentVote = self._voteManager.GetCurrentVote();
        currentTeamVotes = (self._voteManager.GetCurrentVote(teams.TEAM_GOOD), self._voteManager.GetCurrentVote(teams.TEAM_EVIL))
        votesInProgress = self._serverData.GetServerVar("votesInProgress")
        if currentVote == None and currentTeamVotes == (None, None) and len(votesInProgress) == 0:
            if playerID in self.wantsToTcmp:
                self.wantsToTcmp.remove(playerID)
                self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"Player {playerName}^7 no longer wants to toggle campaign! ({len(self.wantsToTcmp)}/{ceil(len(self.players) * self.voteThreshold)})")
            else:
                self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"Player {playerName}^7 already did not want to toggle campaign! ({len(self.wantsToTcmp)}/{ceil(len(self.players) * self.voteThreshold)})")
        return capture

    def HandleRTENominate(self, player : player.Player, teamId : int, cmdArgs : list[str]) -> bool:
        capture = True
        playerName = player.GetName();
        # playerID = player.GetId()
        # currentVote = self._voteManager.GetCurrentVote();
        # currentTeamVotes = (self._voteManager.GetCurrentVote(teams.TEAM_GOOD), self._voteManager.GetCurrentVote(teams.TEAM_EVIL))
        # votesInProgress = self._serverData.GetServerVar("votesInProgress")
        if len(cmdArgs) > 1:
            capture = True
            if cmdArgs[1].isdecimal():
                nominationId = int(cmdArgs[1]);
                if len(self._rteNominations) < 5:
                    for camp in self._campaigns:
                        if nominationId == int(camp.GetEraStr()):
                            # if camp == self._currentRoundConfig._camp: # dont nominate already running era
                            #     return capture;
                            if camp not in self._rteNominations and player not in self._rteNominations.values():
                                self._rteNominations[camp] = player;
                                self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"{playerName}^7 nominated {colors.ColorizeText(camp.GetNameVerbose(), 'lblue')} for RTE !");
                            else:
                                if camp in self._rteNominations:
                                    failReason = f"{camp.GetNameVerbose()} has already been nominated!"
                                elif player in self._rteNominations.values():
                                    failReason = f"{player.GetName()}^7 already nominated an era!"
                                self._serverData.interface.Say(self.config.cfg["MessagePrefix"] + f"Could not nominate RTE Era: {failReason}");
                            return capture
                else:
                    self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + "Era nomination list is full!")
        else:
            capture = True
            if self._serverData.API.GetCurrentMap() == "gc_intermission":
                self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"Please use {colors.ColorizeText('!era <ID>', 'lblue')} to select an era! Find a list of era IDs with the command {colors.ColorizeText('!eralist', 'lblue')}!")
            else:
                self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"Current Era: {colors.ColorizeText(self._currentRoundConfig.GetCampaign().GetNameVerbose(), 'lblue')}")
        return capture
    
    def HandleRTBNominate(self, player : player.Player, teamId : int, cmdArgs : list[str]) -> bool:
        capture = True
        playerName = player.GetName();
        playerID = player.GetId()
        playerTeam = player.GetTeamId()
        # currentVote = self._voteManager.GetCurrentVote();
        # currentTeamVotes = (self._voteManager.GetCurrentVote(teams.TEAM_GOOD), self._voteManager.GetCurrentVote(teams.TEAM_EVIL))
        # votesInProgress = self._serverData.GetServerVar("votesInProgress")
        if len(cmdArgs) > 1:
            bonusStr = cmdArgs[1].lower()
            if self._serverData.args.debug:
                print(playerTeam, bonusStr)
            if not (playerTeam >= teams.TEAM_GOOD and playerTeam <= teams.TEAM_EVIL):
                self._serverData.interface.SvTell(playerID, self.config.cfg["MessagePrefix"] + f"Join a team (^1Red^7/^5Blue^7) to nominate a bonus for that team!")
            elif bonusStr in BONUS_STRINGS:  # ignore team nominations from spectators
                if self._nextRoundConfig.GetCampaign() != None and int(self._nextRoundConfig.GetCampaign().GetEraStr()) in ERA_BONUS_BLACKLIST and bonusStr != 'm' and bonusStr.upper() in ERA_BONUS_BLACKLIST[int(self._nextRoundConfig.GetCampaign().GetEraStr())][playerTeam]:
                    self._serverData.interface.SvTell(playerID, self.config.cfg["MessagePrefix"] + "That bonus cannot be selected for the next team.")
                elif not bonusStr in self._bonusNominations[playerTeam] and bonusStr != 'm':
                    if all([self._bonusNominations[playerTeam][x] != player for x in self._bonusNominations[playerTeam]]):
                        curTc = self._currentRoundConfig.GetTeam(playerTeam);
                        if curTc != None:
                            if curTc.GetBonusString().lower() == bonusStr: # shouldnt happen considering rtb nom list shouldnt return these for players to see
                                self._serverData.interface.SvTell(playerID, "^5[^7RTB^5] You cannot nominate currently ongoing bonus, pick another.");
                                return capture;
                        self._bonusNominations[playerTeam][bonusStr] = player
                        self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"{playerName}^7 ({teams.TranslateTeam(playerTeam)}) nominated {colors.ColorizeText(BONUS_STRINGS[bonusStr], 'lblue')} for RTB !");
                    else:
                        self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"{playerName}^7 ({teams.TranslateTeam(playerTeam)}) has already nominated a bonus.")
                else:
                    self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"Bonus {BONUS_STRINGS[bonusStr]} ({teams.TranslateTeam(playerTeam)}) has already been nominated!")
            else:
                self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"Unknown bonus {colors.ColorizeText(bonusStr, 'lblue')}")
        return capture
    
    def HandleUnRTENominate(self, player : player.Player, teamId : int, cmdArgs : list[str]):
        capture = True
        playerName = player.GetName();
        playerID = player.GetId()
        playerTeam = player.GetTeamId()
        currentVote = self._voteManager.GetCurrentVote();
        currentTeamVotes = (self._voteManager.GetCurrentVote(teams.TEAM_GOOD), self._voteManager.GetCurrentVote(teams.TEAM_EVIL))
        votesInProgress = self._serverData.GetServerVar("votesInProgress")
        nomFound = False
        for nom in list(self._rteNominations.keys()):
            if self._rteNominations[nom] == player:
                nomFound = True
                self._serverData.interface.SvSay(f"{self.config.cfg['MessagePrefix']}{playerName}^7 revoked their nomination for ^5{gcCampRotation.ERAS_LOOKUP[int(nom.GetEraStr())]}^7!")
                del self._rteNominations[nom]
                break
        if nomFound == False:
            self._serverData.interface.SvSay(f"{self.config.cfg['MessagePrefix']}Could not find RTB nomination for player {playerName}^7!")
        return capture
    
    def HandleUnRTBNominate(self, player : player.Player, teamId : int, cmdArgs : list[str]):
        capture = True
        playerName = player.GetName();
        playerID = player.GetId()
        playerTeam = player.GetTeamId()
        currentVote = self._voteManager.GetCurrentVote();
        currentTeamVotes = (self._voteManager.GetCurrentVote(teams.TEAM_GOOD), self._voteManager.GetCurrentVote(teams.TEAM_EVIL))
        votesInProgress = self._serverData.GetServerVar("votesInProgress")
        nomFound = False
        if playerTeam == teams.TEAM_GOOD or playerTeam == teams.TEAM_EVIL:
            for nom in list(self._bonusNominations[playerTeam].keys()):
                if self._bonusNominations[playerTeam][nom] == player:
                    nomFound = True
                    self._serverData.interface.SvSay(f"{self.config.cfg['MessagePrefix']}{playerName}^7 revoked their nomination for ^5{BONUS_STRINGS[nom]}^7!")
                    del self._bonusNominations[playerTeam][nom]
                    break
            if nomFound == False:
                self._serverData.interface.SvSay(f"{self.config.cfg['MessagePrefix']}Could not find RTB nomination for player {playerName}^7!")
        return capture

    def HandleRTENomList(self, player : player.Player, teamId : int, cmdArgs : list[str]):
        capture = True
        # playerName = player.GetName();
        playerID = player.GetId()
        # playerTeam = player.GetTeamId()
        # currentVote = self._voteManager.GetCurrentVote();
        # currentTeamVotes = (self._voteManager.GetCurrentVote(teams.TEAM_GOOD), self._voteManager.GetCurrentVote(teams.TEAM_EVIL))
        # votesInProgress = self._serverData.GetServerVar("votesInProgress")
        self._serverData.interface.SvTell(playerID, "^5[^7List of eras ^5(VIEW IN CONSOLE)]");
        bvstrList = [];
        for camp in self._campaigns:
            desc = camp.GetNameVerbose();
            bvstrList.append("svtell %s %s" % (playerID, "^7" + desc + " ^5(ID : " + str(camp.GetEraStr())) + ")");
        if len(bvstrList) > 0:
            self._serverData.interface.BatchExecute("rtenlSay", bvstrList);
        return capture;

    def HandleRTBNomList(self, player : player.Player, teamId : int, cmdArgs : list[str]):
        capture = True
        teamId = player.GetTeamId();
        playerID = player.GetId()
        if not teams.IsRealTeam(teamId):
            self._serverData.interface.SvTell(playerID, "Join a team to list nominatable bonuses first.");
            return capture;
        self._serverData.interface.SvTell(playerID, "^5[^7List of nominatable bonuses to vote for^5] ");
        bvstrList = [];
        curTeam = self._currentRoundConfig.GetTeam(player.GetTeamId());
        curBonus = None;
        if curTeam != None:
            curBonus = curTeam.GetBonusString().lower();
        for bonus in BONUS_STRINGS:
            if bonus != "m":
                if bonus != curBonus:
                    desc = BONUS_STRINGS[bonus];
                    # if self._campaignMode:
                    price = self.bonusesInfo["Prices"][bonus.lower()];
                    bvstrList.append("svtell %s %s" % (playerID, "^7{^2" + str(price) + "^7} " + desc + " ^5(ID : " + str(bonus.upper())) + ")");
                    # else:
                    #     bvstrList.append("svtell %s %s" % (playerID, "^7" + desc + " ^5(ID : " + str(bonus.upper())) + ")");
        if len(bvstrList) > 0:
            self._serverData.interface.BatchExecute("rtbnlSay", bvstrList);
        return capture;

    def HandleDecimalVote(self, player : player.Player, teamId : int, cmdArgs : list[str]) -> bool:
        capture = False
        # playerName = player.GetName();
        # playerID = player.GetId()
        # playerTeam = player.GetTeamId()
        # currentVote = self._voteManager.GetCurrentVote();
        # currentTeamVotes = (self._voteManager.GetCurrentVote(teams.TEAM_GOOD), self._voteManager.GetCurrentVote(teams.TEAM_EVIL))
        # votesInProgress = self._serverData.GetServerVar("votesInProgress")
        teamVote = self._voteManager.GetCurrentVote(teamId);
        if teamVote != None:
            if cmdArgs[0].isdecimal():
                capture = True
                index = int(cmdArgs[0])-1;
                if index in range(0, len(teamVote.GetOptions())):
                    self._voteManager.HandleVote( player, index, teamId );
        return capture

    def HandleDiscord(self, player : player.Player, teamId : int, cmdArgs : list[str]) -> bool:
        capture = True
        playerID = player.GetId()
        self._serverData.interface.SvSay(f"{self.config.cfg['MessagePrefix']}Discord ^7Link: ^5discord.gg/puSF8Yz93K^7")
        return capture

    def _ChatMessage(self, senderClient : client.Client, message : str, teamId : int ) -> bool:
        #print("message : " + message);
        message = message.lower(); # non-case sensetive
        player : Player = None;
        with self._playersLock:
            player = self.players[senderClient.GetId()];
        if player != None:
            if message.startswith(self.config.cfg["RTEPrefix"]) or not self.config.cfg["requirePrefix"]:
                if message.startswith(self.config.cfg["RTEPrefix"]):
                    message = message[len(self.config.cfg["RTEPrefix"]):]
                if len ( message ) > 0: # in case if someone sends just a prefix and nothing else, otherwise we're splitting an empty string
                    messageParse = message.split()
                    return self.HandleChatCommand(player, teamId, messageParse)
        return False;

    def _AnnounceRTBThreadHandler(self):
        self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"{colors.ColorizeText('Rock the Bonus', 'lblue')} and {colors.ColorizeText('Rock the Era', 'lblue')}  has been enabled.");
        self._serverData.interface.SvSound("sound/sup/bloop.mp3")

    def API_GetCurrentCampaign(self) -> gcCampRotation.GcCampaignRotation:
        return self._currentRoundConfig._camp;

    def StartRTEVote(self):
        # reset list of players that voted to RTE
        self.wantsToRTE.clear()
        voteOptions = [];
        camps = self._campaigns.copy();
        # for camp in camps:
        #     if camp == self._currentRoundConfig._camp:
        #         camps.remove(camp);
        #         break;
        for nom in self._rteNominations:
            camps.remove(nom)
            voteOptions.append(voting.VoteOption(nom, nom.GetNameVerbose()))
        while len(voteOptions) < 5 and len(camps) > 0:  # 2nd condition is failsafe in case there are less than 5 eras after nominations, shouldn't happen in practice
            selected = choice(camps)
            camps.remove(selected)
            voteOptions.append(voting.VoteOption(selected, selected.GetNameVerbose()));
        # Add option to cancel as last vote option, has no vote object
        voteOptions.append(voting.VoteOption(None, "Don't Change"))
        newVote = RTE.RTEVote(voteOptions);
        self._voteManager.QueueVote(newVote);
        # self.currentVote = newVote;

    def StartRTBVote(self):
        nextGood = self._nextRoundConfig.GetTeam(teams.TEAM_GOOD)
        nextEvil = self._nextRoundConfig.GetTeam(teams.TEAM_EVIL)
        if not self._roundRTBStarted and nextGood == None and nextEvil == None:
            self.wantsToRTB.clear()
            self._roundRTBStarted = True;
            if self._nextRoundConfig._camp != None:
                targetCamp = self._nextRoundConfig._camp
            elif self._currentRoundConfig._camp != None:
                targetCamp = self._currentRoundConfig._camp
            else:
                Log.warning("Current campaign is not valid era, defaulting to GCW (id 1)")
                targetCamp = self._campaigns[0]
            gtcList = [];
            etcList = [];
            for etc in self._eraTeamConfigs[targetCamp]:
                tid = etc.GetTeamId();
                if tid == teams.TEAM_GOOD:
                    gtcList.append(etc);
                elif tid == teams.TEAM_EVIL:
                    etcList.append(etc);
            optionsList = [];
            for gtc in gtcList:
                vonm = ( ( "{%dp} " % BONUSES_DATA["Prices"][gtc._bonusStr.lower()] ) + gtc.GetBonusVerbose() );
                if self._nextRoundConfig.GetCampaign() != None and int(self._nextRoundConfig.GetCampaign().GetEraStr()) in ERA_BONUS_BLACKLIST:
                    if not gtc._bonusStr == 'M' and not gtc._bonusStr in ERA_BONUS_BLACKLIST[int(self._nextRoundConfig.GetCampaign().GetEraStr())][teams.TEAM_GOOD]:
                        optionsList.append(voting.VoteOption(gtc, vonm));
                elif gtc._bonusStr != 'M':
                    optionsList.append(voting.VoteOption(gtc, vonm));
            gtcOptions = []
            for option in optionsList:
                if option._something.GetBonusStr().lower() in self._bonusNominations[teams.TEAM_GOOD]:
                    gtcOptions.append(option)
                    del self._bonusNominations[teams.TEAM_GOOD][option._something.GetBonusStr().lower()]
                    optionsList.remove(option)
            while len(gtcOptions) < 5:
                gtcOptions.append(optionsList.pop(choice(range(0, len(optionsList)))))
            # Add option to cancel as last vote option, has no vote object
            gtcOptions.append(voting.VoteOption(None, "Abstain"))
            gtcVote = RTE.RTETCVote(teams.TEAM_GOOD, gtcOptions);

            optionsList.clear();
            for etc in etcList:
                vonm = ( ( "{%dp} " % BONUSES_DATA["Prices"][etc._bonusStr.lower()] ) + etc.GetBonusVerbose() );
                if self._nextRoundConfig.GetCampaign() != None and int(self._nextRoundConfig.GetCampaign().GetEraStr()) in ERA_BONUS_BLACKLIST:
                    if not etc._bonusStr == 'M' and not etc._bonusStr == '' and not etc._bonusStr in ERA_BONUS_BLACKLIST[int(self._nextRoundConfig.GetCampaign().GetEraStr())][teams.TEAM_EVIL]:
                        optionsList.append(voting.VoteOption(etc, vonm));
                elif etc._bonusStr != 'M' and not etc._bonusStr == '':
                    optionsList.append(voting.VoteOption(etc, vonm));
            etcOptions = []
            for option in optionsList:
                if option._something.GetBonusStr().lower() in self._bonusNominations[teams.TEAM_EVIL]:
                    etcOptions.append(option)
                    del self._bonusNominations[teams.TEAM_EVIL][option._something.GetBonusStr().lower()]
                    optionsList.remove(option)
            while len(etcOptions) < 5:
                etcOptions.append(optionsList.pop(choice(range(0, len(optionsList)))))
            etcOptions.append(voting.VoteOption(None, "Abstain"))
            etcVote = RTE.RTETCVote(teams.TEAM_EVIL, etcOptions);
            self._voteManager.QueueVote(gtcVote);
            self._voteManager.QueueVote(etcVote);

    
    def OnClientKill(self, cl : client.Client, victim : client.Client, weaponStr : str) -> bool:
        #Log.debug("Client kill event recieved.");
        return False;

    def OnPlayer(self, cl : client.Client, text : str) -> bool:
        #Log.debug("Player event recieved.");
        return False;

    def OnExit(self, data) -> bool:
        #Log.debug("Exit event recieved.");
        return False;

    def OnClientConnect(self, cl : client.Client )-> bool:
        #Log.debug("Client connect event recived.");
        return self._ClientConnect(cl);

    def OnClientDisconnect(self, cl : client.Client, reason : int)-> bool:
        #Log.debug("Client disconnect event recieved.");
        return self._ClientDisconnect(cl, reason);

    def OnClientChange(self, cl : client.Client, changedOld : dict)-> bool:
        #Log.debug("Client change event recived.");
        player = None;
        with self._playersLock:
            player = self.players[cl.GetId()];
        if player != None:
            keys = changedOld.keys();
            if "t" in keys:
                if changedOld["t"].isdecimal():
                    if int(changedOld['t']) != teams.TEAM_GLOBAL < int(changedOld['t']) <= teams.TEAM_SPEC:
                        if int(changedOld['t']) != teams.TEAM_SPEC:       # don't want to revoke votes every round
                            self._voteManager.OnPlayerChangeTeam(player, int(changedOld["t"]), player.GetTeamId());
                    else:
                        Log.warning(f"Player {player} has bad team ID {changedOld['t']}")
                else:
                    Log.warning(f"Player {player} has non-decimal keys value: {changedOld['t']}")
            if cl.GetTeamId() != player.GetTeamId():
                Log.warning(f"Player {player.GetName()} client does not have the same id as event client with same ID {player._client._teamId} != {cl.GetTeamId()}.")
                player._client = cl
            elif cl._lock != player._client._lock:
                Log.warning(f"Player {player.GetName()} client does not have the same lock as event client with same ID {player._client._teamId} != {cl.GetTeamId()}.")
                player._client = cl
            # if "name" in keys:
            #     pass # name was changed
            # if "ja_guid" in keys:
            #     pass # game guid was changed ( ? )
        return False;

    # Returns True on message containing RTE prefix ( it is an RTE command )
    def OnChatMessage(self, cl : client.Client, message : str, teamId : int ) -> bool:
        return self._ChatMessage(cl, message, teamId);
        
    def OnServerInit(self, data)-> bool:
        self._serverData.SetServerVar("RTBMapChange", False);
        self._roundRTBStarted = False;
        votesInProgress = self._serverData.GetServerVar("votesInProgress")
        if self._voteManager.GetCurrentVote() == None and all([self._voteManager.GetCurrentVote(x) == None for x in range(0, 3)]) and len(votesInProgress) == 0:
            gtc = self._nextRoundConfig.GetTeam(teams.TEAM_GOOD)
            etc = self._nextRoundConfig.GetTeam(teams.TEAM_EVIL)
            goodChanged = evilChanged = False
            currentCamp = self._currentRoundConfig.GetCampaign()
            nextCamp = self._nextRoundConfig.GetCampaign()
            goodDefault = evilDefault = None

            if nextCamp == None and currentCamp != None and (gtc != None or etc != None):
                nextCamp = currentCamp
            
            if nextCamp != None:
                for tc in self._eraTeamConfigs[nextCamp]:
                    if tc.GetEraStr() == nextCamp.GetEraStr() and tc.GetBonusStr() == "":
                        if tc.GetTeamId() == teams.TEAM_GOOD:
                            goodDefault = tc.GetTeamconfig()
                        elif tc.GetTeamId() == teams.TEAM_EVIL:
                            evilDefault = tc.GetTeamconfig()
            if goodDefault and gtc != None and int(gtc.GetEraStr()) in ERA_BONUS_BLACKLIST and gtc.GetBonusString() in ERA_BONUS_BLACKLIST[gcCampRotation.ERA_CLONE_WARS][teams.TEAM_GOOD]:
                gtc = goodDefault
            if evilDefault and etc != None and int(gtc.GetEraStr()) in ERA_BONUS_BLACKLIST in ERA_BONUS_BLACKLIST[gcCampRotation.ERA_CLONE_WARS][teams.TEAM_EVIL]:
                etc = evilDefault
            
            if nextCamp != None:
                if gtc != None:
                    self._serverData.interface.SetTeam1(self.FormTeamconfigString(teams.TEAM_GOOD, [gtc.GetFilename()]))
                    goodChanged = True
                else:
                    gtc = goodDefault
                    self._serverData.interface.SetTeam1(self.FormTeamconfigString(teams.TEAM_GOOD, [gtc.GetFilename()]))
                    goodChanged = True
                if etc != None:
                    self._serverData.interface.SetTeam2(self.FormTeamconfigString(teams.TEAM_EVIL, [etc.GetFilename()]))
                    evilChanged = True
                else:
                    etc = evilDefault
                    self._serverData.interface.SetTeam2(self.FormTeamconfigString(teams.TEAM_EVIL, [etc.GetFilename()]))
                    evilChanged = True
            # no next campaign or current campaign
            elif (gtc != None or etc != None):
                if gtc != None:
                    self._serverData.interface.SetTeam1(self.FormTeamconfigString(teams.TEAM_GOOD, [gtc.GetFilename()]))
                    goodChanged = True
                else:
                    for tc in self._eraTeamConfigs[self._campaigns[0]]:
                        if tc.GetBonusStr() == "" and tc.GetTeamId() == teams.TEAM_GOOD:
                            self._nextRoundConfig.SetTeam(teams.TEAM_GOOD, tc._teamconfig)
                            self._serverData.interface.SetTeam1(self.FormTeamconfigString(teams.TEAM_GOOD, [tc.GetTeamconfig().GetFilename()]))
                            break
                    gtc = tc.GetTeamconfig()
                    goodChanged = True
                if etc != None:
                    self._serverData.interface.SetTeam2(self.FormTeamconfigString(teams.TEAM_EVIL, [etc.GetFilename()]))
                    evilChanged = True
                else:
                    for tc in self._eraTeamConfigs[self._campaigns[0]]:
                        if tc.GetBonusStr() == "" and tc.GetTeamId() == teams.TEAM_EVIL:
                            self._nextRoundConfig.SetTeam(teams.TEAM_EVIL, tc._teamconfig)
                            self._serverData.interface.SetTeam2(self.FormTeamconfigString(teams.TEAM_EVIL, [tc.GetTeamconfig().GetFilename()]))
                            break
                    etc = tc.GetTeamconfig()
                    evilChanged = True
            
            if goodChanged or evilChanged and self._serverData.args and self._serverData.args.debug:
                print(f"Switching teams to {gtc, etc}")

            changeCampaign = False
            if nextCamp != None and currentCamp != nextCamp:
                changeCampaign = True
                self.ChangeCampaign(nextCamp); 
            if ((changeCampaign and self._campaignMode == False) or (not changeCampaign)) and (goodChanged or evilChanged):
                self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + f"Switching teams...")
                sleep(1)
                self._serverData.interface.MapReload(self._serverData.mapName)
                self._nextRoundConfig._camp = None
                self._serverData.SetServerVar("RTBMapChange", True);
            
            if goodChanged:
                self._previousRoundConfig.SetTeam(teams.TEAM_GOOD, self._currentRoundConfig.GetTeam(teams.TEAM_GOOD));
                self._currentRoundConfig.SetTeam(teams.TEAM_GOOD, gtc);
                self._nextRoundConfig.SetTeam(teams.TEAM_GOOD, None);
            if evilChanged:
                self._previousRoundConfig.SetTeam(teams.TEAM_EVIL, self._currentRoundConfig.GetTeam(teams.TEAM_EVIL));
                self._currentRoundConfig.SetTeam(teams.TEAM_EVIL, etc);
                self._nextRoundConfig.SetTeam(teams.TEAM_EVIL, None);

        
        svTeam1 = self._serverData.interface.GetTeam1();
        svTeam2 = self._serverData.interface.GetTeam2();
        if svTeam1 != None:
            svTeam1 = colors.StripColorCodes(svTeam1).strip();
        if svTeam2 != None:
            svTeam2 = colors.StripColorCodes(svTeam2).strip();

        Log.debug("Teams %s : %s " % ( str(svTeam1), str(svTeam2) ) );# ^7 Sup_Good12 : ^7 Sup_Evil12
        if svTeam1 != None and svTeam2 != None:
            self._currentRoundConfig._teams = [self._getTcByName(svTeam1), self._getTcByName(svTeam2)];
        return False;

    def OnServerShutdown(self)-> bool:
        #Log.debug("Server shutdown event recived.");
        return False
        #self._voteManager.DropVotes();          # THIS SHIT BREAKS BONUS VOTING IF THE ROUND ENDS IN THE MIDDLE OF THE VOTE


    def OnMapChange(self, mapName, oldMapName) -> bool:
        Log.debug(f"Map change event received: {mapName}")
        if mapName != self.config.cfg["intermissionMapName"]:
            self._rtbTimeout.Set(self.config.cfg["mapChangeRTBTimeoutSeconds"]);
            if self._rtbAnnounceTimer != None:
                self._rtbAnnounceTimer.cancel();
            self._rtbAnnounceTimer = threading.Timer(self._rtbTimeout.Left(), self._AnnounceRTBThreadHandler);
            self._rtbAnnounceTimer.start();
        else:
            self._rtbTimeout.Set(0); # drop rtertb timeout on intermission map change enter
        
        votesInProgress = self._serverData.GetServerVar("votesInProgress")
        if "RTE" in votesInProgress:
            votesInProgress.remove("RTE")
            self._serverData.SetServerVar("votesInProgress", votesInProgress)
        self._deductedCreditsMsgShown = False;
        self._voteManager.DropVotes()
        return False

    def HandleTestCrash(self, senderName, smodId, senderIP, cmdArgs):
        self._serverData.interface.Say(self.config.cfg["MessagePrefix"] + f"Testing server crash...")
        print(0/0)
    
    def HandleForceRTE(self, senderName, smodId, senderIP, cmdArgs):
        capture = True
        currentVote = self._voteManager.GetCurrentVote();
        currentTeamVotes = (self._voteManager.GetCurrentVote(teams.TEAM_GOOD), self._voteManager.GetCurrentVote(teams.TEAM_EVIL))
        votesInProgress = self._serverData.GetServerVar("votesInProgress")
        if currentVote == None and currentTeamVotes == (None, None) and len(votesInProgress) == 0 and self._nextRoundConfig.GetTeams() == [None, None]:
            self._serverData.interface.SvSay(f"{self.config.cfg['MessagePrefix']}^5RCON ^7forced RTE vote...")
            self.StartRTEVote()
        return capture
    
    def HandleForceRTB(self, senderName, smodId, senderIP, cmdArgs):
        capture = True
        currentVote = self._voteManager.GetCurrentVote();
        currentTeamVotes = (self._voteManager.GetCurrentVote(teams.TEAM_GOOD), self._voteManager.GetCurrentVote(teams.TEAM_EVIL))
        votesInProgress = self._serverData.GetServerVar("votesInProgress")
        if currentVote == None and currentTeamVotes == (None, None) and len(votesInProgress) == 0 and self._nextRoundConfig.GetTeams() == [None, None]:
            self._serverData.interface.SvSay(f"{self.config.cfg['MessagePrefix']}^5RCON ^7forced RTB vote...")
            self.StartRTBVote()
        return capture
    
    def HandleRTBEnable(self, senderName, smodId, senderIP, cmdArgs):
        capture = True;
        if self._rtbTimeout.IsSet():
            self._rtbTimeout.Set(0);
            self._serverData.interface.SvSay(self.config.cfg["MessagePrefix"] + "^5RTB ^7and ^5RTE ^7have been manually enabled.");
            self._serverData.interface.SvSound("sound/sup/bloop.mp3")
            if self._rtbAnnounceTimer != None:
                self._rtbAnnounceTimer.cancel();
        return capture

    def HandleSmodCommand(self, senderName, smodId, senderIP, cmdArgs):
        command = cmdArgs[0]
        if command.startswith(self.config.cfg["RTEPrefix"]):
            command = command[len(self.config.cfg["RTEPrefix"]):]
        for c in self._smodCommandList:
            if command in c:
                return self._smodCommandList[c][1](senderName, smodId, senderIP, cmdArgs)
        return False

    def OnSmsay(self, senderName : str, smodID : int, senderIP : str, message : str):
        message = message.lower()
        messageParse = message.split()
        return self.HandleSmodCommand(senderName, smodID, senderIP, messageParse)
    
    def _GetCurrentServerCampaign(self):
        response = self._serverData.interface.GetCvar("g_campaignRotationFile");
        if response != None:
            for camp in self._campaigns:
                name = camp.GetFilename();
                if name == response:
                    self._currentRoundConfig._camp = camp;
                    Log.info(f"Found currently loaded campaign: {camp.GetFilename()}")
                    break;
        else:
            Log.warning(f"Interface could not be reached, setting currentRoundConfig to None")
            self._currentRoundConfig._camp = None;
        
        response = self._serverData.interface.GetCvar("g_campaign");
        if response != None:
            # self._campaignMode = True if response == "1" else False;
            Log.info("Campaign mode on server is : %s"%(str(response)));
    
    def _ToggleSelfCampaignMode(self, value : bool, campaignRotation : str = None):
        """ Returns 1 if mode was successfully changed, 0 if mode was already set to 'value', and -1 if RTV could not be reached """
        returnVal = -1
        if value != self._campaignMode and type(value) == bool:
            self._campaignMode = value
            self._serverData.SetServerVar("campaignMode", value)
            self._serverData.interface.SetCvar("campaign", "1" if value else "0")
            if campaignRotation:
                self._serverData.interface.SetCvar("campaignFile", campaignRotation)
            returnVal = 1
        elif value == self._campaignMode and type(value) == bool:
            returnVal = 0
        return returnVal

    def LoopThreadHandler(self, control, tickTime):
        toStop = False;
        while not toStop:
            try:
                # Main Loop
                    startTime = time();
                    with self._loopThreadLock:
                        if control.stop:
                            toStop = True;
                            continue;
                    self._voteManager.Update();
                            
                    endTime = time();
                    frameTime = endTime - startTime;
                    sleepTime = tickTime - frameTime;
                    if sleepTime < 0:
                        sleepTime = 0;
                    sleep(tickTime);
            except KeyboardInterrupt:
                Log.info("Interrupt recieved in RTE.");
                self.Stop();
            except Exception as e:
                Log.error(f"Error occurred in {threading.current_thread()}: Type: {type(e)}; Reason: {e}; Traceback: {traceback.format_exc()}")
                continue

    def Start(self) -> bool:
        #Log.info("Starting RTE...");
        startTime = time()
        targetPlugin = self._serverData.API.GetPlugin("plugins.private.ScoreTracker.st");
        if targetPlugin != None:
            xprts = targetPlugin.GetExports();
            if xprts != None:
                self._GetConquestGame = xprts.Get("GetCurrentCampaignGame").pointer;

        targetPlugin = self._serverData.API.GetPlugin("plugins.private.GalacticConquest.gc");
        if targetPlugin != None:
            xprts = targetPlugin.GetExports();
            if xprts != None:
                getCampaigns = xprts.Get("GetCampaigns").pointer;
                getTeamconfigs = xprts.Get("GetTeamconfigs").pointer;
                getTcByName    = xprts.Get("GetTcByName").pointer;
                if getCampaigns != None and getTeamconfigs != None and getTcByName != None:
                    self._campaigns = getCampaigns();
                    self._teamconfigs = getTeamconfigs();
                    self._getTcByName = getTcByName;
                    for camp in self._campaigns:
                        self._goodTeamConfigs[camp] = list[RTE.EraTeamconfig]();
                        self._evilTeamConfigs[camp] = list[RTE.EraTeamconfig]();
                        tcList = [];
                        for tc in self._teamconfigs:
                            if RTE.EraTeamconfig.IsEraTeamconfigName(tc.GetFilename()):
                                etc = RTE.EraTeamconfig(tc);
                                if camp.GetEraStr() == etc.GetEraStr():
                                    tcList.append(etc);
                                    etc._SetCampaign(camp)
                        if len(tcList) > 0:
                            self._eraTeamConfigs[camp] = tcList.copy();
                            for ttc in tcList:
                                if ttc.GetTeamId() == teams.TEAM_GOOD:
                                    self._goodTeamConfigs[camp].append(ttc);
                                elif ttc.GetTeamId() == teams.TEAM_EVIL:
                                    self._evilTeamConfigs[camp].append(ttc);
                            tcList.clear();
                else:
                    Log.error("Missing mandatory dependancy from Galactic Conquest Plugin.");
                    return False;
        
        campaignThread = Thread(target=self._GetCurrentServerCampaign, args=())
        campaignThread.start()
        campaignThread.join()
        self._isRunning = True;
        self._loopThread.start();
        self._ToggleSelfCampaignMode(False, campaignRotation="intermission")
        self._serverData.interface.SetCvar("campaign", "1" if self._campaignMode else "0")
        self._serverData.SetServerVar("votesInProgress", [])
        allClients = self._serverData.API.GetAllClients();
        for cl in allClients:
            self._OnNewPlayer(player.Player(cl));
        self._serverData.interface.Say(self.config.cfg["MessagePrefix"] + "RTE started in %.2f seconds!" % (time() - startTime))
        Log.info("RTE started in %.2f seconds!" % (time() - startTime))   # have to do this bullshit because there's no native python function to truncate a decimal
        return True;


PluginInstance = None;

# Called once when this module ( plugin ) is loaded, return is bool to indicate success for the system
def OnInitialize(serverData : serverdata.ServerData, exports = None) -> bool:
    logMode = logging.INFO;
    if serverData.args.debug:
        logMode = logging.DEBUG;
    if serverData.args.logfile != "":
        logging.basicConfig(
        filename=serverData.args.logfile,
        level=logMode,
        format='%(asctime)s %(levelname)08s %(name)s %(message)s')
    else:
        logging.basicConfig(
        level=logMode,
        format='%(asctime)s %(levelname)08s %(name)s %(message)s')

    global SERVER_DATA;
    SERVER_DATA = serverData; # keep it stored
    #print(str(serverData));
    global PluginInstance;
    PluginInstance = RTE(serverData)
    if exports != None:
        exports.Add("StartRTBVote", PluginInstance.StartRTBVote);
        exports.Add("GetCurrentCampaign", PluginInstance.API_GetCurrentCampaign);
        #exports.Add("GetCurrentTC", PluginInstance.API_GetCurrentTC);
    newVal = []
    rCommands = SERVER_DATA.GetServerVar("registeredCommands")
    if rCommands != None:
        newVal.extend(rCommands)
    for cmd in PluginInstance._commandList[teams.TEAM_GLOBAL]:
        for i in cmd:
            if not i.isdecimal():
                newVal.append((i, PluginInstance._commandList[teams.TEAM_GLOBAL][cmd][0]))
    SERVER_DATA.SetServerVar("registeredCommands", newVal)
    newVal = []
    rCommands = SERVER_DATA.GetServerVar("registeredSmodCommands")
    if rCommands != None:
        newVal.extend(rCommands)
    for i in PluginInstance._smodCommandList:
        for alias in i:
            if not alias.isdecimal():
                newVal.append((alias, PluginInstance._smodCommandList[i][0]))
    SERVER_DATA.SetServerVar("registeredSmodCommands", newVal)
    return True; # indicate plugin load success

# Called once when platform starts, after platform is done with loading internal data and preparing
def OnStart():
    global PluginInstance;
    return PluginInstance.Start();

# Called each loop tick from the system, TODO? maybe add a return timeout for next call
def OnLoop():
    pass
    #print("Calling Loop function from plugin!");

# Called before plugin is unloaded by the system, finalize and free everything here
def OnFinish():
    global PluginInstance;
    PluginInstance.Finish();
    del PluginInstance;

# Called from system on some event raising, return True to indicate event being captured in this module, False to continue tossing it to other plugins in chain
def OnEvent(event) -> bool:
    global PluginInstance;
    #print("Calling OnEvent function from plugin with event %s!" % (str(event)));
    if event.type == godfingerEvent.GODFINGER_EVENT_TYPE_MESSAGE:
        return PluginInstance.OnChatMessage( event.client, event.message, event.teamId );
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_CLIENTCONNECT:
        return PluginInstance.OnClientConnect( event.client);
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_CLIENTCHANGED:
        return PluginInstance.OnClientChange( event.client, event.data );
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_CLIENTDISCONNECT:
        return PluginInstance.OnClientDisconnect( event.client, event.reason );
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_INIT:
        return PluginInstance.OnServerInit(event.data);
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_SHUTDOWN:
        return PluginInstance.OnServerShutdown();
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_KILL:
        return PluginInstance.OnClientKill(event.client, event.victim, event.weaponStr);
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_PLAYER:
        return PluginInstance.OnPlayer(event.client, event.data["text"] if "text" in event.data else "");
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_EXIT:
        return PluginInstance.OnExit(event.data);
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_MAPCHANGE:
        return PluginInstance.OnMapChange(event.mapName, event.oldMapName);
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_SMSAY:
        return PluginInstance.OnSmsay(event.playerName, event.smodID, event.adminIP, event.message)

    return False;
