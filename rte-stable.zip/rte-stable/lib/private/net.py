

import socket;
import threading;
import lib.shared.threadcontrol as threadcontrol;
import lib.private.buffer as buffer;
import logging;
import ctypes;
import sys;
import time;
import queue;

Log = logging.getLogger(__name__);

class SockStat():
    def __init__(self):
        self.bytesRecv = 0;
        self.bytesSent = 0;

class Sock():

    def __init__(self, sock, addr):
        self._sock = sock;
        self._address = addr;
        self._isOpened = False;
        self._bytesSent = 0;
        self._bytesRecv = 0;
    
    @classmethod
    def FromSockAddr(cls, sock, addr):
        return cls(addr, sock);

    def __init__(self, address, sock = None, protocol = socket.SOCK_STREAM, blocking = True, timeout = 0):
        if sock != None:
            self._sock = sock;
        else:
            self._sock = socket.socket(socket.AF_INET, protocol);
            # From official socket docs:
            # If a non-zero value is given, subsequent socket operations will raise a timeout exception if the 
            # timeout period value has elapsed before the operation has completed. If zero is given, the socket 
            # is put in non-blocking mode. If None is given, the socket is put in blocking mode.
            # sock.setblocking(True) is equivalent to sock.settimeout(None)
            # sock.setblocking(False) is equivalent to sock.settimeout(0.0)
            if blocking:
                self._sock.setblocking(blocking);
            else:
                self._sock.settimeout(timeout);
        self._address = address;
        self._isOpened = False;
        self._bytesSent = 0;
        self._bytesRecv = 0;
    
    def __del__(self):
        if self._isOpened:
            self._Close();

    def GetStats(self, ref_SockStatInstance):
        ref_SockStatInstance.bytesRecv = self._bytesRecv;
        ref_SockStatInstance.bytesSent = self._bytesSent;

    def _Open(self):
        if not self._isOpened:
            self._isOpened = True;

    def _Close(self):
        if self._isOpened:
            #self._sock.shutdown(socket.SHUT_RDWR);
            self._sock.close();
            self._isOpened = False;


class ClientSocket(Sock):

    STATUS_CONNECTED = 0;
    STATUS_CLOSED = 1;
    
    @classmethod
    def FromSockAddr(cls, sock, addr):
        return cls(addr, sock)

    def __init__(self, address, sock = None, protocol = socket.SOCK_STREAM, blocking = True, timeout = 0):
        super().__init__(address, sock, protocol, blocking, timeout);
        self._status = ClientSocket.STATUS_CLOSED;
        self._obufLock = threading.Lock();
        self._obuf = buffer.Buffer(2048);
    
    def _Open(self):
        if not self._isOpened:
            try:
                #self._sock.bind(('',0)); # all interfaces, any port.
                bb = self._sock.getblocking();
                bt = self._sock.gettimeout();
                self._sock.settimeout(5 if (bt < 5) else bt); # crunch to make sure it will connect, because connecting with non-blocking is not supported by WINOS ( ? ) 
                self._sock.setblocking(True);
                self._sock.connect(self._address);
                self._status = ClientSocket.STATUS_CONNECTED;
                super()._Open();
            except socket.error:
                Log.info("Exception on establishing client socket connection %s", str(sys.exc_info()));
                self._sock.settimeout(bt);
                self._sock.setblocking(bb);
            except socket.timeout:
                Log.info("Exception on establishing client socket connection %s", str(sys.exc_info()));

    def _Close(self):
        super()._Close();
    
    def GetStatus(self):
        return self._status;

    def Start(self):
        self._Open();
    
    def Stop(self):
        if self._isOpened:
            self._Close();
            self._status = ClientSocket.STATUS_CLOSED;
    
    def LockOutput(self):
        self._obufLock.acquire();
    
    def UnlockOutput(self):
        self._obufLock.release();
    
    def GetOutputBuf(self) -> buffer.Buffer:
        return self._obuf;

    def Read(self, count = 1024) -> buffer.Buffer:
        if self._isOpened:
            try:
                bb = self._sock.recv(count);
                if bb == '':
                    self.Stop();
                else:
                    return buffer.Buffer(target=bytearray(bb));
            except socket.timeout:
                return None;
            except socket.error:
                return None;
        return None;

    def Flush(self):
        if self._isOpened:
            try:
                toSend = 0;
                bb = None;
                with self._obufLock:
                    toSend = self._obuf.GetEffective();
                    bb = self._obuf.Read(toSend);
                    self._obuf.Drop(); # clean output buf
                sent = 0;
                total = toSend;
                while toSend > 0:
                    sent += self._sock.send(bb[sent:total]);
                    toSend -= sent;
                self._bytesSent += sent;
            except socket.error:
                Log.info("Error on socket sending.");
            except socket.timeout:
                pass;

    def __repr__(self):
        return "[Client Socket] " + str(self._sock) + " : " + str(self._address);


class ServerSocket(Sock):

    class Imports():
        def __init__(self):
            self._onNewConnection = None;
            self._onConnectionClosed = None;
            self._onRecieved = None;
    
    class SS_Event():
        def __init__(self, connection, data = {}):
            self._connection = connection;
            self._data = data;
    
    class SEvent_OnConnection(SS_Event):
        def __init__(self, connection, data={}):
            super().__init__(connection, data)

    class SS_Event_OnClosedConnection(SS_Event):
        def __init__(self, connection, data={}):
            super().__init__(connection, data)

    class SS_Event_OnRecieved(SS_Event):
        def __init__(self, connection, data={}):
            super().__init__(connection, data)
    
    def __init__(self, address, processFps = 60, protocol = socket.SOCK_STREAM, timeout = 0, imports : Imports = None):
        self._base = super();
        self._base.__init__(address, None, protocol, True, timeout);
        self._imports = imports;
        self._processFps = processFps;
        self._processFrameTime = 1 / processFps;

        self._connections = list[ClientSocket](); # list of connections active
        self._connectionsLock = threading.Lock();

        self._listenControlLock = threading.Lock();
        self._listenControl = threadcontrol.ThreadControl();
        self._listenThread = threading.Thread(target=self._ThreadListener, daemon=True, args=(self._listenControl,));

        self._processControlLock = threading.Lock();
        self._processControl = threadcontrol.ThreadControl();
        self._processThread = threading.Thread(target=self._ThreadProcess, daemon=True, args=(self._processControl,));
    
        self._eventsLock = threading.Lock();
        self._events = queue.Queue();
        #self._events = list[ServerSocket.SS_Event]();
    
    def __del__(self):
        self._Close();

    def _Open(self):
        if not self._isOpened:
            self._sock.bind(self._address);
        self._base._Open();

    def _Close(self):
        self._base._Close();
        if self._isOpened:
            #self._sock.shutdown(socket.SHUT_RDWR);
            with self._listenControlLock:
                self._listenControl.stop = True;
            with self._processControlLock:
                self._processControl.stop = True;
            
            # force exception raise, just in case, we need it.
            ids = [self._listenThread.native_id, self._processThread.native_id];
            for i in range(len(ids)):
                print("Terminating thread id " + str(ids[i]));
                res = ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_long(ids[i]),
                    ctypes.py_object(SystemExit))
                if res > 1:
                    ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_long(ids[i]), 0)
                    print('Exception raise failure')

            Log.debug("Waiting for network threads to join.");
            self._listenThread.join();
            self._processThread.join();
            Log.debug("Network threads joined.");
    
    def _OnNewConnection(self, connection : ClientSocket):
        if self._imports._onNewConnection != None:
            self._imports._onNewConnection(self, connection);

    def _OnConnectionClosed(self, connection : ClientSocket):
        if self._imports._onConnectionClosed != None:
            self._imports._onConnectionClosed(self, connection);
    
    def _OnRecieved(self, connection : ClientSocket, buf : buffer.Buffer):
         if self._imports._onRecieved != None:
            self._imports._onRecieved(self, connection, buf);
    
    def Update(self): # to call from main thread and grab generated events;
        while True:
            try:
                ev = self._events.get(False);
                if ev != None:
                    evtype = type(ev);
                    if evtype == ServerSocket.SS_Event_OnRecieved:
                        self._OnRecieved(ev._connection, ev._data["bb"]);
                        continue;
                    if evtype == ServerSocket.SEvent_OnConnection:
                        self._OnNewConnection(ev._connection);
                        continue;
                    if evtype == ServerSocket.SS_Event_OnClosedConnection:
                        self._OnConnectionClosed(ev._connection);
                        continue;
                    else:
                        continue;
                else:
                    break;
            except queue.Empty:
                break;
        
    def Start(self):
        self._Open();
        self.StartListen();
        self._processThread.start();
    
    def Stop(self):
        Log.debug("Stopping network interface...");
        self._Close();
        Log.debug("Stopped network interface.");
    
    def StartListen(self):
        if self._isOpened:
            Log.info("Starting listening on %s", self._address);
            self._sock.listen();
            self._listenThread.start();
    
    def CloseConnection(self, connection : ClientSocket):
        with self._connectionsLock:
            if connection in self._connections:
                self._connections.remove(connection);
                connection.Stop();

        with self._eventsLock:
                self._events.put(ServerSocket.SS_Event_OnClosedConnection(connection));
        
    def _ThreadListener(self, control):
        try:
            while True:
                toStop = False;
                with self._listenControlLock:
                    toStop = control.stop;
                if toStop:
                    break;

                connSock, addr = self._sock.accept();
                connSock.settimeout(0); # 0 for server connections socket, socket.error exception = no data available at the time.
                #connSock.setblocking(True); # make it blocking, we're multithreadin'
                cs = ClientSocket.FromSockAddr(connSock, addr);
                cs._isOpened = True; # crunch, fix;
                cs._status = ClientSocket.STATUS_CONNECTED;
                with self._connectionsLock:
                    self._connections.append(cs);
                Log.debug("New connection established : %s", cs);
                with self._eventsLock:
                    self._events.put(ServerSocket.SEvent_OnConnection(cs));
    
        except SystemExit:
            print("System exit exception raised on network listen thread, fucking off.");
        except Exception:
            print("Some exception raised on network listen thread, closing. %s" % ( str(sys.exc_info()) ));
        finally:
            print("Finished network listen thread");

    def _ThreadProcess(self, control):
        index = 0;
        try:
            while True:
                startTime = time.time();
                toStop = False;
                with self._processControlLock:
                    toStop = control.stop;
                if toStop:
                    break;
                
                targetConn = None;
                l = 0;
                with self._connectionsLock:
                    l = len(self._connections);
                    if l > 0:
                        targetConn = self._connections[index];
                index += 1;        
                if index >= l:
                    index = 0;
                
                if targetConn != None:
                    # process input
                    bts = None;
                    while True:
                        try:
                            bts = targetConn._sock.recv(1024);
                            Log.debug(str(bts));
                            if bts == b'':
                                break;
                            else:
                                if bts != b'': # actual data, not disconnect signal
                                    with self._eventsLock:
                                        self._events.put( ServerSocket.SS_Event_OnRecieved(targetConn, {"bb":buffer.Buffer(target=bytearray(bts))}) );
                                    targetConn._bytesRecv += len(bts);
                                break;
                                
                        except socket.timeout:
                            Log.debug("Socket exception on timeout.");
                            break;
                        except SystemExit:
                            Log.debug("System exit on recv");
                            break;
                        except socket.error: # nothing is there to read
                            break;

                    if bts != None:
                        # something recieved;
                        if bts == b'':
                            # client closed the connection
                            Log.debug("Client %s has closed the connection.", str(targetConn));
                            self.CloseConnection(targetConn);
                                
                endTime = time.time();
                frameTime = endTime - startTime;
                sleepTime = self._processFrameTime - frameTime;
                if sleepTime < 0:
                    sleepTime = 0;
                time.sleep(sleepTime);
            
        except SystemExit:
            print("System exit exception raised on network process thread, fucking off.");
        except Exception:
            print("Some exception raised on network listen thread, closing.");
        finally:
            print("Finished network process thread.");
        


