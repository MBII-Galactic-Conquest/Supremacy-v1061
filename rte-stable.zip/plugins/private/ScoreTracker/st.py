
import lib.shared.serverdata as serverdata;
import logging;
import godfingerEvent;
import lib.shared.config as config;
import json;
import lib.shared.client as client;
import lib.shared.player as player
import lib.shared.teams as teams;
import pluginExports;
import datetime;
import threading;
import time;
import lib.shared.timeout as timeout;
import lib.shared.colors as colors;
import plugins.private.GalacticConquest.gcTeamConfig as GcTeamconfig;
import lib.shared.util as util;
import random;
import math;
import os;

CONFIG_DEFAULT_PATH = os.path.join(os.path.dirname(__file__), "stconfig.json");
global stConfig
stConfig = config.Config.fromJSON(CONFIG_DEFAULT_PATH)
CONFIG_FALLBACK = \
"""{
    "scorePerKill":1,
    "scorePerSuicide":0,
    "pointsPerScore":5,
    "scalePointsWithPop":true,
    "scalePointsMode":"linear",
    "pointsLimit":2000,
    "killsToAnnounce":10,
    "startingPoints":
    [
        500,
        500
    ],
    "pointLimitTransition" : {
        "enabled" : true,
        "map" : "gc_intermission",
        "siegeteam1" : "INT_Soldier",
        "siegeteam2" : "INT_Officer"
    },
    "resetOnEmpty":true,
    "startingTickets":50,
    "popTicketBonus" :
    {
        "enabled" : true,
        "threshold" : 16,
        "amount" : 50
    },
    "ticketExhaustPoints":
    [
        50,
        100
    ],
    "ticketDiminishThreshold": 15,
    "lowTicketSounds": {
        "IMPS_WINNING": [
            "sound/sup/bf/1_IMPS_WINNING.mp3",
            "sound/sup/bf/2_IMPS_WINNING.mp3"
        ],
        "IMPS_LOSING": [
            "sound/sup/bf/1_IMPS_LOSING.mp3",
            "sound/sup/bf/2_IMPS_LOSING.mp3"
        ],
        "REBS_WINNING": [
            "sound/sup/bf/1_REBS_WINNING.mp3",
            "sound/sup/bf/2_REBS_WINNING.mp3"
        ],
        "REBS_LOSING": [
            "sound/sup/bf/1_REBS_LOSING.mp3",
            "sound/sup/bf/2_REBS_LOSING.mp3"
        ]
    },
    "depletionAnnounce": {
        "enabled": false
    }
}
"""
SERVER_DATA = None;
Args = None;
Log = logging.getLogger(__name__);

global BONUSES_DATA;
BONUSES_DATA_PATH = os.path.join(os.path.dirname(__file__), "../../../data/Bonuses.json");
BONUSES_DATA = config.Config.fromJSON(BONUSES_DATA_PATH).cfg;


class ScoreTracker(object):

    class Round():
        def __init__(self):
            self.id = -1;
            self.scoreRed = 0;
            self.scoreBlue = 0;
            self.mapName = "";
            self.startDate = datetime.datetime.now(datetime.timezone.utc).strftime("%d/%m/%Y %H:%M:%S UTC+0");
            self.endDate = "";
            self.winner = -1;
        
        def Reset(self):
            self.id = -1;
            self.scoreRed = 0;
            self.scoreBlue = 0;
            self.mapName = "";
            self.startDate = datetime.datetime.now(datetime.timezone.utc).strftime("%d/%m/%Y %H:%M:%S UTC+0");
            self.endDate = "";
            self.winner = -1;

        def __str__(self):
            return self.__repr__();

        def __repr__(self):
            return "Game Round :\n { id %s\n scores %d %d\n mapName %s\n startDate %s\n endDate %s\n winner %d }\n"  % ( self.id, self.scoreRed, self.scoreBlue, self.mapName, self.startDate, self.endDate, self.winner);


    class CampaignGame():
        def __init__(self):
            self.id = -1;
            self.pointsRed = 0;
            self.pointsBlue = 0;
            # reinforcements
            self.ticketsRed = 0;
            self.ticketsBlue = 0;
            self.startDate = datetime.datetime.now(datetime.timezone.utc).strftime("%d/%m/%Y %H:%M:%S UTC+0");
            self.endDate = "";
            self.winner = -1;
            self.lock = threading.Lock();
        
        def Reset(self):
            self.id = -1;
            self.pointsRed = 0;
            self.pointsBlue = 0;
            # reinforcements
            self.ticketsRed = 0;
            self.ticketsBlue = 0;
            self.startDate = datetime.datetime.now(datetime.timezone.utc).strftime("%d/%m/%Y %H:%M:%S UTC+0");
            self.endDate = "";
            self.winner = -1;
            self.lock = threading.Lock();
        
        def IsValid(self) -> bool:
            return self.id != -1;

        def __str__(self):
            return self.__repr__();

        def __repr__(self):
            return "Campaign Game :\n { id %s\n scores %d %d\n startDate %s\n endDate %s\n winner } %d\n" % ( self.id, self.pointsRed, self.pointsBlue, self.startDate, self.endDate, self.winner);

    def Finish(self):
        if not self.isFinished:
            self.isFinished = True;

    def __del__(self):
        self.Finish();

    def __init__(self, serverData : serverdata.ServerData):
        startTime = time.time();
        global stConfig;
        self._serverData = serverData;
        self._config : config.Config = stConfig;
        if self._config == None: # failed to load existing
            # handle config-less init
            Log.error("Missing stconfig.json, creating a fallback one, close the app, modify stconfig.json and come back")
            self.config = config.Config()
            self.config.cfg = json.loads(CONFIG_FALLBACK)
            f = open(CONFIG_DEFAULT_PATH, "wt")
            f.write(CONFIG_FALLBACK)
            f.close()

        self._database = serverData.API.GetDatabase("Godfinger");
        self._database.ExecuteQuery("""CREATE TABLE IF NOT EXISTS ConquestGames (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        pointsRed INTEGER DEFAULT 0,
        pointsBlue INTEGER DEFAULT 0,
        startDate TEXT NOT NULL,
        endDate TEXT DEFAULT NULL,
        winner INTEGER DEFAULT -1
        );""");

        self._database.ExecuteQuery("""CREATE TABLE IF NOT EXISTS Rounds (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        scoreRed INTEGER DEFAULT 0,
        scoreBlue INTEGER DEFAULT 0,
        mapName TEXT DEFAULT NULL,
        startDate TEXT NOT NULL,
        endDate TEXT DEFAULT NULL,
        winner INTEGER DEFAULT -1
        );""");

        #self._isCampaign = bool(serverData.GetServerVar("campaignMode"));
        self._campaignGame : ScoreTracker.CampaignGame = ScoreTracker.CampaignGame();
        self._announceTicks = 0;
        #if self._isCampaign:
        self._CampGameFromDb(self._campaignGame);
        self._ResetGamePoints(self._campaignGame);
        self._ResetGameTickets(self._campaignGame);
        self._announceCommandTimeout = timeout.Timeout();
        self._ticketsCommandTimeout = timeout.Timeout();
        # Added flags to prevent repeated low ticket alerts
        self._alerted_red_low_tickets = False
        self._alerted_blue_low_tickets = False

        #self._AnnounceTeamPoints();
        self._StartRTBVote = None;
        self._GetCurrentCampaign = None;
        self._rtbVoteStarted = False;

        self._round : ScoreTracker.Round = None;
        self._currentCamp = None;
        self.isFinished = False;
        self._commandList = \
        {
            # commands and aliases must be tuples because lists are unhashable apparently
            # index 0 : tuple of aliases for each command
            # index 1: tuple of help string and handler function
            teams.TEAM_GLOBAL : {
                tuple(["credits", "cr"]) : ("!<credits | cr> - display team credit values", self.HandleDisplayPoints),
                tuple(["tickets", "tkts"]) : ("!<tickets | tkts> - display team ticket values", self.HandleDisplayTickets),
            },
            teams.TEAM_EVIL : {
            },
            teams.TEAM_GOOD : {
            },
            teams.TEAM_SPEC : {
            }
        }
        self._smodCommandList = \
        {
            tuple(["rcred", "resetcredits"]) : ("!<rcred | resetcredits> - reset credit values of both teams", self.HandleResetPoints),
            tuple(["scred", "setcredits"]) : ("!<scred | setcredits> [team]  - set credit values of either team (r/b)", self.HandleSetPoints),
            tuple(["rtkt", "resettickets"]) : ("!<rtkt | resettickets> - reset ticket values of both teams", self.HandleResetTickets),
            tuple(["stkt", "settickets"]) : ("!<stkt | settickets> - set ticket values of both teams", self.HandleSetTickets),
            tuple(["help"]) : ("!help [command] - display info about a command or lists all commands if no command given", self.HandleSmodHelp),
        }

        self._redClients = [];
        self._blueClients = [];
        self._totalActiveClients = 0;

        self._serverData.interface.Say("^5[ST]^7: " + "ST started in %.2f seconds!" % (time.time() - startTime));
        #Log.info("ST started in %.2f seconds!" % (time.time() - startTime));


    def OnClientKill(self, client : client.Client, victim : client.Client, weaponStr):
        if client is not None and victim is not None:
            if client is victim:
                # suicide
                pass;
            else:
                # actual kill
                tt = (client.GetTeamId(), victim.GetTeamId());
                if tt[0] != tt[1]:
                    # different teams
                    Log.debug("Total players %d"%self._totalActiveClients);
                    totalScore = self._config.cfg["scorePerKill"];
                    killerTeam = tt[0];
                    if killerTeam == teams.TEAM_GOOD:
                        self._round.scoreRed += totalScore;
                    elif killerTeam == teams.TEAM_EVIL:
                        self._round.scoreBlue += totalScore;
                    #if self._isCampaign:
                    if not self._rtbVoteStarted:
                        self._announceTicks +=1;
                    # process campaign specific stuff
                    with self._campaignGame.lock:
                        totalPoints = totalScore * self._config.cfg["pointsPerScore"];
                        #Log.debug("Total points base %d" % totalPoints);
                        if self._config.cfg["scalePointsWithPop"]:
                            totalPoints = util.Clamp(1, math.ceil(totalPoints - totalPoints * ( ( ( self._totalActiveClients * 100 ) / self._serverData.maxPlayers ) / 100 ) ), totalPoints );
                            Log.debug("Total points modified %d ; ratio %f " % (totalPoints, ( ( self._totalActiveClients * 100 ) / self._serverData.maxPlayers ) / 100 ) );
                        if killerTeam == teams.TEAM_GOOD and not self._rtbVoteStarted:
                            self._campaignGame.pointsRed += totalPoints;
                            self._campaignGame.ticketsBlue = max(self._campaignGame.ticketsBlue - 1, 0)
                            # if self._campaignGame.ticketsBlue % 5 == 0:
                            #     self._AnnounceTickets()
                        elif killerTeam == teams.TEAM_EVIL and not self._rtbVoteStarted:
                            self._campaignGame.pointsBlue += totalPoints;
                            self._campaignGame.ticketsRed = max(self._campaignGame.ticketsRed - 1, 0)
                            # if self._campaignGame.ticketsRed % 5 == 0:
                            #     self._AnnounceTickets()
                        if self._config.cfg['depletionAnnounce']["enabled"]:
                            self.CheckTicketsDiminishing()
                        if self._campaignGame.pointsRed >= self._config.cfg["pointsLimit"] or self._campaignGame.pointsBlue >= self._config.cfg["pointsLimit"]:
                            winnerTeam = colors.ColorizeText('Red', 'red') if self._campaignGame.pointsRed > self._config.cfg["pointsLimit"] else colors.ColorizeText('Blue', 'blue')
                            # Handle point limit transition based on pointLimitTransition config
                            if self._config.cfg['pointLimitTransition']["enabled"] == True:
                                self._serverData.interface.SvSay(f"^5[ST]:^7 {colors.ColorizeText('VICTORY!', 'green')} {winnerTeam} team reached the credit limit! Resetting game...")
                                self._serverData.interface.SvSound("sound/sup/bloop.mp3")
                                time.sleep(1.5)
                                self._serverData.interface.SvSay("^9* Server Sound Invoked *")
                                if self._campaignGame.pointsRed >= self._config.cfg["pointsLimit"]:
                                    if self._campaignGame.pointsBlue >= self._config.cfg["pointsLimit"]:
                                        return;
                                    rebsID = teams.TEAM_GOOD
                                    impsID = teams.TEAM_EVIL
                                    self._serverData.interface.TeamSound("sound/sup/bf/VICTORY.mp3", rebsID)
                                    self._serverData.interface.TeamSound("sound/sup/bf/DEFEAT.mp3", impsID)
                                else:
                                    pass;
                                if self._campaignGame.pointsBlue >= self._config.cfg["pointsLimit"]:
                                    if self._campaignGame.pointsRed >= self._config.cfg["pointsLimit"]:
                                        return;
                                    rebsID = teams.TEAM_GOOD
                                    impsID = teams.TEAM_EVIL
                                    self._serverData.interface.TeamSound("sound/sup/bf/VICTORY.mp3", impsID)
                                    self._serverData.interface.TeamSound("sound/sup/bf/DEFEAT.mp3", rebsID)
                                else:
                                    pass;
                                time.sleep(8.5)
                                self._serverData.interface.SvSound("sound/sup/countdown.mp3")
                                self._serverData.interface.SvSay("^55..")
                                time.sleep(1)
                                self._serverData.interface.SvSay("^54..")
                                time.sleep(1)
                                self._serverData.interface.SvSay("^53..")
                                time.sleep(1.5)
                                self._serverData.interface.SvSay("^52..")
                                time.sleep(1)
                                self._serverData.interface.SvSay("^51..")
                                time.sleep(2)
                                self._serverData.interface.BatchExecute("b", [
                                    f"g_siegeteam1 {self._config.cfg['pointLimitTransition']['siegeteam1']}",
                                    f"g_siegeteam2 {self._config.cfg['pointLimitTransition']['siegeteam2']}",
                                    f"map {self._config.cfg['pointLimitTransition']['map']}"
                                ])
                            else: # If pointLimitTransition is not enabled, just announce and reset points
                                self._serverData.interface.SvSay(f"^5[ST]:^7 {winnerTeam} Point Limit reached!");
                            self._ResetGamePoints()
                            self._AnnounceTeamPoints();
                        
                        if self._announceTicks >= self._config.cfg["killsToAnnounce"]:
                            self._announceTicks = 0;
                            self._AnnounceTickets()
                            self._AnnounceTeamPoints();
                    
                    if not self._rtbVoteStarted:
                        if self._campaignGame.ticketsBlue <= 0 or self._campaignGame.ticketsRed <= 0:
                            if self._campaignGame.ticketsRed <= 0:
                                self._serverData.interface.SvSay("^5[ST]:^1 Red team has been depleted of their tickets!");
                                if self._config.cfg['depletionAnnounce']["enabled"]:
                                    self.TotallyDepletedSounds();
                                    time.sleep(12)
                                self._campaignGame.pointsBlue += self._config.cfg["ticketExhaustPoints"][1];
                                self._campaignGame.pointsRed  += self._config.cfg["ticketExhaustPoints"][0];
                            if self._campaignGame.ticketsBlue <= 0:
                                self._serverData.interface.SvSay("^5[ST]:^5 Blue team has been depleted of their tickets!");
                                if self._config.cfg['depletionAnnounce']["enabled"]:
                                    self.TotallyDepletedSounds();
                                    time.sleep(12)
                                self._campaignGame.pointsBlue += self._config.cfg["ticketExhaustPoints"][0];
                                self._campaignGame.pointsRed  += self._config.cfg["ticketExhaustPoints"][1];
                            self._StartRTBVote();
                            self._rtbVoteStarted = True;
                else:
                    # teamkill
                    pass;


    def CheckTicketsDiminishing(self):
        diminish_threshold = self._config.cfg["ticketDiminishThreshold"]
        all_low_ticket_sounds = self._config.cfg["lowTicketSounds"]

        red_tickets = self._campaignGame.ticketsRed
        blue_tickets = self._campaignGame.ticketsBlue

        # Assign team IDs to input for TeamSound, referenced in remoteconsole.py
        rebsID = teams.TEAM_GOOD
        impsID = teams.TEAM_EVIL

        # RED TEAM (REBS)
        if red_tickets <= diminish_threshold and not self._alerted_red_low_tickets:
            # REBS is losing
            # 1. REBS losing sound
            rebs_losing_sounds = all_low_ticket_sounds.get("REBS_LOSING", [])
            if rebs_losing_sounds:
                selected_rebs_losing = random.choice(rebs_losing_sounds)
                self._serverData.interface.SvSay(f"^5[ST]:^7 {colors.ColorizeText('Red Team (REBS) tickets are critically low!', 'red')}")
                #time.sleep(3)
                self._serverData.interface.TeamSound(selected_rebs_losing, rebsID)
                Log.info(f"Playing REBS losing sound: {selected_rebs_losing}")
            else:
                Log.warning("No REBS losing sounds found.")

            # 2. IMPS winning sound
            imps_winning_sounds = all_low_ticket_sounds.get("IMPS_WINNING", [])
            if imps_winning_sounds:
                selected_imps_winning = random.choice(imps_winning_sounds)
                self._serverData.interface.TeamSound(selected_imps_winning, impsID)
                Log.info(f"Playing IMPS winning sound: {selected_imps_winning}")
            else:
                Log.warning("No IMPS winning sounds found.")

            self._alerted_red_low_tickets = True

        elif red_tickets > diminish_threshold and self._alerted_red_low_tickets:
            self._alerted_red_low_tickets = False

        # BLUE TEAM (IMPS)
        if blue_tickets <= diminish_threshold and not self._alerted_blue_low_tickets:
            # IMPS is losing
            # 1. IMPS losing sound
            imps_losing_sounds = all_low_ticket_sounds.get("IMPS_LOSING", [])
            if imps_losing_sounds:
                selected_imps_losing = random.choice(imps_losing_sounds)
                self._serverData.interface.SvSay(f"^5[ST]:^7 {colors.ColorizeText('Blue Team (IMPS) tickets are critically low!', 'lblue')}")
                #time.sleep(3)
                self._serverData.interface.TeamSound(selected_imps_losing, impsID)
                Log.info(f"Playing IMPS losing sound: {selected_imps_losing}")
            else:
                Log.warning("No IMPS losing sounds found.")

            # 2. REBS winning sound
            rebs_winning_sounds = all_low_ticket_sounds.get("REBS_WINNING", [])
            if rebs_winning_sounds:
                selected_rebs_winning = random.choice(rebs_winning_sounds)
                self._serverData.interface.TeamSound(selected_rebs_winning, rebsID)
                Log.info(f"Playing REBS winning sound: {selected_rebs_winning}")
            else:
                Log.warning("No REBS winning sounds found.")

            self._alerted_blue_low_tickets = True

        elif blue_tickets > diminish_threshold and self._alerted_blue_low_tickets:
            self._alerted_blue_low_tickets = False

    def TotallyDepletedSounds(self):
        options = [
            lambda: self._serverData.interface.SvSound("sound/sup/bf/1_DEPLETED.mp3"),
            lambda: self._serverData.interface.SvSound("sound/sup/bf/2_DEPLETED.mp3"),
            lambda: self._serverData.interface.SvSound("sound/sup/bf/3_DEPLETED.mp3")
        ]

        choice = random.choice(options)()

        if choice:
            return choice
        else:
            Log.error("Invalid depletedSounds")
            return False;

    def IncrementPoints(self, teamId):
        pass;
    
    def Start(self):
        rtbPlugin = self._serverData.API.GetPlugin("plugins.private.RTE.rtePlugin");
        if rtbPlugin != None:
            xprts = rtbPlugin.GetExports();
            if xprts != None:
                self._StartRTBVote = xprts.Get("StartRTBVote").pointer;
                self._GetCurrentCampaign = xprts.Get("GetCurrentCampaign").pointer;
            else:
                Log.error("Failure at importing API from RTE Plugin.");
                return False;
        else:
            Log.error("Failure in getting RTE Plugin.");
            return False;
        return True;

    def OnClientConnect(self, cl : client.Client )-> bool:
        return False;

    def OnClientBegin(self, cl : client.Client ) -> bool:
        # if the client is in team, it means it went spectator while being dead
        # if cl in self._redClients:
        #     self._redClients.remove(cl);
        #     self._totalActiveClients -= 1;
        # elif cl in self._blueClients:
        #     self._blueClients.remove(cl);
        #     self._totalActiveClients -= 1;
        return False;

    def OnClientDisconnect(self, cl : client.Client, reason : int):
        #if self._isCampaign:
        if reason != godfingerEvent.ClientDisconnectEvent.REASON_SERVER_SHUTDOWN:
            if self._config.cfg["resetOnEmpty"]:
                if self._serverData.API.GetClientCount() <= 1: # 1 means thats the last client
                    #self._SaveCampToDb(self._campaignGame);
                    self._ResetGamePoints(self._campaignGame);
                    Log.debug("Score tracking resetting campaign points since all players disconnected.");
            teamId = cl.GetTeamId();
            if teamId == teams.TEAM_GOOD:
                if cl in self._redClients:
                    self._redClients.remove(cl);
                    self._totalActiveClients -= 1;
            elif teamId == teams.TEAM_EVIL:
                if cl in self._blueClients:
                    self._blueClients.remove(cl);
                    self._totalActiveClients -= 1;
        
    def _ResetGamePoints(self, cGame : CampaignGame):
        if cGame != None:
            cGame.pointsRed = self._config.cfg["startingPoints"][0];
            cGame.pointsBlue = self._config.cfg["startingPoints"][1];

    def _SetTeamPoints(self, team : int, val : int, cGame : CampaignGame):
        if cGame != None:
            if team == teams.TEAM_GOOD or team == "r":
                cGame.pointsRed = val
            elif team == teams.TEAM_EVIL or team == "b":
                cGame.pointsBlue = val
    
    def _ResetGameTickets(self, cGame : CampaignGame):
        popBonusEnabled = self._config.cfg["popTicketBonus"]["enabled"]
        popBonusAmount = self._config.cfg["popTicketBonus"]["amount"]
        popBonusThreshold = self._config.cfg["popTicketBonus"]["threshold"]
        ticketsToSetRed = ticketsToSetBlue = self._config.cfg["startingTickets"]
        if cGame != None:
            if popBonusEnabled and len(self._serverData.API.GetAllClients()) >= popBonusThreshold:
                ticketsToSetRed += popBonusAmount
                ticketsToSetBlue += popBonusAmount
            cGame.ticketsRed = ticketsToSetRed
            cGame.ticketsBlue = ticketsToSetBlue
        # Reset alert flags when tickets are reset
        self._alerted_red_low_tickets = False
        self._alerted_blue_low_tickets = False
        # Conditionally call the ticket depletion check after reset
        if self._config.cfg['depletionAnnounce']["enabled"]:
            self.CheckTicketsDiminishing()


    def _SetTeamTickets(self, team : int, val : int, cGame : CampaignGame):
        if cGame != None:
            if team == teams.TEAM_GOOD:
                cGame.ticketsRed = val
            elif team == teams.TEAM_EVIL:
                cGame.ticketsBlue = val
        # Conditionally call the ticket depletion check after setting tickets manually
        if self._config.cfg['depletionAnnounce']["enabled"]:
            self.CheckTicketsDiminishing()

    def OnMapChange(self, mapName, oldMapName):
        self._ResetGameTickets(self._campaignGame);
        self._rtbVoteStarted = False;
        teamStr1 = self._serverData.interface.GetTeam1().strip();
        teamStr2 = self._serverData.interface.GetTeam2().strip();
        bonus1 = GcTeamconfig.GcTeamConfig.GetBonusStringFromName(teamStr1);
        bonus2 = GcTeamconfig.GcTeamConfig.GetBonusStringFromName(teamStr2);
        self._campaignGame.ticketsRed  += BONUSES_DATA["TicketsBonuses"][bonus1.lower()];
        self._campaignGame.ticketsBlue += BONUSES_DATA["TicketsBonuses"][bonus2.lower()];
        # Conditionally call the ticket depletion check after map change and ticket adjustments
        #if self._config.cfg['depletionAnnounce']["enabled"]:
        #    self.CheckTicketsDiminishing()
        return False;

    def OnInitGame(self, vars : dict):
        #self._ProcessCampaignMode();
        round = self._round;
        if round == None:
            round = self._round = ScoreTracker.Round();
            round.mapName = self._serverData.mapName;
        else:
            self.SaveGameState();
            mapName = round.mapName;
            round.Reset();
            round.mapName = mapName;
        rq = self._database.ExecuteQuery("SELECT id FROM Rounds ORDER BY id DESC LIMIT 1;", 1)

        nextId = 1 if len(rq) == 0 else rq[0][0] + 1 ; # because its a list of tuples god damn it
        round.id = nextId;

        Log.debug("New round starting %s" % str(round));

        if self._serverData.API.GetServerVar("RTBMapChange"): # workaround, until plugins implement observer pattern
            self.OnMapChange("", "");

        self._redClients.clear();
        self._blueClients.clear();
        self._totalActiveClients = 0;

        return False;

    def OnClientSpawn(self, client, vars : dict):
        if "team" in vars:
            teamId = teams.TranslateTeam(vars["team"]);
            if teamId == teams.TEAM_GOOD:
                if client in self._blueClients:
                    self._blueClients.remove(client);
                    self._totalActiveClients -= 1;
                self._redClients.append(client);
                self._totalActiveClients += 1;
            elif teamId == teams.TEAM_EVIL:
                if client in self._redClients:
                    self._redClients.remove(client);
                    self._totalActiveClients -= 1;
                self._blueClients.append(client);
                self._totalActiveClients += 1;

    def OnClientChanged(self, client, data : dict ):
        #Log.debug("Client changed Event recived %s" % str(data));
        if "team" in data:
            newTeamId = client.GetTeamId();
            self.MoveTeam(client, data["team"], newTeamId);
        Log.debug("Total active clients %d" % int(self._totalActiveClients));
        return False;

    def MoveTeam(self, client, teamOld, teamNew):
        if teamOld != teamNew:
            if teamOld == teams.TEAM_GOOD:
                if client in self._redClients:
                    self._redClients.remove(client);
                    self._totalActiveClients -= 1;
            elif teamOld == teams.TEAM_EVIL:
                if client in self._blueClients:
                    self._blueClients.remove(client);
                    self._totalActiveClients -= 1;
            elif teamOld == teams.TEAM_SPEC:
                pass;

            if teamNew == teams.TEAM_GOOD:
                self._redClients.append(client);
                self._totalActiveClients += 1;
            elif teamNew == teams.TEAM_EVIL:
                self._blueClients.append(client);
                self._totalActiveClients += 1;
            elif teamNew == teams.TEAM_SPEC:
                pass;


    def OnShutdownGame(self):
        round = self._round;
        self.SaveGameState();
        Log.debug("Ending round %s" % str(round));
        round.Reset();
        return False;

    def OnPostInit(self):
        camp = self._GetCurrentCampaign();
        #Log.debug("Previous camp %s vs now camp %s"%(self._currentCamp, camp));
        if camp != self._currentCamp:
            # camp changed
            self._ResetGamePoints(self._campaignGame);
            self._currentCamp = camp;
        return False;

    def HandleDisplayPoints(self, player : player.Player, teamId : int, cmdArgs : list[str]):
        if not self._announceCommandTimeout.IsSet():
            with self._campaignGame.lock:
                self._AnnounceTeamPoints();
            self._announceCommandTimeout.Set(3);
        return True;

    def HandleDisplayTickets(self, player : player.Player, teamId : int, cmdArgs : list[str]):
        if not self._ticketsCommandTimeout.IsSet():
            with self._campaignGame.lock:
                self._AnnounceTickets();
            self._ticketsCommandTimeout.Set(3);
        return True;

    def HandleResetPoints(self, player, smodId, adminIp, cmdArgs):
        self._serverData.interface.SvSay("^5[ST] ^7: Credits Pool reset by server admin.");
        self._ResetGamePoints(self._campaignGame);
        return True; # captured

    def HandleSetPoints(self, player, smodId, adminIp, cmdArgs):
        if len(cmdArgs) > 2 and cmdArgs[1] in ["1", "2", "r", "b"] and cmdArgs[2].isdecimal():
            if cmdArgs[1] == "r":
                cmdArgs[1] = "1"
            elif cmdArgs[1] == "b":
                cmdArgs[1] = "2" 
            self._SetTeamPoints(int(cmdArgs[1]), int(cmdArgs[2]), self._campaignGame)
            teamStr = colors.ColorizeText("Red", "red") if cmdArgs[1] == "1" else colors.ColorizeText("Blue", "blue")
            self._serverData.interface.SvSay("^5[ST] ^7: " + teamStr + " team points set to " + cmdArgs[2]);
        return True

    def HandleSmodHelp(self, playerName, smodId, adminIP, cmdArgs):
        capture = True
        commandAliasList = self._serverData.GetServerVar("registeredSmodCommands")
        if len(cmdArgs) > 1:
            for i in commandAliasList:
                if cmdArgs[1] == i[0]:
                    saystr = i[1]
                    self._serverData.interface.smsay("^5[ST] ^7: " + saystr)
                    return capture
            # couldn't find command
            self._serverData.interface.smsay("^5[ST] ^7: " + colors.ColorizeText(f"Couldn't find smod command {cmdArgs[1]}", "yellow"))
        else:
            saystr = ', '.join([x[0] for x in commandAliasList])
            if len(saystr) > 100:
                a = []
                s = ""
                for i in commandAliasList:
                    if len(s) + len(i) > 100:
                        a += [f"smsay {'^5[ST] ^7: ' + s[:-2]}"]
                        s = ""
                    s += i[0] + ", "
                if len(s) > 0:
                    a += [f"smsay {'^5[ST] ^7: ' + s[:-2]}"]
                if len(a) > 0:
                    self._serverData.interface.BatchExecute("b", a)
                # self._serverData.rcon.smsay("^5[ST] ^7: " + colors.ColorizeText("(!help <command> for more): ", "yellow") + saystr)
            else:
                self._serverData.interface.smsay("^5[ST] ^7: " + colors.ColorizeText("(!help <command> for more): ", "yellow") + saystr)
        return capture

    def HandleResetTickets(self, playerName, smodId, adminIP, cmdArgs):
        self._ResetGameTickets(self._campaignGame);
        self._serverData.interface.SvSay("^5[ST] ^7: Tickets were reset by server admin.");
        return True; # captured

    def HandleSetTickets(self, player, smodId, adminIp, cmdArgs):
        if len(cmdArgs) > 2 and cmdArgs[1] in ["1", "2", "r", "b"] and cmdArgs[2].isdecimal():
            if cmdArgs[1] == "r":
                cmdArgs[1] = "1"
            elif cmdArgs[1] == "b":
                cmdArgs[1] = "2" 
            self._SetTeamTickets(int(cmdArgs[1]), int(cmdArgs[2]), self._campaignGame)
            teamStr = colors.ColorizeText("Red", "red") if cmdArgs[1] == "1" else colors.ColorizeText("Blue", "blue")
            self._serverData.interface.SvSay("^5[ST] ^7: " + teamStr + " team tickets set to " + cmdArgs[2]);
        return True

    def HandleChatCommand(self, player : player.Player, teamId : int, cmdArgs : list[str]) -> bool:
        if len(cmdArgs) > 0:
            command = cmdArgs[0]
            if command.startswith("!"):
                # TODO: Make this an actual config option
                if command.startswith("!"):
                    command = command[len("!"):]
            for c in self._commandList[teamId]:
                if command in c:
                    return self._commandList[teamId][c][1](player, teamId, cmdArgs)
        return False

    def HandleSmodCommand(self, playerName, smodId, adminIP, cmdArgs):
        command = cmdArgs[0]
        if command.startswith("!"):
            # TODO: Make this an actual config option
            if command.startswith("!"):
                command = command[len("!"):]
        for c in self._smodCommandList:
            if command in c:
                return self._smodCommandList[c][1](playerName, smodId, adminIP, cmdArgs)
        return False

    def OnMessage(self, client, message, teamId) -> bool:
        message = message.lower()
        messageParse = message.split()
        if teamId == teams.TEAM_GLOBAL:
            return self.HandleChatCommand(None, teamId, messageParse)
        return False;

    def OnSmsay(self, senderName : str, smodID : int, senderIP : str, message : str):
        message = message.lower()
        messageParse = message.split()
        return self.HandleSmodCommand(senderName, smodID, senderIP, messageParse)

    def _AnnounceTickets(self):
        tr = 0;
        tb = 0;

        tr = self._campaignGame.ticketsRed;
        tb = self._campaignGame.ticketsBlue;
        self._serverData.interface.SvSay("^5[ST] ^7Reinforcements Tickets : ^7(^1%d^7/^5%d^7)" % (tr, tb));
            
    def _AnnounceTeamPoints(self):
        pr = 0;
        pb = 0;

        pr = self._campaignGame.pointsRed;
        pb = self._campaignGame.pointsBlue;
        self._serverData.interface.SvSay("^5[ST] ^7Credits Pool : ^7(^1%d^7/^5%d^7)" % (pr, pb));
        self._serverData.interface.SvSound("sound/sup/planetzoom.mp3")
    
    def SaveGameState(self):
        if self._round != None:
            round = self._round;
            if round.id != -1:
                # actual game instance
                # save state to database
                round.endDate = datetime.datetime.now(datetime.timezone.utc).strftime("%d/%m/%Y %H:%M:%S UTC+0");
                fmt = """INSERT INTO Rounds (id, scoreRed, scoreBlue, mapName, startDate, endDate, winner)
                VALUES ("%d", "%d", "%d", "%s", "%s", "%s", "%d");""" % (round.id, round.scoreRed, round.scoreBlue, round.mapName, round.startDate, round.endDate, round.winner);
                self._database.ExecuteQuery(fmt);

    # def _ProcessCampaignMode(self):
    #     isCampaign = bool(self._serverData.API.GetServerVar("campaignMode")); # update camp mode
    #     if self._isCampaign and not isCampaign: # turning off
    #         if self._campaignGame != None:
    #             Log.debug("Turning off campaign mode.");
    #             self._SaveCampToDb(self._campaignGame);
    #             Log.debug("Ending campaign game %s" % str(self._campaignGame));
    #             self._campaignGame.Reset();
    #             self._ResetGamePoints(self._campaignGame);
    #     elif not self._isCampaign and isCampaign: # turning on
    #         Log.debug("Turning on campaign mode.");
    #         self._CampGameFromDb(self._campaignGame);
    #     self._isCampaign = isCampaign;

    def _CampGameFromDb(self, campGame):
        rq = self._database.ExecuteQuery("SELECT id FROM ConquestGames ORDER BY id DESC LIMIT 1;", 1)
        nextId = 1 if len(rq) == 0 else rq[0][0] + 1 ; #
        campGame.id = nextId;

    def _SaveCampToDb(self, campGame):
        campGame.endDate = datetime.datetime.now(datetime.timezone.utc).strftime("%d/%m/%Y %H:%M:%S UTC+0");
        fmt = """INSERT INTO ConquestGames (id, pointsRed, pointsBlue, startDate, endDate, winner)
        VALUES ("%d", "%d", "%d", "%s", "%s", "%s");""" % (campGame.id, campGame.pointsRed, campGame.pointsBlue, campGame.startDate, campGame.endDate, campGame.winner);
        #Log.debug("FMT " + fmt );
        self._database.ExecuteQuery(fmt);

PluginInstance : ScoreTracker = None;

def API_GetCurrentCampaignGame():
    global PluginInstance;
    return PluginInstance._campaignGame;

def API_GetCurrentRound():
    global PluginInstance;
    return PluginInstance._round;

# DISCLAIMER : DO NOT LOCK ANY OF THESE FUNCTIONS, IF YOU WANT MAKE INTERNAL LOOPS FOR PLUGINS - MAKE OWN THREADS AND MANAGE THEM, LET THESE FUNCTIONS GO.

# Called once when this module ( plugin ) is loaded, return is bool to indicate success for the system
def OnInitialize(serverData : serverdata.ServerData, exports = None) -> bool:
    logMode = logging.INFO;
    if serverData.args.debug:
        logMode = logging.DEBUG;
    if serverData.args.logfile != "":
        logging.basicConfig(
        filename=serverData.args.logfile,
        level=logMode,
        format='%(asctime)s %(levelname)08s %(name)s %(message)s')
    else:
        logging.basicConfig(
        level=logMode,
        format='%(asctime)s %(levelname)08s %(name)s %(message)s')

    global SERVER_DATA;
    SERVER_DATA = serverData; # keep it stored
    global Args;
    Args = serverData.args;
    global PluginInstance;
    try:
        if PluginInstance != None:
            del PluginInstance;
    except:
        pass
    PluginInstance = ScoreTracker(serverData);
    if exports != None:
        exports.Add("GetCurrentCampaignGame", API_GetCurrentCampaignGame);
        exports.Add("GetCurrentRound", API_GetCurrentRound);
    newVal = []
    rCommands = SERVER_DATA.GetServerVar("registeredCommands")
    if rCommands != None:
        newVal.extend(rCommands)
    for cmd in PluginInstance._commandList[teams.TEAM_GLOBAL]:
        for i in cmd:
            if not i.isdecimal():
                newVal.append((i, PluginInstance._commandList[teams.TEAM_GLOBAL][cmd][0]))
    SERVER_DATA.SetServerVar("registeredCommands", newVal)
    newVal = []
    rCommands = SERVER_DATA.GetServerVar("registeredSmodCommands")
    if rCommands != None:
        newVal.extend(rCommands)
    for i in PluginInstance._smodCommandList:
        for alias in i:
            if not alias.isdecimal():
                newVal.append((alias, PluginInstance._smodCommandList[i][0]))
    SERVER_DATA.SetServerVar("registeredSmodCommands", newVal)

    return True; # indicate plugin load success

# Called once when platform starts, after platform is done with loading internal data and preparing
def OnStart():
    return PluginInstance.Start();

# Called each loop tick from the system, TODO? maybe add a return timeout for next call
def OnLoop():
    pass
    #print("Calling Loop function from plugin!");

# Called before plugin is unloaded by the system, finalize and free everything here
def OnFinish():
    global PluginInstance;
    if PluginInstance != None:
        del PluginInstance;

# Called from system on some event raising, return True to indicate event being captured in this module, False to continue tossing it to other plugins in chain
def OnEvent(event) -> bool:
    global PluginInstance;
    #print("Calling OnEvent function from plugin with event %s!" % (str(event)));
    if event.type == godfingerEvent.GODFINGER_EVENT_TYPE_MESSAGE:
        return PluginInstance.OnMessage(event.client, event.message, event.teamId);
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_CLIENTCONNECT:
        return PluginInstance.OnClientConnect(event.client);
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_CLIENT_BEGIN:
        return PluginInstance.OnClientBegin(event.client);
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_CLIENTCHANGED:
        return PluginInstance.OnClientChanged(event.client, event.data);
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_CLIENTDISCONNECT:
        return PluginInstance.OnClientDisconnect(event.client, event.reason);
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_INIT:
        return PluginInstance.OnInitGame(event.data["vars"]);
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_SHUTDOWN:
        return PluginInstance.OnShutdownGame();
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_KILL:
        return PluginInstance.OnClientKill(event.client, event.victim, event.weaponStr);
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_PLAYER:
        return False;
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_PLAYER_SPAWN:
        return PluginInstance.OnClientSpawn(event.client, event.data);
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_EXIT:
        return False;
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_MAPCHANGE:
        return PluginInstance.OnMapChange(event.mapName, event.oldMapName);
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_SMSAY:
        return PluginInstance.OnSmsay(event.playerName, event.smodID, event.adminIP, event.message);
    elif event.type == godfingerEvent.GODFINGER_EVENT_TYPE_POST_INIT:
        return PluginInstance.OnPostInit();

    return False;