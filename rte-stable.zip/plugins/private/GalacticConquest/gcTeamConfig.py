import lib.shared.teamconfig as teamconfig;
import lib.shared.util as util;

class GcTeamConfig(teamconfig.TeamConfig):
    def __init__(self, name = None, pathName = None):
        super().__init__(name, pathName);

    @staticmethod
    def GetBonusStringFromName(name : str) -> str:
        hasBonuses = name.rfind('-')
        if hasBonuses == -1:    # no dash found in file name, implying default bonus config
            return ""
        else:
            return name[hasBonuses + 1:]

    def GetBonusString(self):
        """ 
        Returns the 0-2 character bonus string at the end of the file after dash character.
        Will not work if file name is not formatted correctly (Sup_TeamX-YZ). If attempted with
        phase string, will not return correct results.
        """
        return GcTeamConfig.GetBonusStringFromName(self._filename);

    def GetEraStr(self):
        index = self._filename.find("Sup_")
        if index != -1:
            return self._filename.split('-')[0][8:]
        else:
            return None
        
    TC_PREFIX = "Sup";
    TC_FORMAT_PHASED  = TC_PREFIX+"_{}PH{}{}-{}-{}";  #"Sup_TeamPhaseSubphase-Era-Bonus"
    TC_FORMAT_REGULAR = TC_PREFIX+"_{}{}-{}";       #"Sup_TeamEra-Bonus"
    TC_PHASE_NONE = -1; 
    @classmethod
    def FormString(cls, team : int, phase : int, subphase : int , era : any, bonus : str):
        # team 1 is always Good, 2 is Evil
        result = "";
        side = "";
        if team == 1:
            side = "Good";
        else:
            side = "Evil";
        isPhased = phase != cls.TC_PHASE_NONE; # phase none
        if isPhased:
            phase = str(util.Clamp(1,phase,2));
        # TODO : Implement subphase
        subphase = "";
        eraStr = era.GetEraStr();
        # TODO : Implement bonus
        # Droid siegeteams (Evil2, Evil15) cannot use some bonuses, so S, G, SG, EB, and L would be available
        if isPhased:
            result = cls.TC_FORMAT_PHASED.format(side, phase, subphase, eraStr, bonus);
        else:
            result = cls.TC_FORMAT_REGULAR.format(side, eraStr, bonus);
        
        return result;