import lib.private.campaignrotation as campaignrotation;

# perfectly should be in server files, hardcode for now
ERAS_START = 1;
ERA_GALACTIC_CIVIL_WAR = 1;
ERA_CLONE_WARS = 2;
ERA_MANDALORIAN_WAR = 3;
ERA_JEDI_CIVIL_WAR = 4;
ERA_DARTH_MALGUS = 5;
ERA_THRAWNS_ASCENDANCY = 6;
ERA_FALL_OF_THE_BLACK_SUN = 7;
ERA_RISE_OF_THE_FIRST_ORDER = 8;
ERA_RISE_OF_THE_EXILE = 9;
ERA_RISE_OF_THE_EMPIRE = 10;
ERA_LEGO_STAR_WARS = 11;
ERA_SHADOWS_OF_DATHOMIR = 12;
ERA_HORDES_OF_THE_YUUZHAN_VONG = 13;
ERA_RISE_OF_DARTH_KRAYT = 14;
ERA_CONQUEST_OF_THE_ETERNAL_THRONE = 15;
ERA_CONQUEST_OF_THE_INFINITE_EMPIRE = 16;
ERA_CLONE_WARS_PHASE_2 = 17;
ERAS_END   = 17;

ERAS_LOOKUP = \
{
    ERA_GALACTIC_CIVIL_WAR: "Galactic Civil War",
    ERA_CLONE_WARS: "Clone Wars, Phase I",
    ERA_MANDALORIAN_WAR: "Mandalorian Wars",
    ERA_JEDI_CIVIL_WAR: "Jedi Civil War",
    ERA_DARTH_MALGUS: "Malgus Wars",
    ERA_THRAWNS_ASCENDANCY: "Thrawns Acendancy", 
    ERA_FALL_OF_THE_BLACK_SUN: "Fall of the Black Sun",
    ERA_RISE_OF_THE_FIRST_ORDER: "Rise of the First Order",
    ERA_RISE_OF_THE_EXILE: "Rise of the Exile",
    ERA_RISE_OF_THE_EMPIRE: "Rise of the Empire",
    ERA_LEGO_STAR_WARS: "Lego Star Wars",
    ERA_SHADOWS_OF_DATHOMIR: "Shadows of Dathomir",
    ERA_HORDES_OF_THE_YUUZHAN_VONG: "Yuuzhan Vong Wars",
    ERA_RISE_OF_DARTH_KRAYT: "Rise of Darth Krayt",
    ERA_CONQUEST_OF_THE_ETERNAL_THRONE: "Eternal Empire Wars",
    ERA_CONQUEST_OF_THE_INFINITE_EMPIRE: "Infinite Empire Wars",
    ERA_CLONE_WARS_PHASE_2 : "Clone Wars, Phase II"
};

class GcCampaignRotation(campaignrotation.CampaignRotation):
    def __init__(self, name, id, vars = {}, srcPk = None):
        super().__init__(name, id, vars, srcPk);
        index = name.find("_");
        if index != -1:
            self._eraStr = name[:index];
        else:
            self._eraStr = "1"; # defaults to if not set in filename
        self._eraVerbose = ERAS_LOOKUP[int(self._eraStr)];

    def GetNameVerbose(self):
        return "" + self._eraVerbose;

    def GetEraStr(self) -> str:
        return "" + self._eraStr;
