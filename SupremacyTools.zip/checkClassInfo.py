import os
import datetime

def check_mbch_files_for_classinfo(start_directory='.'):
    """
    Recursively searches for .mbch files in the specified directory and its subdirectories.
    Flags files that do not contain the string "ClassInfo".
    Prints a summary to the console and writes it to a log file.

    Args:
        start_directory (str): The directory to start the search from. Defaults to the current directory.
    """
    flagged_files = []
    total_mbch_files_checked = 0
    log_filename = "mbch_check_log.log"

    print(f"Starting search for .mbch files in: {os.path.abspath(start_directory)}")
    print("-" * 50)

    for root, _, files in os.walk(start_directory):
        for file in files:
            if file.endswith(".mbch"):
                file_path = os.path.join(root, file)
                total_mbch_files_checked += 1
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                        if "ClassInfo" not in content:
                            flagged_files.append(file_path)
                            print(f"FLAGGED: '{file_path}' (does not contain 'ClassInfo')")
                        else:
                            print(f"OK: '{file_path}' (contains 'ClassInfo')")
                except Exception as e:
                    print(f"ERROR: Could not read file '{file_path}'. Reason: {e}")
                    # Optionally add errored files to a separate list if needed
                    continue

    print("-" * 50)
    print("\n--- Summary ---")
    print(f"Total .mbch files checked: {total_mbch_files_checked}")
    print(f"Total files flagged (missing 'ClassInfo'): {len(flagged_files)}")

    if flagged_files:
        print("\nFlagged Files Paths:")
        for path in flagged_files:
            print(f"- {path}")
    else:
        print("\nNo .mbch files were flagged (all contained 'ClassInfo').")

    # Write results to log file
    with open(log_filename, 'w', encoding='utf-8') as log_file:
        log_file.write(f"MBCH File ClassInfo Check Log - {datetime.datetime.now()}\n")
        log_file.write("-" * 50 + "\n")
        log_file.write(f"Search started in: {os.path.abspath(start_directory)}\n\n")

        if total_mbch_files_checked == 0:
            log_file.write("No .mbch files found in the specified directory or its subdirectories.\n")
        else:
            log_file.write(f"Total .mbch files checked: {total_mbch_files_checked}\n")
            log_file.write(f"Total files flagged (missing 'ClassInfo'): {len(flagged_files)}\n\n")

            if flagged_files:
                log_file.write("Flagged Files Paths:\n")
                for path in flagged_files:
                    log_file.write(f"- {path}\n")
            else:
                log_file.write("No .mbch files were flagged (all contained 'ClassInfo').\n")

    print(f"\nDetailed log saved to: {os.path.abspath(log_filename)}")
    print("Script finished.")


if __name__ == "__main__":
    # Call the function to start the check.
    # By default, it will start from the current directory where the script is run.
    check_mbch_files_for_classinfo()
    # You can specify a different starting directory if needed:
    # check_mbch_files_for_classinfo('/path/to/your/specific/folder')
