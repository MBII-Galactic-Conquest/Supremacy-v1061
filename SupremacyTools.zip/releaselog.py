import subprocess
import datetime
import os

def generate_release_log():
    """
    Generates a comprehensive release log including current date and
    a verbose record of all file changes from the Git history.
    The log is saved to a file named SUPREMACY-RELEASE-YYYYMMDD-HHMMSS.txt.
    """
    # 1. Get current date and time for filename and log content
    now = datetime.datetime.now()
    timestamp = now.strftime("%Y%m%d-%H%M%S")
    current_date_str = now.strftime("%Y-%m-%d %H:%M:%S")

    # Define the output filename
    output_filename = f"SUPREMACY-RELEASE-{timestamp}.txt"

    # Try to open the file for writing.
    # Use utf-8 encoding to handle various characters in commit messages/filenames.
    try:
        with open(output_filename, 'w', encoding='utf-8') as f:
            f.write("========================================================\n")
            f.write(f"           SUPREMACY RELEASE LOG - {current_date_str}   \n")
            f.write("========================================================\n\n")

            f.write("1. CURRENT DATE AND TIME:\n")
            f.write(f"   {current_date_str}\n\n")

            f.write("2. GIT REPOSITORY STATUS (Uncommitted/Staged Changes):\n")
            try:
                # Get the output of 'git status --porcelain' for current working directory status
                # --porcelain gives an easy-to-parse format
                git_status_output = subprocess.check_output(
                    ['git', 'status', '--porcelain'],
                    text=True,
                    stderr=subprocess.PIPE,
                    encoding='utf-8'
                ).strip()
                if git_status_output:
                    f.write("   The following files have unstaged or staged changes:\n")
                    for line in git_status_output.splitlines():
                        f.write(f"   {line}\n")
                else:
                    f.write("   No uncommitted or staged changes detected.\n")
            except subprocess.CalledProcessError as e:
                f.write(f"   Error getting git status: {e.stderr.strip()}\n")
                f.write("   Please ensure you are in a Git repository and Git is installed.\n")
            except FileNotFoundError:
                f.write("   Git command not found. Please ensure Git is installed and in your system's PATH.\n")
            f.write("\n")


            f.write("3. GIT COMMIT HISTORY WITH FILE CHANGES (Verbose Log):\n")
            f.write("   This section lists each commit along with the status (Added, Modified, Deleted, etc.)\n")
            f.write("   and the paths of files affected by that commit.\n\n")
            try:
                # Use 'git log' to get detailed commit information including file changes.
                # --name-status: shows status (A, M, D, R) and name of changed files
                # --pretty=format: specifies the output format for each commit
                #   %H: commit hash
                #   %ad: author date
                #   %s: subject (commit message)
                # --date=iso: formats the date in ISO format
                # --all: includes all branches
                git_log_command = [
                    'git', 'log', '--name-status',
                    '--pretty=format:Commit: %H%nDate: %ad%nSubject: %s%n---Changed Files---',
                    '--date=iso', '--all'
                ]
                git_log_output = subprocess.check_output(
                    git_log_command,
                    text=True,
                    stderr=subprocess.PIPE,
                    encoding='utf-8'
                )
                f.write(git_log_output)

            except subprocess.CalledProcessError as e:
                f.write(f"   Error getting git log: {e.stderr.strip()}\n")
                f.write("   Please ensure you are in a Git repository and Git is installed.\n")
            except FileNotFoundError:
                f.write("   Git command not found. Please ensure Git is installed and in your system's PATH.\n")

            f.write("\n========================================================\n")
            f.write("                END OF RELEASE LOG                    \n")
            f.write("========================================================\n")

        print(f"Release log successfully generated: {output_filename}")

    except IOError as e:
        print(f"Error writing to file {output_filename}: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    generate_release_log()
