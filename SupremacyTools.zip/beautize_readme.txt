python beautize.py . ^
^ being:
--no-blank-lines
--tab-width
--ignore-file *.json