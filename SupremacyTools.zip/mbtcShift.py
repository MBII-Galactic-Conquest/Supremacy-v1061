import os
import re
import logging

# === CONFIGURATION ===

LOG_FILE = "mbtc_class_insertion.log"
MAX_CLASSES_ALLOWED = 6
MAX_SUBCLASSES_PER_BLOCK = 11

# === SETUP LOGGING ===
logging.basicConfig(
    filename=LOG_FILE,
    filemode='a',
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# === UTILITY FUNCTIONS ===

def find_mbtc_files(base_dir):
    mbtc_files = []
    for root, _, files in os.walk(base_dir):
        for file in files:
            if file.lower().endswith('.mbtc'):
                mbtc_files.append(os.path.join(root, file))
    return mbtc_files

def parse_blocks(lines):
    """
    Parses lines into blocks.
    Returns dict of block_name -> (start_line_idx_of_open_brace, end_line_idx_of_close_brace, lines_inside_block)
    This version correctly handles empty lines or comment-only lines between block name and its opening brace.
    """
    blocks = {}
    block_name = None
    brace_level = 0
    block_start = None # This will be the index of the line containing the opening brace '{'

    i = 0
    while i < len(lines):
        line_raw = lines[i]
        # Strip whitespace and comments after //
        line = re.sub(r'//.*', '', line_raw).strip()

        if block_name is None:
            # Look for block start line: "BlockName"
            m = re.match(r'^(\w+)', line, re.IGNORECASE)
            if m:
                candidate_block = m.group(1)
                if '{' in line:
                    # Block name and { are on the same line
                    block_name = candidate_block
                    block_start = i
                    brace_level = line.count('{') - line.count('}')
                    i += 1
                    continue
                else:
                    # Block name found, now scan subsequent lines for the opening brace
                    temp_i = i + 1 # Start scanning from the next line
                    found_brace = False
                    while temp_i < len(lines):
                        next_line = re.sub(r'//.*', '', lines[temp_i]).strip()
                        if next_line == '{':
                            # Found the opening brace for the candidate block
                            block_name = candidate_block
                            block_start = temp_i # The block's content starts after this brace
                            brace_level = 1
                            i = temp_i + 1 # Continue main loop from after the brace line
                            found_brace = True
                            break # Exit inner while loop, found the brace
                        elif next_line:
                            # Found non-empty, non-brace content before the brace, so it's not a block start
                            break
                        temp_i += 1 # Move to the next line to check for brace
                    
                    if found_brace: # If a block was successfully identified (name + brace)
                        continue # Continue the main loop to process block content
        
        # If we are inside a block (block_name is not None)
        else:
            brace_level += line.count("{")
            brace_level -= line.count("}")

            if brace_level == 0:
                block_end = i # This is the line containing the closing brace '}'
                content_start = block_start + 1 # Content starts after the opening brace
                content_end = block_end       # Content ends before the closing brace
                block_content = lines[content_start:content_end]
                blocks[block_name] = (block_start, block_end, block_content)
                block_name = None
                block_start = None
        i += 1
    return blocks

def extract_class_entries(block_lines, prefix):
    """
    Extract entries where keys start with prefix (case-insensitive).
    Returns list of tuples (index_in_block_lines, full_line, key, value).
    """
    entries = []
    pattern = re.compile(r'^(\w+\d+)\s+"([^"]+)"')
    for i, line in enumerate(block_lines):
        # Ensure 'line' is a string before calling .strip()
        if not isinstance(line, str):
            logging.warning(f"Non-string item found in block_lines: {line}. Skipping.")
            continue
        line_strip = line.strip()
        m = pattern.match(line_strip)
        if m:
            key, val = m.groups()
            if key.lower().startswith(prefix.lower()):
                entries.append((i, line, key, val))
    return entries

def find_class_entry(blocks, search_value):
    """
    Search all Classes and Subclasses blocks for entry with value == search_value.
    Return (block_name, key, index_in_block_lines) or None if not found.
    """
    for block_name, (_, _, content) in blocks.items():
        # Determine the correct prefix based on block name
        prefix = "class" if block_name.lower().startswith("classes") else "subclass"
        entries = extract_class_entries(content, prefix)
        for idx, _, key, val in entries:
            if val == search_value:
                return (block_name, key, idx)
    return None

def update_classes_allowed(lines, new_count):
    """
    Update ClassesAllowed line in the file.
    Return True if updated.
    """
    updated = False
    for i, line in enumerate(lines):
        # Look for ClassesAllowed at the start of a stripped line
        if line.strip().lower().startswith("classesallowed"):
            # Ensure we only replace the number, keeping indentation and comments
            parts = line.split()
            if len(parts) >= 2:
                # Assuming the format is "ClassesAllowed N"
                # Keep original leading whitespace
                original_indent = re.match(r'^\s*', line).group(0)
                # Reconstruct the line with the new count, preserving comments if any
                comment_part = ""
                if "//" in line:
                    comment_part = " " + line.split("//", 1)[1].strip() # Get comment part
                
                lines[i] = f"{original_indent}ClassesAllowed {new_count}{comment_part}\n"
                updated = True
                break
    return updated

def insert_or_shift_entry(entries, insert_pos, new_value, prefix):
    """
    Insert new_value at insert_pos (1-based) into entries list (list of (key, value)).
    Shift entries after insert_pos down by 1, renumbering keys accordingly.
    Returns new list of (key, value).
    """
    # Ensure insert_pos is within valid bounds for appending or inserting
    if insert_pos < 1:
        insert_pos = 1
    # If insert_pos is beyond the end, it means append
    if insert_pos > len(entries) + 1:
        insert_pos = len(entries) + 1

    new_entries = []
    inserted = False

    # Iterate through existing entries to build the new list
    # Use enumerate with a custom start to handle 1-based indexing for prefixes
    for i, (old_key, old_val) in enumerate(entries, start=1):
        if i == insert_pos:
            # Insert the new entry at the desired position
            new_entries.append((f"{prefix}{insert_pos}", new_value))
            inserted = True
            # The current entry (old_key, old_val) now shifts down
            new_entries.append((f"{prefix}{i+1}", old_val))
        elif i < insert_pos:
            # Elements before the insert position retain their original key and value
            new_entries.append((old_key, old_val))
        else: # i > insert_pos
            # Elements after the insert position shift down by one and are renumbered
            new_entries.append((f"{prefix}{i+1}", old_val))

    # If the new entry was supposed to be appended (insert_pos was > current length)
    if not inserted:
        # Appends to the end using the calculated insert_pos
        new_entries.append((f"{prefix}{len(entries) + 1}", new_value))

    return new_entries

def build_block_lines(entries, indent=""):
    """
    Build block lines from entries list (key, value), adding an indent for formatting.
    Ensures consistent spacing like "class1  "value"".
    """
    lines = []
    # Find the maximum key length to align the quotes
    max_key_len = 0
    if entries:
        max_key_len = max(len(key) for key, _ in entries)

    for key, val in entries:
        # Calculate padding needed to align quotes
        padding = " " * (max_key_len - len(key) + 2) # At least 2 spaces
        lines.append(f'{indent}{key}{padding}"{val}"\n')
    return lines

def find_or_create_subclass_block(blocks, block_name, lines, insert_after_line_idx):
    """
    Returns (start, end, content) of subclass block.
    Creates block if missing after insert_after_line_idx (index of line after which to insert).
    If created, the lines list is modified in place.
    """
    if block_name in blocks:
        logging.debug(f"Block '{block_name}' already exists.")
        return blocks[block_name]

    logging.debug(f"Block '{block_name}' not found, attempting to create it after line {insert_after_line_idx}.")
    new_block_lines = [
        f"\n", # Add an empty line before the new block for separation
        f"{block_name}\n",
        f"{{\n",
        f"}}\n"
    ]

    # The insert_pos should always be at least `len(lines)` if `insert_after_line_idx` is the last line.
    # So, clamp `insert_pos` to `len(lines)` to ensure it doesn't go out of bounds.
    insert_pos = min(insert_after_line_idx + 1, len(lines))
    
    # Insert the new block lines into the main lines list
    for offset, l in enumerate(new_block_lines):
        lines.insert(insert_pos + offset, l)
    logging.debug(f"Inserted new lines for block '{block_name}' into main content. Lines now: {len(lines)}")

    # Re-parse blocks after insertion to get the correct new indices for the created block
    new_blocks = parse_blocks(lines)
    
    # Ensure the newly created block is now in the parsed blocks
    if block_name in new_blocks:
        logging.debug(f"Successfully created and parsed new block '{block_name}'.")
        return new_blocks[block_name]
    else:
        logging.error(f"Failed to find newly created block '{block_name}' after insertion and re-parsing. This is unexpected.")
        return None # Or raise an error, depending on desired robustness

def get_class_prefix(class_entries, lines=None):
    """
    Extract the prefix from class entries in form s_<prefix>_suffix.
    Returns prefix including 's_' and trailing underscore.
    If no valid prefix found from entries, try to read from top comment.
    If still no prefix, return a default.
    """
    # 1. Try to get prefix from existing class entries
    for _, _, _, val in class_entries: # Unpack to ignore index, full_line, key
        if val.startswith("s_"):
            first_uscore_after_s = val.find('_', 2)
            last_uscore = val.rfind('_')
            
            if first_uscore_after_s != -1 and last_uscore != -1 and last_uscore >= first_uscore_after_s:
                return val[:last_uscore+1]
    
    # 2. If no prefix found from entries, try to read from the top comment
    if lines and len(lines) > 0:
        first_line = lines[0].strip()
        match = re.match(r'^//Supremacy Class Prefix: (s_.*?_)', first_line)
        if match:
            return match.group(1)

    # 3. Default fallback prefix if none found
    return "s_###_" 

def update_prefix_comment(lines, prefix_value):
    """
    Adds or updates a comment on the first line indicating the detected prefix.
    """
    comment_line = f"//Supremacy Class Prefix: {prefix_value}\n"
    
    if len(lines) > 0 and lines[0].strip().startswith('//Supremacy Class Prefix:'):
        # Update existing comment
        lines[0] = comment_line
    else:
        # Insert new comment at the beginning
        lines.insert(0, comment_line)
    return True # Indicate lines were modified

def remove_subclass_block_range(lines, block_name_to_remove):
    """
    Removes a specific SubclassesForClass# block, including its name, braces, and //1-11 comment.
    Returns True if the block was found and removed, False otherwise.
    Modifies the lines list in place.
    """
    modified = False
    blocks_snapshot = parse_blocks(lines) # Get fresh block info

    if block_name_to_remove in blocks_snapshot:
        block_start_brace_idx, block_end_brace_idx, _ = blocks_snapshot[block_name_to_remove]
        
        log_action("N/A", f"Attempting to remove block: {block_name_to_remove}")

        # Find the actual start line of the block definition (e.g., "SubclassesForClass1")
        block_def_start_idx = block_start_brace_idx # Initialize with brace index
        temp_idx = block_start_brace_idx - 1 # Start checking line before brace
        
        found_name_line = False
        while temp_idx >= 0:
            trimmed_prev_line = re.sub(r'//.*', '', lines[temp_idx]).strip()
            if trimmed_prev_line.lower() == block_name_to_remove.lower(): # Found the block name line
                block_def_start_idx = temp_idx
                found_name_line = True
                break
            elif trimmed_prev_line: # Found non-empty, non-block-name content before the block name
                break
            temp_idx -= 1
        
        if not found_name_line: # Fallback if name line isn't directly above brace
            block_def_start_idx = block_start_brace_idx

        # Determine the end of the removal range (closing brace + optional comment + blank lines)
        # Start scanning from the line *after* the closing brace
        current_scan_idx = block_end_brace_idx + 1
        
        # Advance past any blank lines immediately after the closing brace
        while current_scan_idx < len(lines) and not lines[current_scan_idx].strip():
            current_scan_idx += 1
            
        # If a //1-11 comment is found after blank lines (or immediately after brace)
        if current_scan_idx < len(lines):
            current_scan_line_strip = lines[current_scan_idx].strip()
            if re.match(r'^//\d+-\d+$', current_scan_line_strip):
                current_scan_idx += 1 # Include this comment line
                
        # Advance past any further blank lines after the comment (or after where comment would be)
        while current_scan_idx < len(lines) and not lines[current_scan_idx].strip():
            current_scan_idx += 1

        # The final removal end index is `current_scan_idx`
        final_removal_end_idx = current_scan_idx

        # Perform the actual removal by slicing the list
        del lines[block_def_start_idx:final_removal_end_idx]
        modified = True
        log_action("N/A", f"Successfully removed block: {block_name_to_remove} from lines {block_def_start_idx} to {final_removal_end_idx-1}.")
        
    return modified

def remove_all_subclass_blocks_from_file_content(lines):
    """
    Removes all SubclassesForClass# blocks, including their names, braces,
    and any associated '//1-11' comments and blank lines immediately after them.
    Returns a new list of lines.
    """
    blocks_to_remove_ranges = []
    # Get all subclass blocks and their full ranges
    current_blocks = parse_blocks(lines)
    for block_name, (block_start_brace_idx, block_end_brace_idx, _) in current_blocks.items():
        if block_name.startswith("SubclassesForClass"):
            # Find the actual start line of the block definition (e.g., "SubclassesForClass1")
            block_def_start_idx = block_start_brace_idx
            temp_idx = block_start_brace_idx - 1
            while temp_idx >= 0:
                trimmed_prev_line = re.sub(r'//.*', '', lines[temp_idx]).strip()
                if trimmed_prev_line.lower() == block_name.lower():
                    block_def_start_idx = temp_idx
                    break
                elif trimmed_prev_line:
                    break
                temp_idx -= 1
            
            # Determine the end of the removal range (closing brace + optional comment + blank lines)
            current_scan_idx = block_end_brace_idx + 1
            while current_scan_idx < len(lines) and not lines[current_scan_idx].strip():
                current_scan_idx += 1
            if current_scan_idx < len(lines) and re.match(r'^//\d+-\d+$', lines[current_scan_idx].strip()):
                current_scan_idx += 1
            while current_scan_idx < len(lines) and not lines[current_scan_idx].strip():
                current_scan_idx += 1

            blocks_to_remove_ranges.append((block_def_start_idx, current_scan_idx))

    if not blocks_to_remove_ranges:
        return lines # No blocks to remove, return original lines

    # Sort ranges by their start index to handle overlaps/correct order
    blocks_to_remove_ranges.sort()

    new_lines_content = []
    current_line_idx = 0
    for start_remove, end_remove in blocks_to_remove_ranges:
        # Append lines before the current removal range
        while current_line_idx < start_remove:
            new_lines_content.append(lines[current_line_idx])
            current_line_idx += 1
        # Skip lines within the current removal range
        current_line_idx = max(current_line_idx, end_remove)
    
    # Append any remaining lines after the last removal range
    while current_line_idx < len(lines):
        new_lines_content.append(lines[current_line_idx])
        current_line_idx += 1
        
    return new_lines_content


def clear_all_classes_in_file(file_path):
    """
    Clears all class and subclass entries in a file, resets ClassesAllowed.
    Crucially, it preserves the existing prefix comment from the top of the file.
    It returns this preserved prefix.
    """
    log_action(file_path, "Clearing all class and subclass entries.")
    with open(file_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    # Capture the existing prefix from the file's content *before* any modifications
    original_blocks_for_prefix = parse_blocks(lines)
    original_class_entries_for_prefix = []
    if "Classes" in original_blocks_for_prefix:
        # Only try to extract if Classes block exists and has valid content
        original_class_entries_for_prefix = extract_class_entries(
            original_blocks_for_prefix["Classes"][2], "class"
        )
    preserved_prefix = get_class_prefix(original_class_entries_for_prefix, lines=lines)

    modified = False
    
    # Re-parse blocks after initial read to get fresh indices before modification
    blocks = parse_blocks(lines)

    # 1. Clear content of Classes block and ensure it contains `class1 ""`
    if "Classes" in blocks:
        classes_start_idx, classes_end_idx, _ = blocks["Classes"]
        # Set the content of the Classes block to contain only "class1  ""\n"
        lines[classes_start_idx + 1 : classes_end_idx] = ["class1  \"\"\n"]
        modified = True
        log_action(file_path, "Classes block content cleared to 'class1 \"\"'.")
    else:
        log_action(file_path, "No Classes block found to clear content.")

    # 2. Remove ALL SubclassesForClass# blocks using the new robust function
    initial_lines_copy = list(lines) # Create a copy to pass to the removal function
    lines[:] = remove_all_subclass_blocks_from_file_content(initial_lines_copy)
    if len(lines) != len(initial_lines_copy): # If lines length changed, blocks were removed
        modified = True

    # 3. Update ClassesAllowed in the modified lines
    if update_classes_allowed(lines, 1):
        modified = True

    # 4. Handle the prefix comment at the very top of the file
    if update_prefix_comment(lines, preserved_prefix): 
        modified = True

    # Final cleanup of blank lines after all structural modifications
    final_lines_cleaned = []
    last_line_was_blank = True 

    for line in lines:
        is_current_line_blank = not bool(line.strip())
        
        if not is_current_line_blank:
            final_lines_cleaned.append(line)
            last_line_was_blank = False
        elif not last_line_was_blank: # Keep at most one blank line between content sections
            final_lines_cleaned.append(line)
            last_line_was_blank = True
    
    lines[:] = final_lines_cleaned # Update the original list

    if modified:
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.writelines(lines)
            log_action(file_path, f"File updated successfully after insertion/cleanup.")
        except IOError as e:
            log_action(file_path, f"ERROR: Could not write to file {file_path}. Please check permissions or if the file is open in another program. Error: {e}", level=logging.ERROR)
            print(f"ERROR: Could not write to file {file_path}. Please check permissions or if the file is open in another program. Error: {e}")
            return False # Indicate failure to write
    else:
        log_action(file_path, "No modifications made to file content.")

    return modified # Return the overall modification status (True/False)

def log_action(file_path, message, level=logging.INFO):
    if level == logging.ERROR:
        logging.error(f"{file_path} - {message}")
    else:
        logging.info(f"{file_path} - {message}")

# === MAIN FILE PROCESSING ===

def process_file(file_path, desired_position, new_class_suffix):
    log_action(file_path, f"Processing file for insertion at position {desired_position} with suffix '{new_class_suffix}'")
    
    with open(file_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    # Determine prefix for new class/subclass value (might look at existing classes or top comment)
    temp_blocks_for_prefix = parse_blocks(lines)
    temp_class_entries_for_prefix = []
    if "Classes" in temp_blocks_for_prefix:
        temp_class_entries_for_prefix = extract_class_entries(
            temp_blocks_for_prefix["Classes"][2], "class"
        )
    prefix = get_class_prefix(temp_class_entries_for_prefix, lines=lines)
    
    # Ensure the prefix comment is at the very top of the file, updated with the detected prefix
    modified_prefix_comment = update_prefix_comment(lines, prefix)
    
    # Now, re-parse blocks after the prefix comment might have been added/updated
    blocks = parse_blocks(lines)

    if "Classes" not in blocks:
        log_action(file_path, "No Classes block found after parsing, skipping file modification.")
        return False

    classes_start_idx, classes_end_idx, classes_content = blocks["Classes"]
    
    # Extract existing class entries, converting them to (key, value) tuples for easier manipulation
    class_entries_raw = extract_class_entries(classes_content, "class")
    class_entries = [(key, val) for _, _, key, val in class_entries_raw]

    new_class_value = prefix + new_class_suffix

    # === CRITICAL CHANGE: REMOVED THE `find_class_entry` CHECK HERE ===
    # The previous code:
    # existing_entry = find_class_entry(blocks, new_class_value)
    # if existing_entry is not None:
    #     block_name, key, idx = existing_entry
    #     log_action(file_path, f"Class '{new_class_value}' already exists in block '{block_name}' as '{key}', skipping insertion.")
    #     return False
    # This block was preventing the desired shifting when a value (e.g., 's_15or_y')
    # was already present somewhere else in the file.
    # By removing it, the script will now proceed to insert/shift based on `desired_position` regardless
    # of whether the *value* already exists.

    # Find current ClassesAllowed value
    current_classes_allowed = None
    for line_idx, line in enumerate(lines): 
        if line.strip().lower().startswith("classesallowed"):
            try:
                current_classes_allowed = int(line.strip().split()[1])
            except (IndexError, ValueError):
                current_classes_allowed = None
            break

    if desired_position < 1:
        log_action(file_path, f"Invalid desired_position {desired_position} < 1, skipping.")
        return False

    modified_by_content = False 
    
    # If desired position is within the main Classes block limit (1 to MAX_CLASSES_ALLOWED)
    if desired_position <= MAX_CLASSES_ALLOWED:
        insert_pos_in_block = desired_position # 1-based position within the Classes block

        # Scenario 1: Classes block is full, and new class needs to be inserted within its limit.
        # This requires moving the last class to subclasses.
        if len(class_entries) >= MAX_CLASSES_ALLOWED and insert_pos_in_block <= MAX_CLASSES_ALLOWED:
            last_class_key, last_class_val = class_entries[-1]
            # Remove the last element FROM THE *CURRENT* class_entries list
            # before inserting the new value. This `last_class_val` will then be shifted.
            class_entries_for_main_block = class_entries[:-1] 

            # Insert new class at insert_pos, shifting others within the main block's capacity
            class_entries_for_main_block = insert_or_shift_entry(class_entries_for_main_block, insert_pos_in_block, new_class_value, "class")

            # Renumber classes after insertion/shifting (already handled by insert_or_shift_entry, but ensure consistency)
            class_entries_for_main_block = [(f"class{i}", val) for i, (_, val) in enumerate(class_entries_for_main_block, start=1)]

            subclass_block_name = "SubclassesForClass1"
            
            insert_subclass_block_after_idx = classes_end_idx # Default insert after Classes block
            
            existing_subclass_block_keys = sorted([b for b in blocks.keys() if b.startswith("SubclassesForClass")], 
                                                   key=lambda x: int(re.search(r'\d+', x).group()) if re.search(r'\d+', x) else 0)
            if existing_subclass_block_keys:
                last_existing_subclass_block_key = existing_subclass_block_keys[-1]
                insert_subclass_block_after_idx = blocks[last_existing_subclass_block_key][1]

            subclass_block_info = find_or_create_subclass_block(blocks, subclass_block_name, lines, insert_subclass_block_after_idx)
            if subclass_block_info is None:
                log_action(file_path, f"Failed to get/create subclass block '{subclass_block_name}'. Aborting.")
                return False
            
            # IMPT: Re-parse blocks *again* after find_or_create_subclass_block because it might have modified `lines`
            # and we need the updated indices for `subclass_start_idx`, `subclass_end_idx`.
            blocks = parse_blocks(lines) 
            classes_start_idx, classes_end_idx, _ = blocks["Classes"] # Re-get classes block info as well
            subclass_start_idx, subclass_end_idx, subclass_content = blocks[subclass_block_name]

            subclass_entries_raw = extract_class_entries(subclass_content, "Subclass")
            subclass_entries = [(k, v) for _, _, k, v in subclass_entries_raw]

            # Insert the moved last_class_val into the subclass list at position 1, shifting others
            subclass_entries = insert_or_shift_entry(subclass_entries, 1, last_class_val, "Subclass")
            subclass_entries = [(f"Subclass{i}", val) for i, (_, val) in enumerate(subclass_entries, start=1)]

            # Apply NO INDENT for subclass content
            lines[subclass_start_idx + 1 : subclass_end_idx] = build_block_lines(subclass_entries, indent="")

            # Update lines for Classes block (using the new `class_entries_for_main_block`)
            lines[classes_start_idx + 1 : classes_end_idx] = build_block_lines(class_entries_for_main_block, indent="")
            
            modified_by_content = True
            log_action(file_path, f"Inserted new class '{new_class_value}' at position {insert_pos_in_block} in Classes; moved last class '{last_class_val}' to '{subclass_block_name}' as Subclass1.")

        else: # Classes block is not full, so just insert/shift within main Classes block
            class_entries = insert_or_shift_entry(class_entries, insert_pos_in_block, new_class_value, "class")

            # Renumber them to ensure they are 'class1', 'class2', etc.
            class_entries = [(f"class{i}", val) for i, (_, val) in enumerate(class_entries, start=1)]

            # Main Classes block entries should have no indent
            lines[classes_start_idx + 1 : classes_end_idx] = build_block_lines(class_entries, indent="") 
            modified_by_content = True
            log_action(file_path, f"Inserted new class '{new_class_value}' at position {insert_pos_in_block} in Classes.")

        new_classes_allowed = max(len(class_entries), current_classes_allowed if current_classes_allowed is not None else 0)
        if current_classes_allowed is None or new_classes_allowed > current_classes_allowed:
            update_classes_allowed(lines, new_classes_allowed)
            modified_by_content = True
            log_action(file_path, f"Updated ClassesAllowed from {current_classes_allowed} to {new_classes_allowed}.")

    else: # desired_position > MAX_CLASSES_ALLOWED (This is the subclass generation path)
        subclass_relative_pos = desired_position - MAX_CLASSES_ALLOWED 
        
        block_num = (subclass_relative_pos - 1) // MAX_SUBCLASSES_PER_BLOCK + 1 
        subclass_index_in_block = ((subclass_relative_pos - 1) % MAX_SUBCLASSES_PER_BLOCK) + 1 

        subclass_block_name = f"SubclassesForClass{block_num}"

        # Determine where to insert the new subclass block if it doesn't exist.
        # This should be after the last existing block (Classes or last SubclassesForClassX).
        insert_subclass_block_after_idx = classes_end_idx 
        
        existing_subclass_block_keys = sorted([b for b in blocks.keys() if b.startswith("SubclassesForClass")], 
                                               key=lambda x: int(re.search(r'\d+', x).group()) if re.search(r'\d+', x) else 0)
        if existing_subclass_block_keys:
            last_existing_subclass_block_key = existing_subclass_block_keys[-1]
            # Ensure insert_after_line_idx is based on the *current* state of `lines` after potential modifications.
            insert_subclass_block_after_idx = blocks[last_existing_subclass_block_key][1]


        subclass_block_info = find_or_create_subclass_block(blocks, subclass_block_name, lines, insert_subclass_block_after_idx)
        if subclass_block_info is None:
            log_action(file_path, f"Failed to get/create subclass block '{subclass_block_name}'. Aborting.")
            return False
        
        # IMPT: Re-parse blocks *again* after find_or_create_subclass_block because it might have modified `lines`
        # and we need the updated indices for `subclass_start_idx`, `subclass_end_idx`.
        blocks = parse_blocks(lines) 
        subclass_start_idx, subclass_end_idx, subclass_content = blocks[subclass_block_name]

        subclass_entries_raw = extract_class_entries(subclass_content, "Subclass")
        subclass_entries = [(k, v) for _, _, k, v in subclass_entries_raw]

        # Insert/shift the new subclass entry into the list of subclass entries for this block
        subclass_entries = insert_or_shift_entry(subclass_entries, subclass_index_in_block, new_class_value, "Subclass")

        # Renumber them to ensure they are 'Subclass1', 'Subclass2', etc.
        subclass_entries = [(f"Subclass{i}", val) for i, (_, val) in enumerate(subclass_entries, start=1)]

        # Apply no indent for subclass content
        lines[subclass_start_idx + 1 : subclass_end_idx] = build_block_lines(subclass_entries, indent="")
        modified_by_content = True
        log_action(file_path, f"Inserted new subclass '{new_class_value}' at position {desired_position} (Block: {subclass_block_name}, Index: Subclass{subclass_index_in_block}).")

    # Post-modification cleanup: remove empty subclass blocks
    removed_any_empty_subclass_blocks = False
    blocks_to_check_for_emptiness = list(parse_blocks(lines).keys()) 
    for block_name in blocks_to_check_for_emptiness:
        if block_name.startswith("SubclassesForClass"):
            block_info = parse_blocks(lines).get(block_name)
            if block_info:
                _, _, content = block_info
                subclass_entries = extract_class_entries(content, "Subclass")
                if not subclass_entries: 
                    if remove_subclass_block_range(lines, block_name):
                        removed_any_empty_subclass_blocks = True
                        blocks = parse_blocks(lines) 

    if modified_by_content or modified_prefix_comment or removed_any_empty_subclass_blocks:
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.writelines(lines)
            log_action(file_path, f"File updated successfully after insertion/cleanup.")
        except IOError as e:
            log_action(file_path, f"ERROR: Could not write to file {file_path}. Please check permissions or if the file is open in another program. Error: {e}", level=logging.ERROR)
            print(f"ERROR: Could not write to file {file_path}. Please check permissions or if the file is open in another program. Error: {e}")
            return False # Indicate failure to write
    else:
        log_action(file_path, "No modifications made to file content.")

    return modified_by_content or modified_prefix_comment or removed_any_empty_subclass_blocks # Return overall modification status

def log_action(file_path, message, level=logging.INFO):
    if level == logging.ERROR:
        logging.error(f"{file_path} - {message}")
    else:
        logging.info(f"{file_path} - {message}")

# === MAIN SCRIPT ENTRY POINT ===

def main():
    print("Supremacy Class/Subclass Insertion Script")
    print("Inserts specified class string into .mbtc files at a specified class position.\n")

    base_dir = os.getcwd()
    mbtc_files = find_mbtc_files(base_dir)
    if not mbtc_files:
        print("No .mbtc files found in the current directory or subdirectories.")
        input("\nProcessing complete. Press Enter to exit...") 
        return

    print(f"Found {len(mbtc_files)} .mbtc files to process.")

    empty_classes_response = input("Do you wish to empty all class entries in each .mbtc? (y/n): ").strip().lower()
    if empty_classes_response == 'y':
        confirm_empty = input("Are you sure? This will remove all existing class and subclass entries. (y/n): ").strip().lower()
        if confirm_empty == 'y':
            print("\n--- Emptying All Class Entries ---")
            for file_path in mbtc_files:
                try:
                    cleared_prefix = clear_all_classes_in_file(file_path)
                    if cleared_prefix is False: # Check specifically for False if write failed
                        print(f"Failed to clear: {file_path}. See error messages above.")
                    else:
                        print(f"Cleared: {file_path}")
                        if cleared_prefix: # `cleared_prefix` will be the prefix string on success
                            log_action(file_path, f"File cleared. Original prefix found: {cleared_prefix}")
                    
                except Exception as e:
                        logging.exception(f"Error clearing {file_path}: {e}")
                        print(f"Error clearing {file_path}: {e}")
            print("Finished clearing class entries.")
        else:
            print("Operation to empty classes cancelled.")
    
    print("\n--- Starting Class Insertion Process ---")
    while True: 
        try:
            desired_pos_input = input("\nEnter desired class position (1-based, classes 1-6, subclasses start at 7), 'q' to quit, or 'e' to empty all classes: ").strip().lower()
            if desired_pos_input == 'q':
                break 
            elif desired_pos_input == 'e':
                confirm_empty = input("Are you sure you want to empty all class entries? (y/n): ").strip().lower()
                if confirm_empty == 'y':
                    print("\n--- Emptying All Class Entries ---")
                    for file_path in mbtc_files:
                        try:
                            cleared_prefix = clear_all_classes_in_file(file_path)
                            if cleared_prefix is False:
                                print(f"Failed to clear: {file_path}. See error messages above.")
                            else:
                                print(f"Cleared: {file_path}")
                                if cleared_prefix:
                                    log_action(file_path, f"File cleared. Original prefix found: {cleared_prefix}")
                        except Exception as e:
                            logging.exception(f"Error clearing {file_path}: {e}")
                            print(f"Error clearing {file_path}: {e}")
                    print("Finished emptying class entries.")
                else:
                    print("Emptying classes cancelled.")
                continue # Continue the loop to ask for position again

            desired_pos = int(desired_pos_input)
            if desired_pos < 1:
                print("Position must be at least 1.")
                continue
        except ValueError:
            print("Invalid input. Please enter a valid integer, 'q', or 'e'.")
            continue

        new_class_suffix = input("Enter the class name suffix (e.g. 'test' for s_1em_test): ").strip()
        if not new_class_suffix:
            print("Class suffix cannot be empty. Please try again.")
            continue 

        print("\n--- Processing Files ---")
        for file_path in mbtc_files:
            try:
                modified = process_file(file_path, desired_pos, new_class_suffix)
                if modified is False: # Check explicitly for False if write failed
                     print(f"Failed to modify: {file_path}. See error messages above.")
                elif modified: # modified can be True or the prefix string
                    print(f"Modified: {file_path}")
                else:
                    print(f"No change: {file_path}")
            except Exception as e:
                logging.exception(f"Error processing {file_path}: {e}") 
                print(f"Error processing {file_path}: {e}")

    input("\nProcessing complete. Press Enter to exit...")

if __name__ == "__main__":
    main()
